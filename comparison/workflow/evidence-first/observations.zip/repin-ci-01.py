import argparse
import hashlib
from pathlib import Path
import re

def derived(root):
    target=root / '.github/workflows/native-source-workflow.yml'
    with target.open('rb') as stream:
        raw=stream.read(65537)
    if len(raw)>65536: raise ValueError('workflow bound')
    for key,name in (('NATIVE_WORKFLOW_HELD_SHA256','native_workspace.py'),('NATIVE_WORKFLOW_READER_SHA256','prepare_receipt.py')):
        with (root/'comparison/workflow'/name).open('rb') as stream:
            source=stream.read(131073)
        if len(source)>131072: raise ValueError('source bound')
        line=b'          '+key.encode()+b': '+hashlib.sha256(source).hexdigest().encode()
        raw,count=re.subn(rb'^          '+key.encode()+rb': [A-Za-z0-9_]+$',line,raw,flags=re.MULTILINE)
        if count!=1: raise ValueError('unique pin field required')
    return target,raw

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--root',type=Path,required=True); parser.add_argument('--check',action='store_true'); args=parser.parse_args()
    target,raw=derived(args.root)
    if args.check:
        if target.read_bytes()!=raw: raise ValueError('workflow pins differ')
    else:
        with target.open('wb') as stream:
            if stream.write(raw)!=len(raw): raise ValueError('short workflow write')
    print('Workflow pins derived from exact product and reader bytes')

if __name__=='__main__': main()
