"""Create an explicit successor contract/oracle without rewriting the first freeze."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def save(name, value):
    with (ROOT / name).open('x', encoding='ascii') as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=True) + '\n')

contract = json.loads((ROOT / 'contract.json').read_bytes())
contract['supersedes'] = 'contract.json first freeze retained; closed output spelling and timing limitations clarified.'
contract['core']['output_exact_keys'].extend(['attempts', 'prespecification_timing'])
contract['core']['output_constants']['prespecification_timing'] = 'NOT_VERIFIED'
contract['core']['attempts_output'] = 'attempts is an exact copy of the validated ordered plan attempts list, including every outcome/retry/task/arm/cache/actor/role record. Retrospective outcomes are allowed; no chronology or preregistration claim follows.'
contract['core']['slot_output'] = {
    'base_exact_keys': ['id', 'attempt', 'phase', 'metric', 'currency', 'status', 'reason'],
    'RECORDED_additional_exact_keys': ['measurement', 'artifact', 'artifact_sha256', 'value', 'interval', 'aggregation'],
    'UNKNOWN_additional_exact_keys': [],
    'NOT_APPLICABLE_additional_exact_keys': [],
    'values': 'id/attempt/phase/metric/currency are copied from the frozen slot; status from ledger. reason is empty for RECORDED, ledger reason for UNKNOWN, plan reason for NOT_APPLICABLE. measurement is source measurement ID; artifact is binding ID; artifact_sha256 is held artifact digest. value and interval copied unchanged from source claim. aggregation is NONADDITIVE_OBSERVATION for provider_cumulative metrics, NO_AGGREGATION otherwise. Sort slots by id. No additional fields.'
}
contract['refusals']['precedence'] = 'First byte caps and held root digest checks. Canonical JSON parse precedes object interpretation. For parsed objects, cardinality maxima produce INPUT_BOUND before semantic schema/inventory checks. Empty plan attempts or slots produce PLAN_INVENTORY. Then plan schema/inventory/phase coverage; exact artifact binding IDs and pins; artifact schema/plan identity/global measurement ID uniqueness; ledger slot coverage; applicability; per-record measurement binding and once-only use; unused measurement; interval shape/comparability/overlap; output cap. Multiple independent simultaneous failures outside this ordering have no oracle priority claim.'
contract['CLI']['path_grammar'] = 'Path fields are nonempty absolute UTF-8 strings at most4096 encoded bytes, excluding NUL; they are serialized with ensure_ascii=true like all JSON strings. Path strings are the sole exception to the ASCII identifier/reason rules. Duplicate artifact IDs refuse BINDING_MISMATCH before dictionary conversion; no last-wins normalization.'
contract['acceptance_link'] += ' This tool does not verify prespecification timing; independent external protocol freeze and chronology evidence remain prerequisites before a study.'
save('contract-v2.json', contract)
oracle = json.loads((ROOT / 'oracle.json').read_bytes())
oracle['supersedes'] = 'oracle.json first freeze retained; expected output spelling and timing/attempt preservation clarified.'
base = {
    'schema': 'transport/accounting-completeness-report/1', 'status': 'RECORDED_COMPLETE',
    'plan_sha256': 'HELD_PLAN_SHA256', 'ledger_sha256': 'HELD_LEDGER_SHA256',
    'attempts': oracle['plan']['attempts'], 'slots': [], 'authority': 'NONE',
    'measurement_truth': 'UNPROVEN', 'source_authentication': 'UNKNOWN',
    'clock_trust': 'UNKNOWN', 'coverage_scope': 'DECLARED_FROZEN_INVENTORY_ONLY',
    'hidden_work_detection': 'NONE', 'benefit': 'NOT_ASSESSED', 'acceptance': 'NOT_ASSESSED',
    'prespecification_timing': 'NOT_VERIFIED'
}
# Only literal fixture records supply the expected fields; no product code is consulted.
for slot, measurement in zip(oracle['plan']['slots'], oracle['artifact_E1']['measurements'], strict=True):
    base['slots'].append({'id':slot['id'],'attempt':slot['attempt'],'phase':slot['phase'],
        'metric':slot['metric'],'currency':None,'status':'RECORDED','reason':'',
        'measurement':measurement['id'],'artifact':'E1','artifact_sha256':'E1_SHA256',
        'value':100,'interval':measurement['interval'],'aggregation':'NO_AGGREGATION'})
base['slots'].sort(key=lambda value:value['id'])
oracle['literal_base_expected_output'] = base
oracle['required_boundary_controls'].append({
    'boundary':'duplicate CLI artifact IDs',
    'construction':'Use base request and append the identical E1 binding again before CLI dictionary conversion.',
    'expected':{'status':'REFUSED','reason':'BINDING_MISMATCH'}})
save('oracle-v2.json', oracle)
