"""Expand literal independent oracle inputs; expected outcomes remain oracle literals."""
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
MAX_TREE = 8 * 1024 * 1024


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def default_record(slot, measurement):
    return {'slot':slot, 'status':'RECORDED', 'measurement':measurement, 'reason':''}


def initial(oracle):
    artifact = copy.deepcopy(oracle['artifact_E1'])
    records = [default_record(item['slot'],item['id']) for item in artifact['measurements']]
    return {'plan':copy.deepcopy(oracle['plan']), 'artifact_E1':artifact,
            'ledger':{'schema':'transport/accounting-ledger/1','plan_sha256':'PLAN_SHA256',
                      'artifacts':[], 'records':records}}


def locate(state, target):
    parts = target.split('.')
    value = state[parts[0]]
    for part in parts[1:]:
        value = value[part]
    return value


def selected(items, edit):
    if edit.get('all'):
        return items
    key = 'id' if 'id' in edit else 'slot'
    return [item for item in items if item[key] == edit[key]]


def edit_one(state, edit):
    target = locate(state,edit['target'])
    if 'set' in edit:
        targets = selected(target,edit) if isinstance(target,list) else [target]
        need(bool(targets),'fixture edit selected nothing')
        for value in targets:
            value.update(copy.deepcopy(edit['set']))
    elif 'replace' in edit:
        key = 'id' if 'id' in edit else 'slot'
        indexes = [i for i,v in enumerate(target) if v[key] == edit[key]]
        need(len(indexes)==1,'fixture replace selection')
        target[indexes[0]] = copy.deepcopy(edit['replace'])
    elif 'append' in edit:
        target.append(copy.deepcopy(edit['append']))
    elif edit.get('reverse'):
        target.reverse()
    else:
        key = 'id' if 'remove_id' in edit else 'slot'
        values = edit.get('remove_slots',[edit.get('remove_id',edit.get('remove_slot'))])
        target[:] = [item for item in target if item[key] not in values]


def copy_attempt(state, extra, oracle):
    state['plan']['attempts'].append(copy.deepcopy(extra['attempt']))
    for index, original in enumerate(oracle['plan']['slots']):
        slot = copy.deepcopy(original)
        slot.update(id=extra['slot_ids'][index],attempt=extra['attempt']['id'])
        state['plan']['slots'].append(slot)
        measurement = copy.deepcopy(oracle['artifact_E1']['measurements'][index])
        measurement.update(id=extra['measurement_ids'][index],slot=slot['id'])
        measurement['interval'].update(start=extra['starts'][index],end=extra['ends'][index])
        state['artifact_E1']['measurements'].append(measurement)
        state['ledger']['records'].append(default_record(slot['id'],measurement['id']))


def expansion(state, spec, oracle):
    target = spec['target']
    count = spec['copies']
    need(count<=129,'fixture expansion bound')
    if target == 'plan.slots':
        template = oracle['plan']['slots'][0]
        state['plan']['slots'] = [dict(copy.deepcopy(template),id='Slot'+str(i)) for i in range(count)]
    elif target == 'plan.attempts':
        template = oracle['plan']['attempts'][0]
        state['plan']['attempts'] = [dict(copy.deepcopy(template),id='Attempt'+str(i)) for i in range(count)]
    elif target == 'ledger.artifacts_and_bindings':
        for key in list(state):
            if key.startswith('artifact_'):
                del state[key]
        for i in range(count):
            artifact = copy.deepcopy(oracle['artifact_E1'])
            artifact['measurements'][0]['id']='Source'+str(i)
            state['artifact_Evidence'+str(i)] = artifact
    else:
        raise ValueError('undeclared expansion')


def state_for(case, cases, oracle, depth=0):
    need(depth<=2,'fixture inheritance bound')
    state = state_for(cases[case['base']],cases,oracle,depth+1) if 'base' in case else initial(oracle)
    for edit in case.get('edits',[]):
        edit_one(state,edit)
    for extra in case.get('copy_attempts',[]):
        copy_attempt(state,extra,oracle)
    state['plan']['slots'].extend(copy.deepcopy(case.get('append_slots',[])))
    for item in case.get('append_measurements',[]):
        state['artifact_E1']['measurements'].append(copy.deepcopy(item))
        if case.get('append_record',True):
            state['ledger']['records'].append(default_record(item['slot'],item['id']))
    for name, artifact in case.get('extra_artifacts',{}).items():
        state['artifact_'+name] = copy.deepcopy(artifact)
    if 'literal_expansion' in case:
        expansion(state,case['literal_expansion'],oracle)
    return state


def raw_edit(raw, edit):
    if 'append' in edit:
        return raw + edit['append'].encode('ascii')
    old,new = edit['replace'].encode('ascii'),edit['with'].encode('ascii')
    need(old in raw,'raw edit target missing')
    return raw.replace(old,new,1 if edit.get('only_first') else -1)


def serialize(state,case):
    plan = canonical(state['plan'])
    edit = case.get('raw_edit',{})
    raw_input = case.get('raw_input',{})
    if edit.get('target')=='plan':
        plan = raw_edit(plan,edit)
    if raw_input.get('target')=='plan':
        plan = raw_input['repeat_ASCII'].encode('ascii') * raw_input['count']
    artifacts = {}
    for key, value in state.items():
        if not key.startswith('artifact_'):
            continue
        if case.get('substitute_artifact_plan',True):
            value['plan_sha256']=sha(plan)
        raw = canonical(value)
        if edit.get('target')==key:
            raw = raw_edit(raw,edit)
        if raw_input.get('target')==key:
            raw = raw_input['repeat_ASCII'].encode('ascii') * raw_input['count']
        artifacts[key[len('artifact_'):]] = raw
    ledger = state['ledger']
    ledger['plan_sha256']=sha(plan)
    ledger['artifacts']=[{'id':key,'bytes':len(raw),'sha256':sha(raw)} for key,raw in sorted(artifacts.items())]
    ledger_raw = canonical(ledger)
    if case.get('retain_old_pins')=='artifact_only':
        name=case['alter_bytes']['artifact']
        artifacts[name]=artifacts[name].replace(b'"value":100',b'"value":101',1)
    if 'extra_binding' in case:
        extra=case['extra_binding']
        artifacts[extra['id']]=extra['bytes'].encode('ascii')
    return plan,ledger_raw,artifacts


def write_new(path,raw,inventory):
    with path.open('xb') as stream:
        need(stream.write(raw)==len(raw),'short fixture write')
    need(path.read_bytes()==raw,'fixture readback mismatch')
    inventory[str(path.relative_to(ROOT))]={'bytes':len(raw),'sha256':sha(raw)}


def write_case(case, cases, oracle, folder, inventory):
    plan,ledger,artifacts=serialize(state_for(case,cases,oracle),case)
    child=folder/case['id']
    child.mkdir()
    write_new(child/'plan.json',plan,inventory)
    write_new(child/'ledger.json',ledger,inventory)
    for name,raw in artifacts.items():
        write_new(child/(name+'.json'),raw,inventory)
    roots={'plan_sha256':sha(plan),'ledger_sha256':case.get('held_ledger_sha256',sha(ledger)),
           'bindings':sorted(artifacts),'expected':case['expected'],
           'scope':'CLI_ONLY' if 'CLI_raw_request' in case else 'CORE_AND_CLI'}
    write_new(child/'held.json',canonical(roots),inventory)
    if 'CLI_raw_request' in case:
        spec=case['CLI_raw_request']
        write_new(child/'request.raw',spec['repeat_ASCII'].encode('ascii')*spec['count'],inventory)


def main():
    need(len(sys.argv)==1,'no data-selected options')
    oracle=json.loads((ROOT/'oracle-v2.json').read_bytes())
    folder=ROOT/'fixtures-v2'
    folder.mkdir()
    inventory={}
    cases={case['id']:case for case in oracle['cases']}
    for case in oracle['cases']:
        write_case(case,cases,oracle,folder,inventory)
    receipt={'schema':'transport/accounting-oracle-materialization/1',
             'oracle_sha256':sha((ROOT/'oracle-v2.json').read_bytes()),
             'contract_sha256':sha((ROOT/'contract-v2.json').read_bytes()),
             'builder_sha256':sha(Path(__file__).read_bytes()),'files':inventory,
             'case_ids':[case['id'] for case in oracle['cases']],
             'expected_outcomes_source':'Literal frozen oracle only; no product imported.'}
    raw=canonical(receipt)
    need(sum(item['bytes'] for item in inventory.values())+len(raw)<=MAX_TREE,'fixture tree bound')
    with (ROOT/'fixtures-v2-manifest.json').open('xb') as stream:
        need(stream.write(raw)==len(raw),'manifest short write')
    print(json.dumps({'status':'MATERIALIZED_NOT_PRODUCT_TESTED','cases':len(cases),'manifest_sha256':sha(raw)}))


if __name__=='__main__':
    main()
