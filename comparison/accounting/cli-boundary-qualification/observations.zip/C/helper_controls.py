"""Fixed synthetic helper controls; never invokes the accounting CLI."""
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner_support as S



def refusal(action):
    try:
        action()
    except (OSError, ValueError):
        return True
    raise ValueError('expected helper refusal absent')


def main():
    S.limits()
    root = S.DESIGN / 'helper-controls'
    root.mkdir(mode=0o700)
    rows = []
    sample = root / 'sample.bin'
    S.write(sample, b'abc')
    rows.append(dict(case='bounded-read', passed=S.read(sample, 3) == b'abc'))
    rows.append(dict(case='read-over-cap', passed=refusal(lambda: S.read(sample, 2))))
    rows.append(dict(case='create-only', passed=refusal(lambda: S.write(sample, b'other'))))
    link = root / 'link.bin'
    link.symlink_to(sample)
    rows.append(dict(case='symlink-refusal', passed=refusal(lambda: S.read(link))))
    calls = [('success', "import sys;sys.stdout.write('ok\\n')", 0, 2, False),
             ('nonzero', 'raise SystemExit(3)', 3, 2, False),
             ('timeout', 'import time;time.sleep(2)', None, 0.1, True),
             ('file-cap', "import sys;sys.stdout.write('x'*131073);sys.stdout.flush()", None, 2, False)]
    for stem, code, expected, seconds, session in calls:
        result = S.process([S.PYTHON, '-I', '-S', '-B', '-Werror', '-c', code],
                           root, stem, seconds, session=session)
        if stem == 'timeout':
            passed = result['timed_out'] and result['exit'] < 0
        elif stem == 'file-cap':
            passed = result['exit'] != 0 and result['stdout']['bytes'] <= 131072
        else:
            passed = result['exit'] == expected and not result['timed_out']
        rows.append(dict(case=stem, passed=passed, process=result))
    S.need(all(row['passed'] for row in rows), 'helper control failed')
    report = dict(status='PASS', scope='FIXED_SYNTHETIC_HELPER_CONTROLS_ONLY',
                  actual_accounting_CLI_calls='NONE', rows=rows)
    S.write(root / 'report.json', S.canonical(report))
    print(json.dumps(dict(status=report['status'], scope=report['scope'])))


if __name__ == '__main__':
    main()
