"""Prepare fixed API references, or run only under a separately pinned launch receipt."""
import json
import os
from pathlib import Path
import resource
import sys
import time

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner_support as S

CONTRACT_PIN = {'bytes': 8578, 'sha256': 'f4cdd4f5a5ce88f3bd2a701c1539778009ec3158af24640c79d07e0e1b08fab4'}
ORACLE_PIN = {'bytes': 5004, 'sha256': '44b98bee0ffb69fa501c8bedb018624c56871d8c94831d2fa64ac7fa4911dca1'}


def inputs():
    S.check(S.DESIGN / 'contract.json', CONTRACT_PIN)
    S.check(S.DESIGN / 'literal-oracle.json', ORACLE_PIN)
    return S.document(S.DESIGN / 'contract.json'), S.document(S.DESIGN / 'literal-oracle.json')


def stage_case(case, data):
    name = case['case']
    folder = S.ROOT / 'stage' / name
    folder.mkdir(mode=0o700)
    bindings, descriptors = {}, {}
    for member, expected in case['input_members'].items():
        raw = data[member]
        path = folder / Path(member).name
        S.write(path, raw, 65536)
        S.check(path, expected, 65536)
        descriptors[path.name] = dict(path=str(path), **expected)
        if path.name.startswith('Evidence'):
            bindings[path.stem] = raw
    request = dict(schema='transport/accounting-request/1', plan=descriptors['plan.json'],
        ledger=descriptors['ledger.json'], artifacts=[dict(id=key,
        **descriptors[key + '.json']) for key in bindings])
    request_path = folder / 'request.json'
    S.write(request_path, S.canonical(request), 65536)
    folder.chmod(0o500)
    return dict(request=str(request_path), plan=descriptors['plan.json'],
                ledger=descriptors['ledger.json']), bindings


def prepare():
    contract, oracle = inputs()
    S.capacity()
    before = S.source_pins(contract)
    S.ROOT.mkdir(mode=0o700)
    (S.ROOT / 'stage').mkdir(mode=0o700)
    (S.ROOT / 'api-reference').mkdir(mode=0o700)
    rel = 'comparison/accounting/tests/boundary_check.py'
    loader = S.fixed_module(S.SOURCE / rel, contract['pins'][rel])
    data, module, references = loader.fixtures(), loader.subject(), {}
    for case in oracle['cases']:
        name = case['case']
        loader.run_case(module, data, name)
        request, bindings = stage_case(case, data)
        prefix = name + '/'
        plan, ledger = data[prefix + 'plan.json'], data[prefix + 'ledger.json']
        result = module.validate(plan, loader.sha(plan), ledger, loader.sha(ledger), bindings)
        S.need(result['status'] == case['expected_status'], 'literal status')
        raw = loader.canonical(result) + b'\n'
        if name == 'overflow':
            S.need(raw == case['literal_stdout_ascii'].encode('ascii'), 'literal refusal')
        else:
            S.need(len(raw) == case['checked_report_bytes_including_LF'], 'literal size')
        reference = S.ROOT / 'api-reference' / (name + '.stdout')
        references[name] = dict(input=request, reference=S.write(reference, raw))
    (S.ROOT / 'stage').chmod(0o500)
    (S.ROOT / 'api-reference').chmod(0o500)
    after = S.source_pins(contract)
    S.need(before == after, 'source changed during preparation')
    report = dict(status='PREPARED_API_REFERENCES_NO_CLI_CALLS', source_before=before,
        source_after=after, cases=references, semantics='QUALIFIED_API_BYTE_EQUIVALENCE_ONLY',
        frozen_inputs=frozen_inputs(), design_pins=dict(contract=CONTRACT_PIN, oracle=ORACLE_PIN))
    S.write(S.ROOT / 'prepared.json', S.canonical(report))
    S.capacity()
    return report


def frozen_inputs():
    result = {}
    for name in S.CASES:
        folder = S.ROOT / 'stage' / name
        for filename in ('plan.json', 'ledger.json', 'Evidencexxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.json', 'request.json'):
            path = folder / filename
            result[str(path)] = S.pin(path, 65536)
        path = S.ROOT / 'api-reference' / (name + '.stdout')
        result[str(path)] = S.pin(path)
    return result


def launch_check():
    launch = S.document(S.ROOT / 'launch-admission.json')
    S.need(launch['status'] == 'ADMITTED_FIXED_SIX_CLI_CALLS', 'launch not admitted')
    S.check(S.DESIGN / 'runner.py', launch['runner'])
    S.check(S.DESIGN / 'runner_support.py', launch['support'])
    S.check(S.ROOT / 'prepared.json', launch['prepared'])
    prepared = S.document(S.ROOT / 'prepared.json')
    S.need(frozen_inputs() == prepared['frozen_inputs'], 'frozen input mutation')
    return prepared


def cpu_used():
    rows = [resource.getrusage(kind) for kind in (resource.RUSAGE_SELF, resource.RUSAGE_CHILDREN)]
    return sum(row.ru_utime + row.ru_stime for row in rows)


def mode_case(mode, case, prepared, folder, started, baseline):
    S.capacity()
    name = case['case']
    row = prepared['cases'][name]['input']
    argv = [S.PYTHON, '-I', '-S', '-B'] + (['-O'] if mode == 'optimized' else [])
    argv += ['-Werror', str(S.SOURCE / 'comparison/accounting/check.py'), '--request',
        row['request'], '--expect-plan-sha256', row['plan']['sha256'],
        '--expect-ledger-sha256', row['ledger']['sha256']]
    remaining = 30 - (time.monotonic() - started)
    cpu_remaining = int(29 - (cpu_used() - baseline))
    S.need(remaining > 0 and cpu_remaining >= 1, 'mode budget exhausted')
    result = S.process(argv, folder, name, remaining, cpu_remaining)
    S.write(folder / (name + '.result.json'), S.canonical(result))
    actual = S.read(folder / (name + '.stdout'))
    expected = S.read(S.ROOT / 'api-reference' / (name + '.stdout'))
    S.need(not result['timed_out'] and result['exit'] == case['expected_cli_exit'], 'CLI exit')
    S.need(result['stderr']['bytes'] == 0 and actual == expected, 'CLI byte equivalence')
    return result


def observe(paths):
    result = {}
    for name, path in paths.items():
        try:
            result[name] = S.pin(path)
        except (OSError, ValueError) as error:
            result[name] = dict(error=type(error).__name__, detail=str(error)[:256])
    return result


def mode_run(mode):
    contract, oracle = inputs()
    prepared = launch_check()
    folder = S.ROOT / mode
    folder.mkdir(mode=0o700)
    before, files_before = S.source_pins(contract), frozen_inputs()
    source_paths = {rel: S.SOURCE / rel for rel in contract['pins']}
    source_paths['runtime'] = Path(S.PYTHON)
    started, baseline = time.monotonic(), cpu_used()
    results = [dict(case=name, status='UNRUN') for name in S.CASES]
    failure = None
    try:
        for index, case in enumerate(oracle['cases']):
            results[index]['status'] = 'FAILED'
            result = mode_case(mode, case, prepared, folder, started, baseline)
            results[index].update(status='PASS', process=result)
        S.need(cpu_used() - baseline <= 30 and time.monotonic() - started <= 30, 'mode resource cap')
    except (OSError, ValueError, RuntimeError) as error:
        failure = dict(type=type(error).__name__, detail=str(error)[:256])
    after = observe(source_paths)
    files_after = observe({name: Path(name) for name in files_before})
    identical = before == after and files_before == files_after
    report = dict(status='PASS' if failure is None and identical else 'FAILED',
        mode=mode, results=results, failure=failure, source_before=before,
        source_after=after, inputs_before=files_before, inputs_after=files_after)
    S.write(folder / 'mode-result.json', S.canonical(report))
    S.need(report['status'] == 'PASS', 'mode qualification failed; receipt retained')
    return report


def run():
    launch_check()
    results = []
    for mode in S.MODES:
        S.capacity()
        argv = [S.PYTHON, '-I', '-S', '-B', '-Werror', str(S.DESIGN / 'runner.py'), 'mode', mode]
        result = S.process(argv, S.ROOT, mode + '-supervisor', 30, session=True)
        results.append(result)
        S.write(S.ROOT / (mode + '-supervisor.json'), S.canonical(result))
        S.need(not result['timed_out'] and result['exit'] == 0 and
               result['stderr']['bytes'] == 0, 'mode process failed')
        S.need(S.document(S.ROOT / mode / 'mode-result.json')['status'] == 'PASS', 'mode result')
    report = dict(status='TESTED_CLI_BOUNDARIES_NORMAL_AND_OPTIMIZED', modes=results,
        consequence='API_CLI_BYTE_EQUIVALENCE_ONLY', acceptance='NOT_ASSESSED')
    S.write(S.ROOT / 'result.json', S.canonical(report))
    return report


def main():
    S.limits()
    S.need(sys.executable == S.PYTHON, 'fixed local interpreter required')
    if sys.argv[1:] == ['prepare']:
        report = prepare()
    elif sys.argv[1:] == ['run']:
        report = run()
    elif len(sys.argv) == 3 and sys.argv[1] == 'mode' and sys.argv[2] in S.MODES:
        report = mode_run(sys.argv[2])
    else:
        raise ValueError('fixed prepare/run/mode syntax only')
    print(json.dumps(dict(status=report['status']), sort_keys=True))


if __name__ == '__main__':
    main()
