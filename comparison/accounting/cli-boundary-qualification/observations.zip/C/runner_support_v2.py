"""Bounded local-only helpers for the reviewed CLI equivalence qualification."""
import ctypes
import errno
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import time
import types

DESIGN = Path('/dev/shm/semantic-transport-cli-boundary-design-20261029')
ROOT = Path('/dev/shm/semantic-transport-cli-boundary-qualification-20261029')
SOURCE = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
PYTHON = '/usr/bin/python3.14'
CASES = ('exact-plan', 'exact-ledger', 'overflow')
MODES = ('normal', 'optimized')


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('ascii')


def safe_path(path):
    need(path.is_absolute(), 'absolute path required')
    for parent in (*reversed(path.parents), path):
        need(not parent.is_symlink(), 'symlink component')


def read(path, cap=131072):
    safe_path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'regular exclusive file')
        need(0 <= before.st_size <= cap, 'read bound')
        raw = stream.read(cap + 1)
        after = os.fstat(stream.fileno())
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(len(raw) == before.st_size and all(getattr(before, k) == getattr(after, k)
         for k in keys), 'file changed during bounded read')
    return raw


def pin(path, cap=131072):
    raw = read(path, cap)
    row = path.stat()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                stat={k: getattr(row, k) for k in ('st_dev', 'st_ino', 'st_size',
                     'st_mtime_ns', 'st_ctime_ns', 'st_mode', 'st_uid', 'st_nlink')})


def check(path, expected, cap=131072):
    observed = pin(path, cap)
    need(all(observed[k] == expected[k] for k in ('bytes', 'sha256')), 'held pin mismatch')
    return observed


def write(path, raw, cap=131072):
    need(type(raw) is bytes and len(raw) <= cap, 'write bound')
    safe_path(path.parent)
    need(path.parent.is_dir(), 'missing parent')
    with path.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'short write')
        stream.flush()
        os.fsync(stream.fileno())
    path.chmod(0o400)
    return pin(path, cap)


def document(path):
    return json.loads(read(path))


def footprint(root, cap):
    root_row = root.lstat()
    need(stat.S_ISDIR(root_row.st_mode), 'root directory')
    total = max(root_row.st_size, root_row.st_blocks * 512)
    files, stack = 0, [(root, 0)]
    for _ in range(256):
        if not stack:
            need(total <= cap, 'task capacity')
            return total
        parent, depth = stack.pop()
        need(depth <= 4, 'tree depth')
        with os.scandir(parent) as entries:
            for entry in entries:
                files += 1
                need(files <= 256 and not entry.is_symlink(), 'tree count/type')
                row = entry.stat(follow_symlinks=False)
                total += max(row.st_size, row.st_blocks * 512)
                need(total <= cap, 'tree allocated bytes')
                if entry.is_dir(follow_symlinks=False):
                    stack.append((Path(entry.path), depth + 1))
                else:
                    need(stat.S_ISREG(row.st_mode) and row.st_nlink == 1, 'tree file')
    raise ValueError('tree traversal bound')


def capacity():
    need(os.statvfs('/dev/shm').f_bavail * os.statvfs('/dev/shm').f_frsize >= 8388608,
         'tmpfs free capacity')
    if ROOT.exists():
        footprint(ROOT, 8388608)
        if (ROOT / 'stage').exists():
            footprint(ROOT / 'stage', 1048576)


def limits(cpu=30):
    for kind, cap in ((resource.RLIMIT_AS, 268435456), (resource.RLIMIT_CPU, cpu),
                      (resource.RLIMIT_FSIZE, 131072), (resource.RLIMIT_NOFILE, 64)):
        soft, hard = resource.getrlimit(kind)
        next_hard = cap if hard == resource.RLIM_INFINITY else min(hard, cap)
        next_soft = next_hard if soft == resource.RLIM_INFINITY else min(soft, next_hard)
        resource.setrlimit(kind, (next_soft, next_hard))


def source_pins(contract):
    result = {rel: check(SOURCE / rel, held) for rel, held in contract['pins'].items()}
    runtime = contract['runtime']
    result['runtime'] = check(Path(runtime['path']), runtime)
    return result


def fixed_module(path, expected):
    check(path, expected)
    raw = read(path, 65536)
    module = types.ModuleType('fixed_boundary_qualification')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec', dont_inherit=True), module.__dict__)
    return module


CLEANUP_SECONDS = 2


def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    call = libc.prctl
    call.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
    call.restype = ctypes.c_int
    need(call(36, 1, 0, 0, 0) == 0, 'Linux subreaper unavailable')


def group_members(pgid, deadline):
    members = []
    with os.scandir('/proc') as entries:
        for count, entry in enumerate(entries):
            need(count < 8192 and time.monotonic() < deadline, 'bounded proc scan exhausted')
            if not entry.name.isdigit():
                continue
            try:
                with open('/proc/' + entry.name + '/stat', 'rb') as stream:
                    raw = stream.read(4097)
            except OSError as error:
                if error.errno in (errno.ENOENT, errno.ESRCH):
                    continue
                raise
            need(len(raw) <= 4096 and b') ' in raw, 'proc stat bound/shape')
            fields = raw.rsplit(b') ', 1)[1].split()
            need(len(fields) >= 3, 'proc stat fields')
            if int(fields[2]) == pgid:
                members.append(dict(pid=int(entry.name), state=fields[0].decode('ascii')))
                need(len(members) <= 64, 'owned process count')
    return members


def reap_group(pgid, rows):
    for _ in range(64):
        try:
            pid, status = os.waitpid(-pgid, os.WNOHANG)
        except ChildProcessError:
            return
        if pid == 0:
            return
        rows.append(dict(pid=pid, wait_status=status))
    raise ValueError('reap child count bound')


def cleanup(child, session):
    deadline = time.monotonic() + CLEANUP_SECONDS
    result = dict(budget_seconds=CLEANUP_SECONDS, confirmed=False, reaped=[], errors=[])
    try:
        try:
            if session:
                os.killpg(child.pid, signal.SIGKILL)
            elif child.poll() is None:
                child.kill()
        except ProcessLookupError:
            pass
        except OSError as error:
            result['errors'].append(dict(action='kill', type=type(error).__name__, errno=error.errno))
        try:
            result['direct_exit'] = child.wait(timeout=max(0, deadline - time.monotonic()))
        except (subprocess.TimeoutExpired, OSError) as error:
            result['errors'].append(dict(action='wait', type=type(error).__name__))
        for _ in range(200):
            if time.monotonic() >= deadline:
                break
            if session:
                reap_group(child.pid, result['reaped'])
                members = group_members(child.pid, deadline)
            else:
                members = [] if child.poll() is not None else [dict(pid=child.pid, state='UNKNOWN')]
            result['remaining_members'] = members
            if not members and child.returncode is not None:
                result['confirmed'] = not result['errors']
                break
            time.sleep(min(0.01, max(0, deadline - time.monotonic())))
    except (OSError, ValueError) as error:
        result['errors'].append(dict(action='cleanup', type=type(error).__name__, detail=str(error)[:128]))
    result['elapsed_seconds'] = CLEANUP_SECONDS - max(0, deadline - time.monotonic())
    result['direct_reaped'] = child.returncode is not None
    result['scope'] = 'OWNED_PROCESS_GROUP' if session else 'DIRECT_CHILD_OUTER_GROUP_STILL_OWNED'
    return result


def process(argv, folder, stem, timeout, cpu=30, session=False, on_spawn=None):
    outpath, errpath = folder / (stem + '.stdout'), folder / (stem + '.stderr')
    safe_path(folder)
    child, started = None, time.monotonic()
    result = dict(argv=argv, exit=None, timed_out=False, dispatch='FAILED_TO_START', errors=[])
    try:
        if session:
            subreaper()
        with outpath.open('xb') as stdout, errpath.open('xb') as stderr:
            child = subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, start_new_session=session,
                preexec_fn=lambda: limits(cpu))
            result.update(dispatch='STARTED', pid=child.pid)
            if on_spawn is not None:
                on_spawn(child.pid)
            try:
                result['exit'] = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                result['timed_out'] = True
    except BaseException as error:
        result['errors'].append(dict(type=type(error).__name__, detail=str(error)[:128]))
    finally:
        if child is not None:
            result['cleanup'] = cleanup(child, session)
            result['exit'] = child.returncode
        else:
            result['cleanup'] = dict(confirmed=True, scope='NO_CHILD_CREATED')
    result['elapsed_seconds'] = time.monotonic() - started
    for label, path in (('stdout', outpath), ('stderr', errpath)):
        if path.exists():
            path.chmod(0o400)
            result[label] = pin(path)
        else:
            result[label] = dict(missing=True)
    return result
