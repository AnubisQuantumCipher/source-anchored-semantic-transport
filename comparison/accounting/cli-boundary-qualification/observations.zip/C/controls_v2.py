"""Targeted C1-C4 synthetic controls; never invoke accounting/check.py."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner_support_v2 as S
import runner_v2 as R

BASE = S.DESIGN / 'controls-v2'


def need_error(call):
    try:
        call()
    except (OSError, ValueError):
        return True
    raise ValueError('expected refusal absent')


def inventory_control():
    folder = BASE / 'inventory'
    folder.mkdir(mode=0o700)
    original = S.ROOT
    S.ROOT = folder
    try:
        (folder / 'dispatch-v2').mkdir(mode=0o700)
        R.journal('normal', 'exact-plan', 'intent', dict(argv=['SYNTHETIC'], dispatch='INFLIGHT_UNCERTAIN'))
        rows = R.dispatch_inventory()
        S.need(len(rows) == 6 and rows[0]['dispatch'] == 'INFLIGHT_UNCERTAIN', 'inflight inventory')
        S.need(all(row['status'] == 'UNRUN' for row in rows[1:]), 'unrun inventory')
        R.journal('normal', 'exact-plan', 'observed', dict(dispatch='FAILED_TO_START', exit=None))
        R.journal('normal', 'exact-plan', 'checked', dict(status='FAILED'))
        rows = R.dispatch_inventory()
        S.need(rows[0]['status'] == 'FAILED' and rows[0]['dispatch'] == 'FAILED_TO_START', 'failed start')
        return dict(case='C1_DURABLE_INTENT_FAILED_START_SIX_ROWS', status='PASS', inventory=rows)
    finally:
        S.ROOT = original


def orchestration_control(stem, dispatch):
    folder = BASE / stem
    folder.mkdir(mode=0o700)
    saved = {name: getattr(R, name) for name in
             ('inputs', 'frozen_inputs', 'launch_check', 'supervised_mode', 'observe')}
    old_root, old_limits, old_pins = S.ROOT, S.limits, S.source_pins
    S.ROOT, S.limits, S.source_pins = folder, lambda: None, lambda unused: {}
    R.inputs, R.frozen_inputs, R.observe = lambda: ({'pins': {}}, None), lambda: {}, lambda unused: {}
    def failure(unused=None):
        if dispatch:
            R.journal('normal', 'exact-plan', 'intent', dict(argv=['SYNTHETIC'], dispatch='INFLIGHT_UNCERTAIN'))
        raise ValueError('fixed synthetic prelaunch/supervisor failure')
    R.launch_check = (lambda: {}) if dispatch else failure
    R.supervised_mode = failure
    try:
        result = R.run()
        S.need(result['status'] == 'FAILED_OR_INCOMPLETE' and len(result['inventory']) == 6, 'terminal inventory')
        rows = result['inventory']
        if dispatch:
            S.need(rows[0]['dispatch'] == 'INFLIGHT_UNCERTAIN', 'dispatch certainty')
            rows = rows[1:]
        S.need(all(row['status'] == 'UNRUN' for row in rows), 'terminal unrun')
        S.need(S.document(folder / 'terminal-result-v2.json') == result, 'durable terminal')
        return dict(case=stem, status='PASS', terminal=result)
    finally:
        S.ROOT, S.limits, S.source_pins = old_root, old_limits, old_pins
        for name, value in saved.items():
            setattr(R, name, value)


def descendant_control(stem, timeout):
    folder = BASE / stem
    folder.mkdir(mode=0o700)
    pidfile = folder / 'descendant.pid'
    script = ('import os,subprocess,time\n'
        'p=subprocess.Popen([' + repr(S.PYTHON) + ",'-I','-S','-B','-c','import time;time.sleep(60)'])\n"
        'f=open(' + repr(str(pidfile)) + ",'x');f.write(str(p.pid));f.flush();os.fsync(f.fileno());f.close()\n" +
        ('time.sleep(60)\n' if timeout else 'os._exit(7)\n'))
    result = S.process([S.PYTHON, '-I', '-S', '-B', '-Werror', '-c', script],
                       folder, 'supervisor', 0.3 if timeout else 2, session=True)
    pid = int(S.read(pidfile, 32))
    S.need(result['cleanup']['confirmed'] and result['cleanup']['direct_reaped'], 'group cleanup')
    S.need(any(row['pid'] == pid for row in result['cleanup']['reaped']), 'descendant reaped')
    S.need(not Path('/proc/' + str(pid)).exists(), 'descendant still exists')
    S.need(result['timed_out'] if timeout else result['exit'] == 7, 'abnormal observation')
    return dict(case=stem, status='PASS', process=result, descendant_pid=pid)


class WaitFailure:
    pid, returncode = 2147483647, None
    def poll(self):
        return None
    def kill(self):
        return None
    def wait(self, timeout=None):
        S.need(timeout is not None and 0 <= timeout <= S.CLEANUP_SECONDS, 'unbounded wait')
        raise subprocess.TimeoutExpired('SYNTHETIC', timeout)


def bounded_reap_control():
    started = time.monotonic()
    result = S.cleanup(WaitFailure(), False)
    elapsed = time.monotonic() - started
    S.need(not result['confirmed'] and not result['direct_reaped'], 'false reap claim')
    S.need(elapsed < 3 and result['errors'], 'cleanup deadline missing')
    return dict(case='C3_BOUNDED_FAILED_REAP_NO_FALSE_SUCCESS', status='PASS', cleanup=result)


def allocation_control():
    folder = BASE / 'allocation'
    folder.mkdir(mode=0o700)
    S.write(folder / 'tiny', b'x')
    rows = [folder.stat(), (folder / 'tiny').stat()]
    logical = sum(row.st_size for row in rows)
    allocated = sum(max(row.st_size, row.st_blocks * 512) for row in rows)
    S.need(allocated > logical, 'fixture not distinguishing allocation')
    S.need(S.footprint(folder, allocated) == allocated, 'allocated directory/file accounting')
    S.need(need_error(lambda: S.footprint(folder, logical)), 'logical-only ceiling accepted')
    return dict(case='C4_ALLOCATED_BYTES_DIRECTORY_INCLUDED', status='PASS',
                observed_logical_bytes=logical, observed_allocated_bytes=allocated)


def static_control():
    result = {}
    for name in ('runner_v2.py', 'runner_support_v2.py', 'controls_v2.py'):
        raw = S.read(S.DESIGN / name, 65536)
        tree = ast.parse(raw)
        compile(raw, str(S.DESIGN / name), 'exec', dont_inherit=True)
        rows = {row.name: row.end_lineno - row.lineno + 1 for row in ast.walk(tree)
                if isinstance(row, ast.FunctionDef)}
        S.need(all(value <= 60 for value in rows.values()), 'function cap')
        result[name] = dict(pin=S.pin(S.DESIGN / name), functions=rows)
    return dict(case='STATIC_WARNING_ERROR_COMPILE_FUNCTION_CAP', status='PASS', files=result)


def main():
    BASE.mkdir(mode=0o700)
    results = [static_control(), inventory_control(), orchestration_control('C1_prelaunch', False),
        orchestration_control('C1_supervisor', True), descendant_control('C2_abnormal_descendant', False),
        descendant_control('C2_C3_timeout_descendant', True), bounded_reap_control(), allocation_control()]
    report = dict(status='PASS', actual_check_py_calls='NONE', results=results,
                  scope='TARGETED_C1_C2_C3_C4_SYNTHETIC_CONTROLS_ONLY')
    S.write(BASE / 'report.json', S.canonical(report))
    print(json.dumps(dict(status='PASS', actual_check_py_calls='NONE')))


if __name__ == '__main__':
    main()
