"""Prepare fixed API references, or run only under a separately pinned launch receipt."""
import json
import os
from pathlib import Path
import resource
import sys
import time

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import runner_support_v2 as S

CONTRACT_PIN = {'bytes': 8578, 'sha256': 'f4cdd4f5a5ce88f3bd2a701c1539778009ec3158af24640c79d07e0e1b08fab4'}
ORACLE_PIN = {'bytes': 5004, 'sha256': '44b98bee0ffb69fa501c8bedb018624c56871d8c94831d2fa64ac7fa4911dca1'}


def inputs():
    S.check(S.DESIGN / 'contract.json', CONTRACT_PIN)
    S.check(S.DESIGN / 'literal-oracle.json', ORACLE_PIN)
    return S.document(S.DESIGN / 'contract.json'), S.document(S.DESIGN / 'literal-oracle.json')


def frozen_inputs():
    result = {}
    for name in S.CASES:
        folder = S.ROOT / 'stage' / name
        for filename in ('plan.json', 'ledger.json', 'Evidencexxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.json', 'request.json'):
            path = folder / filename
            result[str(path)] = S.pin(path, 65536)
        path = S.ROOT / 'api-reference' / (name + '.stdout')
        result[str(path)] = S.pin(path)
    return result


def launch_check():
    launch = S.document(S.ROOT / 'launch-admission-v2.json')
    S.need(launch['status'] == 'ADMITTED_FIXED_SIX_CLI_CALLS', 'launch not admitted')
    S.check(S.DESIGN / 'runner_v2.py', launch['runner'])
    S.check(S.DESIGN / 'runner_support_v2.py', launch['support'])
    S.check(S.ROOT / 'prepared.json', launch['prepared'])
    prepared = S.document(S.ROOT / 'prepared.json')
    S.need(frozen_inputs() == prepared['frozen_inputs'], 'frozen input mutation')
    return prepared


def cpu_used():
    rows = [resource.getrusage(kind) for kind in (resource.RUSAGE_SELF, resource.RUSAGE_CHILDREN)]
    return sum(row.ru_utime + row.ru_stime for row in rows)


def journal(mode, name, phase, value):
    path = S.ROOT / 'dispatch-v2' / (mode + '--' + name + '--' + phase + '.json')
    return S.write(path, S.canonical(value))


def case_argv(mode, row):
    argv = [S.PYTHON, '-I', '-S', '-B'] + (['-O'] if mode == 'optimized' else [])
    return argv + ['-Werror', str(S.SOURCE / 'comparison/accounting/check.py'), '--request',
        row['request'], '--expect-plan-sha256', row['plan']['sha256'],
        '--expect-ledger-sha256', row['ledger']['sha256']]


def mode_case(mode, case, prepared, folder, started, baseline):
    S.capacity()
    name = case['case']
    argv = case_argv(mode, prepared['cases'][name]['input'])
    remaining = 30 - (time.monotonic() - started)
    cpu_remaining = int(29 - (cpu_used() - baseline))
    S.need(remaining > 0 and cpu_remaining >= 1, 'mode budget exhausted')
    journal(mode, name, 'intent', dict(argv=argv, dispatch='INFLIGHT_UNCERTAIN'))
    on_spawn = lambda pid: journal(mode, name, 'spawned', dict(pid=pid, dispatch='STARTED'))
    result = S.process(argv, folder, name, remaining, cpu_remaining, on_spawn=on_spawn)
    journal(mode, name, 'observed', result)
    failure = None
    try:
        actual = S.read(folder / (name + '.stdout'))
        expected = S.read(S.ROOT / 'api-reference' / (name + '.stdout'))
        S.need(not result['timed_out'] and result['exit'] == case['expected_cli_exit'], 'CLI exit')
        S.need(not result['errors'] and result['cleanup']['confirmed'], 'CLI cleanup')
        S.need(result['stderr'].get('bytes') == 0 and actual == expected, 'CLI byte equivalence')
    except (OSError, ValueError) as error:
        failure = dict(type=type(error).__name__, detail=str(error)[:256])
    journal(mode, name, 'checked', dict(status='PASS' if failure is None else 'FAILED', failure=failure))
    S.need(failure is None, 'CLI case failed; durable evidence retained')
    return result


def observe(paths):
    result = {}
    for name, path in paths.items():
        try:
            result[name] = S.pin(path)
        except (OSError, ValueError) as error:
            result[name] = dict(error=type(error).__name__, detail=str(error)[:256])
    return result


def dispatch_inventory():
    rows = []
    for mode in S.MODES:
        for name in S.CASES:
            row = dict(mode=mode, case=name, status='UNRUN', dispatch='CONFIRMED_NO_INTENT')
            for phase in ('intent', 'spawned', 'observed', 'checked'):
                path = S.ROOT / 'dispatch-v2' / (mode + '--' + name + '--' + phase + '.json')
                if not path.exists():
                    continue
                row['status'] = 'FAILED_OR_INCOMPLETE'
                if phase in ('intent', 'spawned'):
                    row['dispatch'] = 'INFLIGHT_UNCERTAIN'
                try:
                    value = S.document(path)
                    row[phase] = value
                    if phase == 'observed':
                        row['dispatch'] = value['dispatch']
                    if phase == 'checked':
                        row['status'] = value['status']
                except (OSError, ValueError, KeyError) as error:
                    row['journal_error'] = str(error)[:128]
                    row['dispatch'] = 'INFLIGHT_UNCERTAIN'
            if row['status'] == 'PASS' and (not all(k in row for k in
                    ('intent', 'spawned', 'observed', 'checked')) or 'journal_error' in row):
                row.update(status='FAILED_OR_INCOMPLETE', dispatch='INFLIGHT_UNCERTAIN')
            rows.append(row)
    return rows


def mode_run(mode):
    contract, oracle = inputs()
    prepared = launch_check()
    folder = S.ROOT / (mode + '-v2')
    folder.mkdir(mode=0o700)
    before, files_before = S.source_pins(contract), frozen_inputs()
    source_paths = {rel: S.SOURCE / rel for rel in contract['pins']}
    source_paths['runtime'] = Path(S.PYTHON)
    started, baseline = time.monotonic(), cpu_used()
    failure = None
    try:
        for case in oracle['cases']:
            mode_case(mode, case, prepared, folder, started, baseline)
        S.need(cpu_used() - baseline <= 30 and time.monotonic() - started <= 30, 'mode resource cap')
    except BaseException as error:
        failure = dict(type=type(error).__name__, detail=str(error)[:256])
    after = observe(source_paths)
    files_after = observe({name: Path(name) for name in files_before})
    identical = before == after and files_before == files_after
    report = dict(status='PASS' if failure is None and identical else 'FAILED',
        mode=mode, inventory=dispatch_inventory(), failure=failure, source_before=before,
        source_after=after, inputs_before=files_before, inputs_after=files_after)
    S.write(folder / 'mode-result.json', S.canonical(report))
    return report


def supervised_mode(mode):
    S.capacity()
    argv = [S.PYTHON, '-I', '-S', '-B', '-Werror', str(S.DESIGN / 'runner_v2.py'), 'mode', mode]
    S.write(S.ROOT / (mode + '-supervisor-intent-v2.json'), S.canonical(dict(argv=argv)))
    result = S.process(argv, S.ROOT, mode + '-supervisor-v2', 30, session=True)
    S.write(S.ROOT / (mode + '-supervisor-result-v2.json'), S.canonical(result))
    S.need(not result['timed_out'] and result['exit'] == 0 and not result['errors'], 'mode process failed')
    S.need(result['cleanup']['confirmed'] and result['stderr'].get('bytes') == 0, 'mode cleanup/stderr')
    S.need(S.document(S.ROOT / (mode + '-v2') / 'mode-result.json')['status'] == 'PASS', 'mode result')
    return result


def run():
    failure, modes, before, files_before = None, [], {}, {}
    source_paths = {}
    try:
        (S.ROOT / 'dispatch-v2').mkdir(mode=0o700)
        S.write(S.ROOT / 'inventory-initial-v2.json', S.canonical(dict(inventory=dispatch_inventory())))
        S.limits()
        S.need(sys.executable == S.PYTHON, 'fixed local interpreter required')
        contract, unused_oracle = inputs()
        source_paths = {rel: S.SOURCE / rel for rel in contract['pins']}
        source_paths['runtime'] = Path(S.PYTHON)
        before, files_before = S.source_pins(contract), frozen_inputs()
        launch_check()
        for mode in S.MODES:
            modes.append(supervised_mode(mode))
    except BaseException as error:
        failure = dict(type=type(error).__name__, detail=str(error)[:256])
    after = observe(source_paths)
    files_after = observe({name: Path(name) for name in files_before})
    inventory = dispatch_inventory()
    passed = (failure is None and before == after and files_before == files_after
              and all(row['status'] == 'PASS' for row in inventory))
    report = dict(status='TESTED_CLI_BOUNDARIES_NORMAL_AND_OPTIMIZED' if passed else
        'FAILED_OR_INCOMPLETE', modes=modes, inventory=inventory, failure=failure,
        source_before=before, source_after=after, inputs_before=files_before,
        inputs_after=files_after, consequence='API_CLI_BYTE_EQUIVALENCE_ONLY', acceptance='NOT_ASSESSED')
    S.write(S.ROOT / 'terminal-result-v2.json', S.canonical(report))
    return report


def main():
    if sys.argv[1:] == ['run']:
        report = run()
    elif len(sys.argv) == 3 and sys.argv[1] == 'mode' and sys.argv[2] in S.MODES:
        S.limits()
        report = mode_run(sys.argv[2])
    else:
        raise ValueError('fixed v2 run/mode syntax only; preparation is already frozen')
    print(json.dumps(dict(status=report['status']), sort_keys=True))
    return 0 if report['status'] in ('PASS', 'TESTED_CLI_BOUNDARIES_NORMAL_AND_OPTIMIZED') else 1


if __name__ == '__main__':
    raise SystemExit(main())
