"""Bounded local-only helpers for the reviewed CLI equivalence qualification."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import time
import types

DESIGN = Path('/dev/shm/semantic-transport-cli-boundary-design-20261029')
ROOT = Path('/dev/shm/semantic-transport-cli-boundary-qualification-20261029')
SOURCE = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
PYTHON = '/usr/bin/python3.14'
CASES = ('exact-plan', 'exact-ledger', 'overflow')
MODES = ('normal', 'optimized')


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('ascii')


def safe_path(path):
    need(path.is_absolute(), 'absolute path required')
    for parent in (*reversed(path.parents), path):
        need(not parent.is_symlink(), 'symlink component')


def read(path, cap=131072):
    safe_path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'regular exclusive file')
        need(0 <= before.st_size <= cap, 'read bound')
        raw = stream.read(cap + 1)
        after = os.fstat(stream.fileno())
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    need(len(raw) == before.st_size and all(getattr(before, k) == getattr(after, k)
         for k in keys), 'file changed during bounded read')
    return raw


def pin(path, cap=131072):
    raw = read(path, cap)
    row = path.stat()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                stat={k: getattr(row, k) for k in ('st_dev', 'st_ino', 'st_size',
                     'st_mtime_ns', 'st_ctime_ns', 'st_mode', 'st_uid', 'st_nlink')})


def check(path, expected, cap=131072):
    observed = pin(path, cap)
    need(all(observed[k] == expected[k] for k in ('bytes', 'sha256')), 'held pin mismatch')
    return observed


def write(path, raw, cap=131072):
    need(type(raw) is bytes and len(raw) <= cap, 'write bound')
    safe_path(path.parent)
    need(path.parent.is_dir(), 'missing parent')
    with path.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'short write')
        stream.flush()
        os.fsync(stream.fileno())
    path.chmod(0o400)
    return pin(path, cap)


def document(path):
    return json.loads(read(path))


def footprint(root, cap):
    total, files, stack = 0, 0, [(root, 0)]
    for _ in range(64):
        if not stack:
            need(total <= cap, 'task capacity')
            return total
        parent, depth = stack.pop()
        need(depth <= 4, 'tree depth')
        with os.scandir(parent) as entries:
            for entry in entries:
                files += 1
                need(files <= 64 and not entry.is_symlink(), 'tree count/type')
                if entry.is_dir(follow_symlinks=False):
                    stack.append((Path(entry.path), depth + 1))
                else:
                    row = entry.stat(follow_symlinks=False)
                    need(stat.S_ISREG(row.st_mode) and row.st_nlink == 1, 'tree file')
                    total += row.st_size
                    need(total <= cap, 'tree bytes')
    raise ValueError('tree traversal bound')


def capacity():
    need(os.statvfs('/dev/shm').f_bavail * os.statvfs('/dev/shm').f_frsize >= 8388608,
         'tmpfs free capacity')
    if ROOT.exists():
        footprint(ROOT, 8388608)
        if (ROOT / 'stage').exists():
            footprint(ROOT / 'stage', 1048576)


def limits(cpu=30):
    for kind, cap in ((resource.RLIMIT_AS, 268435456), (resource.RLIMIT_CPU, cpu),
                      (resource.RLIMIT_FSIZE, 131072), (resource.RLIMIT_NOFILE, 64)):
        soft, hard = resource.getrlimit(kind)
        next_hard = cap if hard == resource.RLIM_INFINITY else min(hard, cap)
        next_soft = next_hard if soft == resource.RLIM_INFINITY else min(soft, next_hard)
        resource.setrlimit(kind, (next_soft, next_hard))


def source_pins(contract):
    result = {rel: check(SOURCE / rel, held) for rel, held in contract['pins'].items()}
    runtime = contract['runtime']
    result['runtime'] = check(Path(runtime['path']), runtime)
    return result


def fixed_module(path, expected):
    check(path, expected)
    raw = read(path, 65536)
    module = types.ModuleType('fixed_boundary_qualification')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec', dont_inherit=True), module.__dict__)
    return module


def process(argv, folder, stem, timeout, cpu=30, session=False):
    outpath, errpath = folder / (stem + '.stdout'), folder / (stem + '.stderr')
    safe_path(folder)
    started = time.monotonic()
    with outpath.open('xb') as stdout, errpath.open('xb') as stderr:
        child = subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL,
            stdout=stdout, stderr=stderr, start_new_session=session,
            preexec_fn=lambda: limits(cpu))
        timed_out = False
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            if session:
                os.killpg(child.pid, signal.SIGKILL)
            else:
                child.kill()
            code = child.wait()
    outpath.chmod(0o400)
    errpath.chmod(0o400)
    return dict(argv=argv, exit=code, timed_out=timed_out,
        elapsed_seconds=time.monotonic() - started,
        stdout=pin(outpath), stderr=pin(errpath))
