"""Add literal required boundary controls; retain every earlier raw fixture freeze."""
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('literal_fixture_builder',ROOT/'materialize_iterative.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def supplementary():
    return [
      {'id':'B01_JSON_DEPTH_OVER','edits':[{'target':'plan','set':{'extra':[[[[[[[[[[[[[]]]]]]]]]]]]]}}],
       'expected':{'status':'REFUSED','reason':'JSON_INVALID'}},
      {'id':'B02_CROSS_ARM_OVERLAP','base':'P04_FAILED_UNSAFE_RETRY_RETAINED','edits':[
       {'target':'plan.attempts','id':'A2','set':{'arm':'transport','retry_of':None}},
       {'target':'plan.attempts','id':'A3','set':{'arm':'transport'}},
       {'target':'artifact_E1.measurements','id':'Nsetup','set':{'interval':{'clock':'C1','start':15,'end':25}}}],
       'expected':{'status':'REFUSED','reason':'INTERVAL_OVERLAP'}},
      {'id':'B03_MODEL_TIME_NOT_HUMAN','base':'P02_MISSING_HUMAN_TASK','append_slots':[
       {'id':'Smodel','attempt':'A1','phase':'inference','metric':'model_elapsed_ns','currency':None,'applicability':'required','reason':''}],
       'append_measurements':[{'id':'Mmodel','slot':'Smodel','metric':'model_elapsed_ns','currency':None,'value':400,'interval':{'clock':'Modelclock','start':1,'end':2}}],
       'expected':{'status':'INCOMPLETE'}},
      {'id':'B04_ADMIN_TIME_NOT_HUMAN','base':'P02_MISSING_HUMAN_TASK','append_slots':[
       {'id':'Sadmin','attempt':'A1','phase':'task','metric':'owner_admin_ns','currency':None,'applicability':'required','reason':''}],
       'append_measurements':[{'id':'Madmin','slot':'Sadmin','metric':'owner_admin_ns','currency':None,'value':400,'interval':{'clock':'Adminclock','start':1,'end':2}}],
       'expected':{'status':'INCOMPLETE'}}]


def aggregate_case(folder,inventory,oracle):
    case={'id':'B05_AGGREGATE_ARTIFACT_OVER','expected':{'status':'REFUSED','reason':'INPUT_BOUND'}}
    plan,ledger,unused=module.serialize(module.initial(oracle),case)
    records=json.loads(ledger)
    artifacts={'E'+str(i):b' '*65536 for i in range(17)}
    records['artifacts']=[{'id':name,'bytes':len(raw),'sha256':module.sha(raw)} for name,raw in artifacts.items()]
    ledger=module.canonical(records)
    child=folder/case['id'];child.mkdir()
    for name,raw in {'plan.json':plan,'ledger.json':ledger,**{k+'.json':v for k,v in artifacts.items()}}.items():
        module.write_new(child/name,raw,inventory)
    held={'plan_sha256':module.sha(plan),'ledger_sha256':module.sha(ledger),
          'bindings':sorted(artifacts),'expected':case['expected'],'scope':'CORE_AND_CLI'}
    module.write_new(child/'held.json',module.canonical(held),inventory)
    return case


def duplicate_cli(folder,inventory,oracle):
    case={'id':'B06_DUPLICATE_CLI_BINDING','expected':{'status':'REFUSED','reason':'BINDING_MISMATCH'}}
    plan,ledger,artifacts=module.serialize(module.initial(oracle),case)
    child=folder/case['id'];child.mkdir()
    for name,raw in {'plan.json':plan,'ledger.json':ledger,**{k+'.json':v for k,v in artifacts.items()}}.items():
        module.write_new(child/name,raw,inventory)
    def reference(name,raw):
        return {'path':str(child/name),'bytes':len(raw),'sha256':module.sha(raw)}
    binding=dict(id='E1',**reference('E1.json',artifacts['E1']))
    request={'schema':'transport/accounting-request/1','plan':reference('plan.json',plan),
             'ledger':reference('ledger.json',ledger),'artifacts':[binding,binding]}
    held={'plan_sha256':module.sha(plan),'ledger_sha256':module.sha(ledger),
          'bindings':['E1'],'expected':case['expected'],'scope':'CLI_ONLY'}
    module.write_new(child/'held.json',module.canonical(held),inventory)
    module.write_new(child/'request.raw',module.canonical(request),inventory)
    return case


def main():
    oracle=json.loads((ROOT/'oracle-v2.json').read_bytes())
    folder=ROOT/'fixtures-v4';folder.mkdir()
    inventory={};cases={v['id']:v for v in oracle['cases']}
    ordered=list(oracle['cases'])+supplementary()
    for case in ordered:
        module.write_case(case,cases,oracle,folder,inventory)
    ordered.append(aggregate_case(folder,inventory,oracle))
    ordered.append(duplicate_cli(folder,inventory,oracle))
    receipt={'schema':'transport/accounting-oracle-materialization/1',
        'oracle_sha256':module.sha((ROOT/'oracle-v2.json').read_bytes()),
        'contract_sha256':module.sha((ROOT/'contract-v2.json').read_bytes()),
        'builder_sha256':module.sha(Path(__file__).read_bytes()),
        'helper_sha256':module.sha((ROOT/'materialize_iterative.py').read_bytes()),
        'files':inventory,'case_ids':[v['id'] for v in ordered],
        'expected_outcomes_source':'42 literal oracle cases plus six literal required boundary controls; no product imported.',
        'boundary_recipe_correction':'B02 changes A3 arm as well as A2 to retain retry identity and isolate the predeclared overlap refusal; no expected outcome changed.',
        'conditional_runtime_controls_unrun':['exact65536-byte valid plan/ledger intersection','output131073-byte valid-input reachability']}
    raw=module.canonical(receipt)
    module.need(sum(v['bytes'] for v in inventory.values())+len(raw)<=module.MAX_TREE,'tree cap')
    with (ROOT/'fixtures-v4-manifest.json').open('xb') as stream:
        module.need(stream.write(raw)==len(raw),'manifest short write')
    print(json.dumps({'status':'MATERIALIZED_NOT_PRODUCT_TESTED','cases':len(ordered),'manifest_sha256':module.sha(raw)}))


if __name__=='__main__':
    main()
