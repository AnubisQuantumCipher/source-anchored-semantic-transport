import os, sys
args = sys.argv[1:]
if len(args) > 32 or args[0] != sys.executable:
    raise ValueError('fixed test Python/argv required')
index = args.index('--request-json') + 1
if args[index] != '__FROZEN_70000_X_REQUEST__':
    raise ValueError('fixed literal oversize case required')
args[index] = 'x' * 70000
os.execve(sys.executable, args, dict(os.environ))
