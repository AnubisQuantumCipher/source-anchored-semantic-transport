"""Isolated, bounded write fault injections. Does not execute producer."""
import errno
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path('/dev/shm/semantic-transport-independent-reader-20261029/review')
SOURCE = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028/install/read_transport_export.py')
spec = importlib.util.spec_from_file_location('reader', SOURCE)
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
real_write = r.os.write
real_run = r._run
line = r._json_line({'status': 'EXACT_PINNED_EXPORT_BYTES_RECOVERED', 'authority': 'NONE'})
raw = b'checked inert bytes'
results = []

def positive_short_case():
    output = BASE / 'repaired-short-selected.bin'
    captured = bytearray()
    def writer(fd, data):
        if fd == 1:
            n = min(12, len(data))
            captured.extend(data[:n])
            return n
        return real_write(fd, data)
    r.os.write = writer
    try:
        r._publish(output, raw, line)
        result = {'case':'all_positive_short','stdout_hex':captured.hex(),
                  'complete_json_exact':bytes(captured)==line,
                  'output_exact':output.read_bytes()==raw}
        result['passed'] = result['complete_json_exact'] and result['output_exact']
        results.append(result)
    finally:
        r.os.write = real_write
        if output.exists():
            output.unlink()


def invalid_count_case(name, count):
    r.os.write = lambda fd, data: count
    try:
        try:
            r._write_bytes(1, b'x', 'STDOUT_WRITE')
            outcome = 'ACCEPTED'
        except r.ExportReadError as error:
            outcome = error.code
        results.append({'case':name,'returned_count':count,'outcome':outcome,
                        'passed':outcome=='STDOUT_WRITE'})
    finally:
        r.os.write = real_write


def failure_case():
    output = BASE / 'repaired-pipe-selected.bin'
    stdout = bytearray()
    stderr = bytearray()
    def writer(fd, data):
        if fd == 1:
            if stdout:
                raise BrokenPipeError(errno.EPIPE, 'injected')
            stdout.extend(data[:7])
            return 7
        if fd == 2:
            n = min(3, len(data))
            stderr.extend(data[:n])
            return n
        return real_write(fd, data)
    r.os.write = writer
    r._run = lambda args: r._publish(output, raw, line)
    try:
        code = r.main([])
        diagnostic = json.loads(stderr)
        result = {'case':'stdout_partial_then_EPIPE_stderr_short',
                  'exit':code,'stdout_hex':stdout.hex(),'stderr_hex':stderr.hex(),
                  'diagnostic':diagnostic,'selected_file_remains':output.exists()}
        result['passed'] = (code!=0 and not output.exists() and
                            bytes(stdout)==line[:7] and
                            diagnostic['status']=='REFUSED')
        results.append(result)
    finally:
        r.os.write = real_write
        r._run = real_run

positive_short_case()
for name, count in [('zero',0),('boolean',True),('negative',-1),('impossible',2)]:
    invalid_count_case(name, count)
failure_case()
report = {'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'results':results,'all_passed':all(x['passed'] for x in results),
          'native_or_producer_executed':False}
(BASE/'repaired_fault_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
