"""Bounded short-write injection; no producer/runtime invocation."""
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path('/dev/shm/semantic-transport-independent-reader-20261029/review')
SOURCE = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028/install/read_transport_export.py')
spec = importlib.util.spec_from_file_location('independent_reader', SOURCE)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
original_write = reader.os.write
captured = bytearray()
line = b'{"status":"EXACT_PINNED_EXPORT_BYTES_RECOVERED"}\n'
output = BASE / 'repaired-original-repro-selected.bin'

def short_write(descriptor, raw):
    if descriptor == 1:
        count = min(12, len(raw))
        captured.extend(raw[:count])
        return count
    return original_write(descriptor, raw)

reader.os.write = short_write
try:
    reader._publish(output, b'checked inert bytes', line)
    outcome = 'unexpected success'
except reader.ExportReadError as error:
    outcome = error.code
finally:
    reader.os.write = original_write
result = {'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'error': outcome, 'stdout_hex': captured.hex(),
          'stdout_is_complete_success_json': bytes(captured) == line,
          'selected_file_remains': output.exists(),
          'injected_fault': 'stdout write returns valid positive short count',
          'producer_invoked': False}
(BASE / 'repaired-original-repro-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
