# Source-Anchored Semantic Transport lexicon.md

All metadata below are unverified declarations.
Original bytes are retained. Binary media are retained, not understood.
Anchors prove references to selected bytes only; they do not prove a reading.

<pre>
SOURCES
id: S0
label: Exact development S0
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S1
label: Exact development S1
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S2
label: Exact development S2
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S3
label: Exact development S3
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S4
label: Exact development S4
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S5
label: Exact development S5
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S6
label: Exact development S6
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S7
label: Exact development S7
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S8
label: Exact development S8
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S9
label: Exact development S9
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S10
label: Exact development S10
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S11
label: Exact development S11
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S12
label: Exact development S12
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S13
label: Exact development S13
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S14
label: Exact development S14
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

id: S15
label: Exact development S15
media_type: application/octet-stream
provenance: Authored development fixture; no model or semantic qualification.

INTERPRETATIONS
UNCERTAINTIES
RELATIONS
</pre>

Interpretation supplied: NO
Coverage is a byte-reference report; no semantic completeness is claimed.

## Fixed definitions

- Σ: Documentary source group only; not an arithmetic sum, universal quantifier or completeness claim.
- I: Ordered declared interpretation IDs and statuses; none means no interpretation was supplied.
- U: Ordered uncertainty IDs; none means no uncertainty record was supplied, not absence of uncertainty.
- R: Ordered declared relations, written first kind second; no causality, execution or authority is implied.
- anchor: Half-open offsets [begin,end) in exact original bytes with SHA-256 of the selected bytes; a reference only, not entailment.
- M: Typed meaning units with indexed operator trees, fixed dictionary identities and declared context dependencies; interpretation and adequacy remain unproved.
- supports: Declared support from the first record to the second; no entailment or truth is verified.
- contradicts: Declared conflict between the first record and the second; no inconsistency is proved.
- qualifies: The first record declares a qualification on the second; no scope or adequacy is verified.
- derived_from: The first record is declared derived from the second; no derivation is checked.
- supersedes: The first record is declared to replace the second in this reading; no authority is granted.

## Decoder and boundary

Use the separately supplied Transport decoder and matching runtime; never execute archive content.
This ZIP has exactly manifest.json, codec.json, index.json, formula.txt, README.md.
README.md is this lexicon.md document; the separately returned lexicon bytes are identical.
STS1 binds bytes and declarations, not author identity, truth, confidentiality or authority.
No reference is fetched. Missing or incompatible external dependencies refuse before reconstruction.
External trusted runtime; hash-then-use does not isolate hostile concurrent same-user mutation.
