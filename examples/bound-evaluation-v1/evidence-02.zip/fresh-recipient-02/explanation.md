# Source reconstruction and conditional results

This reconstruction uses only the frozen interface and its declared reader/evaluator commands. The interface SHA256 was checked as `0fc423e3fa797f7103d957b4fd2e096e1c29e48dfb932f9f1008c2daab90d6e1`. The reader was called first with `describe`, then `catalog`, then one complete page for each catalogued source. Each page declared `end:true`. The catalog describes all three as synthetic public fixtures with no current execution authority.

## Recovered source records

The following quotations reproduce the complete UTF-8 text returned by the reader, including the documentary literals. References use the reader's byte spans and source hashes, retained in the named command receipts.

**REQUIREMENT**, bytes [0,198), SHA256 `a5f5f17299494c57397ff7699e48bc5057e138aa4719e178a55809621f9aabcc`; [reader receipt](command-04-requirement.json):

```text
The security review must be complete and the validation review must be complete.
Exact documentary literals: 6.62607015e-34 J s and 1/3. No numeric evaluation or quantum interpretation is declared.
```

**EVIDENCE**, bytes [0,147), SHA256 `5785d910c764395189bcdd4d449a2a05436aaac772b1b17e75d8148dc544b774`; [reader receipt](command-05-evidence.json):

```text
Security review completion is reported TRUE.
Validation review completion is reported FALSE.
These attributed reports are not authenticated facts.
```

**HISTORY**, bytes [0,195), SHA256 `205b132c28e82c2633626ab58e5ad49b4d06b7ccbbdfabe2db018324a0113387`; [reader receipt](command-06-history.json):

```text
An older record reported validation review completion TRUE.
The later FALSE report is a declared correction. Neither recency nor correction wording automatically selects an authoritative report.
```

The requirement is a conjunction: security review completion is required, and validation review completion is required. EVIDENCE supplies attributed TRUE and FALSE reports respectively. HISTORY preserves an older TRUE validation report and the declared correction relationship without establishing which report is authoritative. These are recovered claims, not authenticated facts about completed reviews. The numeric strings above remain documentary literals; no mathematical or quantum conclusion is drawn.

## Interpretation and context boundaries

The page annotations associate `U_REQUIREMENT` with proposed interpretation `I_REQUIREMENT` and kind `instruction`; `U_EVIDENCE/I_EVIDENCE` and `U_HISTORY/I_HISTORY` are proposed `source_claim` readings. All representations are `INCOMPLETE`; typing is `TESTED_NOT_FORMALLY_PROVED`. Context adequacy, interpretation entailment and semantic completeness are `UNPROVEN`. Source text has execution authority `NONE`.

The EVIDENCE and HISTORY units each retain their whole returned span as opaque propositions. REQUIREMENT has residual spans [0,4), [19,20), [24,28), [36,37), [40,45), [62,63), [67,71), and [79,198). The last includes the documentary sentence. Residuals describe bytes outside declared spans/cues/mentions; they are not proof of semantic coverage. Full source recovery preserves these bytes alongside the proposed interpretation.

The evaluator preserves a `qualifies` relation from `I_HISTORY` to `I_EVIDENCE`, anchored to HISTORY [0,195). Its policy is `CONTEXT_LINKS_PRESERVED_NOT_INTERPRETED_AS_SUPERSESSION_OR_AUTHORITY`. Uncertainty `REPORT_AUTHENTICITY` affects all three interpretations: reports and correction precedence remain unauthenticated. Declared dependency closure is not a guarantee of adequate context; absence of additional declared uncertainty is not certainty.

## Computed outcomes

Both exact declared evaluator argv arrays ran successfully, without candidate input first. Each returned `EVALUATED` and an evaluation with status `CONDITIONAL_EVALUATION`, scope `SELECTED_DECLARED_GROUND_OBLIGATION_CONDITIONAL_ON_REPORTS`, and execution authority `NONE`. Only `U_REQUIREMENT` is evaluated as an obligation. `U_EVIDENCE` and `U_HISTORY` remain `NOT_EVALUATED` as units even where their attributed reports are calculation inputs.

| Declared input | Returned calculation | Root outcome | Canonical evaluation SHA256 |
| --- | --- | --- | --- |
| selection | SECURITY_COMPLETE = KNOWN_TRUE; security must = SATISFIED. VALIDATION_COMPLETE = KNOWN_FALSE; validation must = VIOLATED. Conjunction = VIOLATED. | VIOLATED | `6c67a51a914e54aa24bdf7eb97ad438b8e616f5861d053e6d1bfefcdeda5deea` |
| all | SECURITY_COMPLETE = KNOWN_TRUE; security must = SATISFIED. Conflicting FALSE and older TRUE validation reports give VALIDATION_COMPLETE = UNRESOLVED; validation must = UNKNOWN. Conjunction = UNKNOWN. | UNKNOWN | `a9f44b7e801b5f6b91977865e7cce3c09967a5ae25e5e3779f5861993e869714` |

See [selection evaluation receipt](command-07-evaluate-selection.json), [all evaluation receipt](command-08-evaluate-all.json), and the separately saved deterministic objects [selection](evaluation-selection.json) and [all](evaluation-all.json). The first calculation conditions on the declared selected reports; it does not independently authenticate or authorize that selection. The second preserves the conflict without choosing a report by recency or correction wording.

Both bind SECURITY_COMPLETE to meaning node 2 and VALIDATION_COMPLETE to meaning node 6 under contract SHA256 `0a0c7e2ef09f634f716a810cd8c443460058f3225938f83fdfa39454250ac37a`. The selected requirement source and unit hashes remain pinned in the saved evaluation objects. Each evaluation reports `source_entailment:UNPROVEN`, `report_interpretation:UNPROVEN`, `report_authentication:NOT_AUTHENTICATED`, and `context_adequacy:UNPROVEN`.

The candidate files pin only each deterministic evaluation object, canonicalized with UTF-8 JSON, ensure_ascii=False, sorted keys, comma/colon separators and allow_nan=False. Process timings are excluded. Each candidate carries the returned root outcome and empty commentary. Each corresponding evaluator was then called once with its candidate file. Both returned conclusion status `DECLARED_OUTCOME_MATCH`, commentary `NOT_ASSESSED`, and execution authority `NONE`; see [selection check](command-10-check-selection.json) and [all check](command-11-check-all.json). A checked structured conclusion does not validate this explanation's free prose, source entailment, completeness, real-world review status, authenticity, or any execution authority.

## Evidence limits

The full actual command results are retained as command-01 through command-11 JSON receipts. The interface verification wrapper emitted an incidental unclosed-file ResourceWarning, retained verbatim in command-02; its interface hash matched, the reader subprocess returned zero, and its response was OK. No reader/evaluator refusal was returned during reconstruction. No source text or candidate prose was executed.

The smallest next acceptance step beyond this demonstration would require independently justified report authenticity and selection precedence, plus evidence that the proposed interpretation faithfully covers the intended requirement and sufficient context. Those matters remain unproved here. This demonstration's candidate checks establish only the declared structured evaluation binding and outcome.
