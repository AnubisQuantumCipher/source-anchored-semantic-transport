#!/usr/bin/env python3
"""Read back selective exports and source offsets; create one additional audit receipt."""
import ast
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).absolute().parent


def read(path, cap=131072):
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= cap
    with path.open('rb') as stream:
        raw = stream.read(cap)
    assert len(raw) == path.stat().st_size
    return raw


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exports():
    receipt = json.loads(read(ROOT / 'receipt.json'))
    assert len(receipt['files']) <= 64
    for item in receipt['files']:
        path = Path(item['path'])
        raw = read(path)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        if path.suffix in ('.json', '.jsonl'):
            json.loads(raw)
        elif path.suffix == '.py':
            ast.parse(raw)
    for name in ('reviews', 'library'):
        assert gzip.decompress(read(ROOT / (name + '-source-baseline.gz'))) == read(ROOT / (name + '-source-baseline.bin'))


def sources():
    for label in ('recipient01', 'recipient02', 'reviewer', 'source_evaluator'):
        metadata = json.loads(read(ROOT / (label + '-metadata.json')))
        raw = read(Path(metadata['source_snapshot']['path']), 4194304)
        assert len(metadata['selected_exports']) <= 64
        for selected in metadata['selected_exports']:
            location = selected['source']
            line = raw[location['byte_start']:location['byte_end']]
            assert sha(line) == location['raw_line_sha256']
            payload = json.loads(line)['payload']
            if selected['kind'].startswith('custom_tool'):
                assert read(Path(selected['artifact']['path'])) == line
                assert payload['type'] in ('custom_tool_call', 'custom_tool_call_output')
            else:
                assert payload['phase'] == 'final_answer'
        assert all(item['value'] == {'model': 'gpt-6.1-sol', 'effort': 'high'}
                   for item in metadata['observed_turn_contexts'])


def dispatch():
    value = json.loads(read(ROOT / 'dispatches.json'))
    path = Path(value['root_tail_snapshot']['path'])
    start = max(0, path.stat().st_size - 4194304)
    with path.open('rb') as stream:
        stream.seek(start)
        raw = stream.read(4194304)
    assert len(value['selected_dispatches']) == 4
    for item in value['selected_dispatches'].values():
        location = item['source']
        assert location['byte_start'] >= start
        line = raw[location['byte_start'] - start:location['byte_end'] - start]
        assert sha(line) == location['raw_line_sha256']
        assert json.loads(line)['payload']['arguments'].encode() == read(Path(item['artifact']['path']))


def main():
    exports()
    sources()
    dispatch()
    files = list(ROOT.iterdir())
    assert len(files) <= 64 and all(path.is_file() and not path.is_symlink() for path in files)
    total = sum(path.stat().st_size for path in files)
    assert total < 1048576 - 4096
    receipt = dict(status='READBACK_VERIFIED_SCOPED', extraction_receipt_sha256=sha(read(ROOT / 'receipt.json')),
        audit_script_sha256=sha(read(Path(__file__))), measurements_sha256=sha(read(ROOT / 'measurements.json')),
        actual_file_bytes_before_audit_receipt=total, source_offsets='SELECTED_LINES_RECHECKED_AGAINST_CURRENT_LOG_BYTES',
        dispatch_scope='SELECTED_ARGUMENTS_RECHECKED_USING_ONLY_CURRENT_LAST_4MIB',
        gzip='BASELINE_ROUNDTRIPS_MATCH', authority='NONE')
    raw = json.dumps(receipt, sort_keys=True, separators=(',', ':')).encode() + b'\n'
    with (ROOT / 'audit-receipt.json').open('xb') as stream:
        assert stream.write(raw) == len(raw)
    print(raw.decode(), end='')


if __name__ == '__main__':
    main()
