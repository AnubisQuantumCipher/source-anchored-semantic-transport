#!/usr/bin/env python3
"""Bounded, selective audit export; never exports session instructions or reasoning."""
import ast
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile
import zlib

OUT = Path(__file__).absolute().parent
EVIDENCE = OUT.parent
WORK = Path('[HOST]/Work/semantic-transport-bound-evaluation-20261028')
SESSIONS = Path('[HOST]/.codex/sessions/2026/10/28')
ROOT_LOG = Path('[HOST]/.codex/sessions/2026/10/25/rollout-2026-10-25T20-34-20-01a175a1-2f57-7d91-a157-7e4375dcf7b0.jsonl')
LOGS = {
    'recipient01': 'rollout-2026-10-28T20-45-00-01a1851e-0948-7571-b00c-aa5ae20b3377.jsonl',
    'recipient02': 'rollout-2026-10-28T20-47-04-01a1851f-ed34-7731-a129-49be5b1bfaaf.jsonl',
    'reviewer': 'rollout-2026-10-28T20-33-08-01a18513-2d54-7e31-aaec-425507c63022.jsonl',
    'source_evaluator': 'rollout-2026-10-28T20-45-19-01a1851e-5382-75b1-92f2-c02bf326a1ee.jsonl'}
NEW_HELPERS = ('transport_bound_contract.py', 'transport_bound_evaluate.py',
               'transport_bound_inputs.py', 'transport_bound_lowering.py')
FORBIDDEN = (b'encrypted_content', b'base_instructions', b'user_instructions', b'creator_id', b'creatorId')


def require(test, message):
    if not test:
        raise ValueError(message)


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, cap=4194304):
    require(path.is_file() and not path.is_symlink(), 'regular nonsymlink input required')
    with path.open('rb') as stream:
        raw = stream.read(cap + 1)
    require(len(raw) <= cap, 'input byte cap')
    return raw


def pin(path, raw=None):
    data = read(path) if raw is None else raw
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def write(name, raw):
    require('/' not in name and len(raw) <= 131072, 'single export bound')
    require(not any(word in raw for word in FORBIDDEN), 'private instruction field in export')
    with (OUT / name).open('xb') as stream:
        require(stream.write(raw) == len(raw), 'short evidence write')
    return pin(OUT / name)


def save(name, value):
    return write(name, encoded(value) + b'\n')


def lines(raw, base=0):
    result, offset = [], base
    chunks = raw.splitlines(keepends=True)
    require(len(chunks) <= 4096, 'log line count cap')
    for number, line in enumerate(chunks, 1):
        require(len(line) <= 262144, 'log line byte cap')
        require(line.endswith(b'\n'), 'partial log line cannot be represented as complete')
        result.append((dict(line_number=number, byte_start=offset, byte_end=offset + len(line),
                            raw_line_sha256=digest(line)), line, json.loads(line)))
        offset += len(line)
    return result


def safe_final(payload):
    content = payload.get('content', [])
    require(type(content) is list and len(content) <= 32, 'final content count cap')
    text = []
    for item in content:
        require(item.get('type') == 'output_text' and type(item.get('text')) is str, 'plain final text only')
        text.append(item['text'])
    return '\n'.join(text).encode('utf-8')


def metadata_entry(obj, location):
    payload, kind = obj.get('payload', {}), obj.get('type')
    if kind == 'session_meta':
        value = {key: payload.get(key) for key in ('id', 'agent_path', 'timestamp', 'cli_version', 'model_provider')}
    elif kind == 'turn_context':
        value = {key: payload.get(key) for key in ('model', 'effort')}
    else:
        value = payload['info']
    return dict(value=value, timestamp=obj.get('timestamp'), source=location)


def export_log(label, filename):
    path = SESSIONS / filename
    raw = read(path)
    entries, exports, contexts, sessions, usage, events = lines(raw), [], [], [], [], []
    calls, nested = Counter(), Counter()
    for location, line, obj in entries:
        payload, kind = obj.get('payload', {}), obj.get('type')
        subtype = payload.get('type')
        if kind == 'session_meta':
            sessions.append(metadata_entry(obj, location))
        elif kind == 'turn_context':
            contexts.append(metadata_entry(obj, location))
        elif kind == 'event_msg' and subtype == 'token_count':
            usage.append(metadata_entry(obj, location))
        if kind == 'event_msg' and subtype in ('task_started', 'task_complete'):
            events.append(dict(type=subtype, timestamp=obj['timestamp'], source=location))
        if kind != 'response_item':
            continue
        if subtype in ('custom_tool_call', 'function_call'):
            calls[payload.get('name', 'UNKNOWN')] += 1
            nested.update(re.findall(r'tools\.([A-Za-z0-9_]+)\s*\(', payload.get('input', '')))
        if label.startswith('recipient') and subtype in ('custom_tool_call', 'custom_tool_call_output'):
            artifact = write(label + '-line-%04d.jsonl' % location['line_number'], line)
            exports.append(dict(kind=subtype, call_id=payload.get('call_id'), source=location, artifact=artifact))
        if subtype == 'message' and payload.get('role') == 'assistant' and payload.get('phase') == 'final_answer':
            artifact = write(label + '-final-%04d.txt' % location['line_number'], safe_final(payload))
            exports.append(dict(kind='final_assistant_text_metadata_stripped', source=location, artifact=artifact))
    require(len(sessions) == 1 and contexts and usage, 'missing observed session/model/token metadata')
    value = dict(schema='transport/selected-session-trace/1', source_snapshot=pin(path, raw),
        observed_first_timestamp=entries[0][2]['timestamp'], observed_last_timestamp=entries[-1][2]['timestamp'],
        session_meta=sessions[0], observed_turn_contexts=contexts, lifecycle_events=events,
        tool_call_names=dict(calls), nested_tool_references_lexically_observed=dict(nested),
        nested_reference_scope='Declared tool names in exec input, not independent invocation accounting.',
        last_token_count_info=usage[-1], token_count_events=len(usage), selected_exports=exports,
        usage_scope='Host-reported cumulative usage includes global and repeated context; not document tokens or billed cost.',
        cost=dict(status='UNKNOWN_NOT_REPORTED', billed_cost=None, currency=None),
        omitted='All reasoning, encrypted content, global/base/user instructions, private message metadata and account rate limits.',
        duration='NOT_DERIVED; observed timestamps retained without elapsed-time arithmetic.')
    save(label + '-metadata.json', value)
    return value


def dispatches(runs):
    size = ROOT_LOG.stat().st_size
    start = max(0, size - 4194304)
    with ROOT_LOG.open('rb') as stream:
        stream.seek(start)
        raw = stream.read(4194304)
    require(len(raw) <= 4194304, 'root tail cap')
    tail_pin = dict(path=str(ROOT_LOG), observed_file_bytes=size, byte_start=start,
                    bytes=len(raw), sha256=digest(raw), scope='LAST_4MIB_ONLY_NO_WHOLE_FILE_HASH')
    if start:
        first = raw.index(b'\n') + 1
        start, raw = start + first, raw[first:]
    targets = {value['session_meta']['value']['agent_path'].rsplit('/', 1)[1]: label for label, value in runs.items()}
    found = {}
    for location, line, obj in lines(raw, start):
        payload = obj.get('payload', {})
        if obj.get('type') != 'response_item' or payload.get('name') != 'spawn_agent':
            continue
        text = payload.get('arguments')
        require(type(text) is str, 'exact dispatch argument text required')
        arguments = json.loads(text)
        task = arguments.get('task_name')
        if task in targets:
            require(task not in found, 'ambiguous duplicate selected dispatch')
            artifact = write(targets[task] + '-dispatch-arguments.json', text.encode('utf-8'))
            found[task] = dict(source=dict(location, line_number_scope='TAIL_COMPLETE_LINES_ONLY'),
                               timestamp=obj['timestamp'], artifact=artifact)
    require(set(found) == set(targets), 'selected dispatch absent from allowed root tail')
    value = dict(root_tail_snapshot=tail_pin, selected_dispatches=found)
    save('dispatches.json', value)
    return value


def freeze_inputs():
    path = EVIDENCE / 'integration-01/native-02/source-freeze.json'
    raw = read(path)
    value = json.loads(raw)
    require(len(value['files']) <= 64, 'test freeze file bound')
    for item in value['files']:
        require(pin(Path(item['path'])) == item, 'current file differs from successful test freeze: ' + item['path'])
    require(pin(Path(value['native']['path'])) == value['native'], 'native differs from tested binary')
    return pin(path, raw), value


def measured_bundle(snapshot):
    require(len(snapshot['files']) <= 130, 'bundle member bound')
    result = []
    for name, expected in snapshot['files'].items():
        path = Path(snapshot['path']) / name
        actual = pin(path)
        require(actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'], 'bundle changed')
        result.append(actual)
    return dict(path=snapshot['path'], actual_files=result, aggregate_file_bytes=sum(item['bytes'] for item in result),
                scope='Actual regular-file byte lengths; directory metadata, OS and Python dependencies excluded.')


def helper_closure(freeze):
    available = {Path(item['path']).name: item for item in freeze['files'] if Path(item['path']).parent == WORK / 'install'}
    pending, seen = list(NEW_HELPERS), set()
    for _ in range(128):
        if not pending:
            break
        name = pending.pop()
        if name in seen:
            continue
        require(name in available, 'helper missing from successful test freeze')
        seen.add(name)
        for node in ast.walk(ast.parse(read(Path(available[name]['path'])))):
            modules = [node.module] if isinstance(node, ast.ImportFrom) else (
                [item.name for item in node.names] if isinstance(node, ast.Import) else [])
            for module in modules:
                candidate = (module or '').split('.')[0] + '.py'
                if candidate in available and candidate not in seen:
                    pending.append(candidate)
                    require(len(pending) <= 64, 'helper closure queue bound')
    require(not pending and len(seen) <= 64, 'helper closure traversal bound')
    new = [available[name] for name in NEW_HELPERS]
    all_helpers = [available[name] for name in sorted(seen)]
    return dict(additive_product_files=new, additive_product_bytes=sum(item['bytes'] for item in new),
        local_import_closure=all_helpers, local_import_closure_bytes=sum(item['bytes'] for item in all_helpers),
        scope='Static local imports from four additive entry modules, matched to successful test freeze; installed decoder, Python, standard library and dynamic environment are separate.')


def measured_fixture(name, freeze):
    base = WORK / 'examples/bound-evaluation-v1' / name
    records, original = [], b''
    for source_id in ('REQUIREMENT', 'EVIDENCE', 'HISTORY'):
        path = base / (source_id.lower() + '.txt')
        raw = read(path, 4096)
        records.append(dict(id=source_id, **pin(path, raw), concatenation_start=len(original),
                            concatenation_end=len(original) + len(raw)))
        original += raw
    plain = write(name + '-source-baseline.bin', original)
    compressed = gzip.compress(original, compresslevel=9, mtime=0)
    require(gzip.decompress(compressed) == original, 'gzip baseline round trip failed')
    gz = write(name + '-source-baseline.gz', compressed)
    package = EVIDENCE / 'integration-01/native-02' / (name + '-encoded')
    share, archive, lexicon = read(package / 'share.txt'), read(package / 'meaning.zip'), read(package / 'lexicon.md')
    with zipfile.ZipFile(package / 'meaning.zip', 'r', allowZip64=False) as source:
        members = source.infolist()
        require(len(members) == 5 and all(item.compress_type == zipfile.ZIP_STORED and item.file_size <= 131072
                                       for item in members), 'expected bounded stored ZIP')
        require(source.read('README.md') == lexicon, 'matched ZIP lexicon differs')
    contract = json.loads(read(EVIDENCE / 'integration-01/native-02' / (name + '-contract.json')))
    identity = 'STS1:' + share.decode('utf-8').split('STS1:', 1)[1].split()[0]
    require(contract['package_identity'] == identity, 'share differs from tested contract package')
    return dict(sources=records, original_source_bytes=len(original), typed_plan=pin(base / 'plan.json'),
        share=dict(pin(package / 'share.txt', share), unicode_codepoints=len(share.decode('utf-8'))),
        zip=pin(package / 'meaning.zip', archive), lexicon=pin(package / 'lexicon.md', lexicon), package_identity=identity,
        source_baseline=dict(plain=plain, gzip=gz, compression_level=9, mtime=0,
            definition='Source documents concatenated in REQUIREMENT,EVIDENCE,HISTORY order without separators; boundaries listed above. No semantic declarations or runtime dependencies included.'),
        match_scope='Source files match successful test freeze; share matches tested contract identity; ZIP README matches external lexicon. No new decoder execution performed.')


def measurements(runs):
    freeze_pin, freeze = freeze_inputs()
    value = dict(schema='transport/bound-evaluation-measurements/1', successful_test_freeze=freeze_pin,
        fixtures={name: measured_fixture(name, freeze) for name in ('reviews', 'library')},
        installed_decoder=measured_bundle(freeze['bundle']), native=pin(Path(freeze['native']['path'])),
        helpers=helper_closure(freeze), measurement_python=pin(Path(sys.executable).resolve()),
        compression=dict(format='standard gzip', implementation='Python gzip.compress', python_version=sys.version,
                         zlib_build_version=zlib.ZLIB_VERSION, zlib_runtime_version=zlib.ZLIB_RUNTIME_VERSION),
        model_runs={label: dict(observed_turn_contexts=run['observed_turn_contexts'],
            tool_call_names=run['tool_call_names'], last_token_count_info=run['last_token_count_info'],
            cost=run['cost'], observed_first_timestamp=run['observed_first_timestamp'],
            observed_last_timestamp=run['observed_last_timestamp']) for label, run in runs.items()},
        interpretation='Measured bytes and log-reported usage only. No net saving, token efficiency, amortization, billed-cost or timing advantage is claimed.',
        arithmetic_scope='Byte lengths and finite file-byte aggregation are instrument observations; no elapsed-time or amortized arithmetic was performed.')
    save('measurements.json', value)
    return value


def main():
    require(OUT.name == 'trace-01' and len(list(OUT.iterdir())) == 1, 'fresh trace directory containing only this script required')
    for node in ast.walk(ast.parse(read(Path(__file__)))):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            require(node.end_lineno - node.lineno + 1 <= 60, 'extractor function size bound')
    runs = {label: export_log(label, filename) for label, filename in LOGS.items()}
    dispatches(runs)
    measurements(runs)
    files = sorted(OUT.iterdir())
    require(len(files) <= 64 and all(path.is_file() and not path.is_symlink() for path in files), 'trace member bound')
    inventory = [pin(path) for path in files]
    require(sum(item['bytes'] for item in inventory) < 1048576 - 65536, 'trace aggregate budget')
    save('receipt.json', dict(schema='transport/selective-trace-export/1', status='EXPORTED_SCOPED', files=inventory,
        exported_bytes_before_receipt=sum(item['bytes'] for item in inventory), script=pin(Path(__file__)),
        privacy='Only allowed session fields, selected recipient tool lines, stripped final text and exact selected dispatch arguments exported; no instructions or reasoning exported.',
        time_scope='Timestamp snapshots only; active session logs may append after capture.',
        costs='UNKNOWN_NOT_REPORTED; token totals are host cumulative usage, not document-token or billing measurements.'))
    print(json.dumps(dict(status='EXPORTED_SCOPED', files=len(inventory), output=str(OUT))))


if __name__ == '__main__':
    main()
