import datetime
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import time

ROOT = Path('[HOST]/Work/semantic-transport-bound-evaluation-20261028')
OUT = Path(__file__).absolute().parent
NATIVE = ROOT / 'evaluation/bin/transport_bound_eval_native'
PIN = 'f13cd1c5ac3914a7a2efabb9548e9284c8a7196e84e3a7fd5e8ad4bf63160ac6'


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save_new(path, raw):
    with path.open('xb') as target:
        target.write(raw)
    return identity(path)


def run_case(name, args, expected_stdout=None):
    start = time.monotonic_ns()
    result = subprocess.run([str(NATIVE)] + args, capture_output=True, timeout=2)
    stdout = save_new(OUT / (name + '.stdout'), result.stdout)
    stderr = save_new(OUT / (name + '.stderr'), result.stderr)
    record = dict(name=name, elapsed_ns=time.monotonic_ns() - start,
                  exit_code=result.returncode, stdout=stdout, stderr=stderr)
    if expected_stdout is None:
        record['passed'] = result.returncode != 0 and not result.stdout and bool(result.stderr)
    else:
        record['passed'] = result.returncode == 0 and not result.stderr and result.stdout == expected_stdout
    return record


def frame(mask):
    return b'STV1' + struct.pack('>H', 2) + struct.pack('>BBHH', 1, mask, 0, 0) + struct.pack('>BBHH', 4, 0, 1, 0)


def main():
    assert identity(NATIVE)['sha256'] == PIN
    evidence = ROOT.parent.parent / 'unused'
    reference = Path('[HOST]/Projects/source-anchored-semantic-transport/evidence/bound-evaluation-v1/core-04')
    declared = json.loads((reference / 'source-manifest.json').read_bytes())
    for name, item in declared.items():
        assert identity(ROOT / name) == item, name
    records = []
    with tempfile.TemporaryDirectory(prefix='bound-review-core04-') as temporary:
        directory = Path(temporary)
        valid = directory / 'valid.stv1'
        valid.write_bytes(frame(4))
        os.mkfifo(directory / 'fifo')
        (directory / 'symlink').symlink_to(valid)
        (directory / 'dangling').symlink_to(directory / 'missing')
        (directory / 'empty').write_bytes(b'')
        (directory / 'truncated').write_bytes(frame(4)[:-1])
        (directory / 'oversize').write_bytes(bytes(1543))
        cases = [('fifo', directory / 'fifo'), ('directory', directory),
                 ('symlink', directory / 'symlink'), ('dangling', directory / 'dangling'),
                 ('device-null', Path('/dev/null')), ('device-zero', Path('/dev/zero')),
                 ('missing', directory / 'missing'), ('empty', directory / 'empty'),
                 ('truncated', directory / 'truncated'), ('oversize', directory / 'oversize')]
        for name, path in cases:
            records.append(run_case(name, [str(path)]))
        records.append(run_case('no-argument', []))
        records.append(run_case('extra-argument', [str(valid), 'extra']))
        states = [('UNRESOLVED', 'UNKNOWN'), ('UNRESOLVED', 'UNKNOWN'),
                  ('KNOWN_FALSE', 'VIOLATED'), ('UNRESOLVED', 'UNKNOWN'),
                  ('KNOWN_TRUE', 'SATISFIED'), ('UNRESOLVED', 'UNKNOWN'),
                  ('UNRESOLVED', 'UNKNOWN'), ('UNRESOLVED', 'UNKNOWN')]
        for mask, (truth, norm) in enumerate(states):
            path = directory / ('mask-' + str(mask))
            path.write_bytes(frame(mask))
            expected = ('NODE 1 FACT ' + truth + '\nNODE 2 NORM ' + norm + '\n').encode()
            records.append(run_case('mask-' + str(mask), [str(path)], expected))
    assert identity(NATIVE)['sha256'] == PIN
    report = dict(schema='transport/independent-io-review/1',
                  recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  native=identity(NATIVE), source_manifest=identity(reference / 'source-manifest.json'),
                  source_manifest_matches_current=True, controls=records,
                  status='TESTED' if all(item['passed'] for item in records) else 'FAILED',
                  original_fifo_observation='Original core-03 timed out on private FIFO; raw earlier output was session-only. Current FIFO stdout/stderr are retained separately.',
                  model_provenance=dict(requested_model='gpt-6.1-sol', requested_reasoning_effort='high', actual_runtime_model_metadata='NOT_EXPOSED_TO_REVIEWER'),
                  proof_rerun=False, whole_system_acceptance='NOT_DECLARED')
    raw = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode()
    receipt = save_new(OUT / 'core-04-independent-checks.json', raw)
    assert report['status'] == 'TESTED'
    print(json.dumps(dict(status=report['status'], receipt=receipt)))


if __name__ == '__main__':
    main()
