"""Only deterministic policy/data controls; never discover actual process controls."""
import json
import os
from pathlib import Path
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parent))
import clean_helpers as h
import test_quiescent as quiet
import test_clean_helpers as helper
import test_runtime_inventory as ipc
import test_review_repairs as repairs
import test_terminal_refusal as terminal
import test_directory_lifetime as lifetime

EXCLUDED_HELPER=('test_short_success','test_nonzero_failure','test_timeout_kill_reap',
                 'test_grandchild_group_reap','test_stream_overflow','test_storage_refusal')


def selected(case,excluded=()):
    names=unittest.defaultTestLoader.getTestCaseNames(case)
    h.need(len(names)<=32 and all(name in names for name in excluded),'fixed pure control list')
    return unittest.TestSuite(case(name) for name in names if name not in excluded)


def main():
    os.umask(0o077)
    mode='optimized' if sys.flags.optimize else 'normal'
    root=h.DESIGN/('pn-05' if mode=='normal' else 'po-05');root.mkdir(mode=0o700,exist_ok=False)
    modules=(quiet,helper,ipc,repairs,terminal,lifetime)
    for index,module in enumerate(modules):
        module.ROOT=root/str(index);module.ROOT.mkdir(mode=0o700)
    suite=unittest.TestSuite([selected(quiet.Pure),selected(helper.Controls,EXCLUDED_HELPER),
        selected(ipc.Controls,('test_real_owned_child_ipc_window',)),
        selected(repairs.Controls),selected(terminal.Control),selected(lifetime.Controls)])
    with (root/'unittest.stderr').open('x') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    h.write(root/'report.json',dict(status='PASS' if result.wasSuccessful() else 'FAILED',
        tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),
        skipped=len(result.skipped),mode=mode,actual_process_controls=0,
        excluded=dict(helper=list(EXCLUDED_HELPER),ipc=['test_real_owned_child_ipc_window'],
                      quiescent='Signals class never loaded'),
        source_files={p.name:h.pin(h.read(p)) for p in h.DESIGN.glob('*.py')}))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':raise SystemExit(main())
