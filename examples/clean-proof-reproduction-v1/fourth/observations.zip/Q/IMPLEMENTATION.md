Quiescent-observation implementation only. T4 remains ABSENT; no native build,
compiler, prover or model action occurred. T1/T2/T3 remain FAILED. Native
compatibility, clean proof and whole-system correctness remain UNPROVEN.

The runner pins the freshly created private leader PID/starttime/PGID/SID/UID,
reserves it unreaped through final signalling, verifies ownership before each
signal and never polls/waits/reaps during monitoring. At most eight complete
bounded proc/thread censuses seek two identical all-stopped/zombie observations;
limits are 8192 metadata entries per census, 256 group threads, 4096B stat data
and 0.5 seconds per pause within unchanged command/outer deadlines. Only transient
FileNotFoundError/ProcessLookupError may reacquire. Definitive ownership/session,
permission, malformed/oversized/count/deadline failures remain terminal.

No filesystem inventory runs on incomplete acquisition. A refused/expired scan
sends no SIGCONT. Successful scans resume only with renewed owner/headroom checks;
post-resume expiry is recorded FAILED_AFTER_RESUME. Cleanup signals end before
wait/reap. Unconfirmed ownership/cleanup remains FAILED, never a numeric-group
fallback. Final source/copy/canonical/tool/environment/strict inventory/lifetime
callbacks remain independent and final state is serialized after all callbacks.
Deadline guards cover per-entry walks, lstat before/after, ancestors, scandir,
readback and final lifetime publication. No complete/END is published after a
known deadline failure. All original strict source/summary/IPC/lifetime gates,
source/tool/canonical pins and 120/300/450s, 1GiB/256MiB limits remain.

Current source passed 63 pure controls normally and under -O. Seven inherited
process-creating controls are explicitly excluded. Exactly three actual tiny
Python-only signal controls passed on the exact first-control-version.zip source:
fork/thread private group resume; failed scan with no resume and TERM/KILL cleanup;
normal zombie/EOF cleanup without further signals. Later timing/definitive-census
repairs have PURE qualification only; no current-source signal re-execution is
claimed or authorized. Raw failures (mock-clock fixture and too-long fixture
socket path), source versions, reports and outputs remain preserved byte-exact.

fixture-data.zip/index/receipt preserve completed synthetic regular bytes and
metadata after full original/archive/copy readback under the separately pinned
compaction grant. They do NOT preserve active kernel/socket state. Full selected
stat/readback/removal receipts remain in the recorded staging path. Baseline
M v1 is preserved as inert indexed data; source-diff.zip contains the exact diff.
Metadata quiescence is observed, conditional on trusted OS/private group/no
external writers or group escape. It is not an atomic filesystem snapshot,
hostile same-uid isolation, authenticated process provenance or hard realtime.

Launch still requires independent implementation PASS, a separate current root
launch receipt and held hash, and 450s headroom before the unchanged reviewed
22:29 UTC ceiling. No automatic retry or authority from historical approvals.
The command after separate admission only is:
/usr/bin/python3 -I -S -B -Werror /dev/shm/semantic-transport-proof-quiescent-design-20261029/clean_driver.py --launch-admission OWNER_JSON --expect-launch-sha256 HELD_SHA256
