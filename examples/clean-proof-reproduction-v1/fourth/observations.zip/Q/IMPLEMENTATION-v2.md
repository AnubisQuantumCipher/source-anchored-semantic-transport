V2 remains pending independent review and separate native admission. T4 is absent.
Owner uncertainty is terminal at every reserved leader process/thread read. Only
non-owner disappearance may reacquire. The original phase clock starts before
Popen and is never reset after capture; expired capture cannot enter monitoring.
Cleanup-only identity capture targets only the still-unreaped private Popen leader.
Current 18 quiescent pure controls passed normally and under -O. No new actual
process/signal controls ran. The three earlier actual controls have exact separate
source pins; current-source signal compatibility remains UNPROVEN.
65/65 prior pure logic PASS did exceed Q's 1MiB design cap: measured1054052 against
1048576. That aggregate run remains FAILED_RESOURCE_BOUND forever. Separately
admitted, fully verified inert fixture recovery restored the workspace under the
unchanged cap. This is a later readback, never retroactive compliance or a waiver.
V1 source/index/report/raw and every failure are retained. Native/proof/source/
canonical/tool/wall/task resource guarantees remain unchanged. No further tests,
code changes, signals or native action are authorized by these artifacts.
