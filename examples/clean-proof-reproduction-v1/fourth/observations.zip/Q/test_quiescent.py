"""Bounded pure controls plus exactly three admitted Python-only signal groups."""
import ast
from contextlib import ExitStack
import io
import json
import os
from pathlib import Path
import signal
import sys
import time
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import clean_helpers as h
import clean_process as process
import quiescent as q
import runtime_inventory as r

ROOT=h.DESIGN/'quiescent-tests-01'
OWNER=dict(pid=12345,tid=12345,pgid=12345,sid=12345,starttime=99,uid=os.getuid())


def row(state='T',tid=12345):
    return dict(OWNER,tid=tid,state=state)


def scan(records, complete=True):
    return dict(records=records,complete=complete,metadata_entries=2,
                attempted_path='/proc/fixed/stat',known='UNKNOWN')


class Pure(unittest.TestCase):
    def acquire(self, records):
        state=q.new_state(OWNER); calls=[]
        def fixed(_owner,current):
            current.update(scan(records.pop(0) if records else [row()]))
            return current
        with patch.object(q,'send',lambda *_:calls.append('STOP')), \
             patch.object(q,'census',fixed):
            result=q.acquire(OWNER,state,time.monotonic()+1)
        return result,state,calls

    def test_stable_multimember_thread_census(self):
        rows=[row(),row(tid=12346),dict(row(tid=12347),pid=12347)]
        current,state,calls=self.acquire([rows,rows])
        self.assertEqual(current['records'],rows)
        self.assertEqual(state['complete_censuses'],2)
        self.assertEqual(calls,['STOP','STOP'])

    def test_running_thread_and_membership_change_reacquire(self):
        stopped=[row(),row(tid=12346)]
        current,state,calls=self.acquire([[row(),row('D',12346)],[row()],stopped,stopped])
        self.assertEqual(current['records'],stopped)
        self.assertEqual(len(calls),4)
        self.assertEqual(state['complete_censuses'],4)

    def test_no_convergence_fixed_eight(self):
        state=q.new_state(OWNER);calls=[]
        def fixed(_owner,current): current.update(scan([row('R')]))
        with patch.object(q,'send',lambda *_:calls.append('STOP')),patch.object(q,'census',fixed):
            with self.assertRaisesRegex(ValueError,'round bound'):
                q.acquire(OWNER,state,time.monotonic()+1)
        self.assertEqual(len(calls),8)

    def test_incomplete_never_complete_or_inventory(self):
        for error in (FileNotFoundError('ENOENT'),PermissionError('denied'),
                      ValueError('malformed'),ValueError('proc metadata entry bound')):
            state=q.new_state(OWNER);called=[]
            with patch.object(q,'send',lambda *_:None), \
                 patch.object(q,'census',side_effect=error):
                with self.assertRaises((OSError,ValueError)):
                    q.observe(OWNER,state,time.monotonic()+1,lambda *_:called.append('scan'))
            self.assertEqual(called,[])
            self.assertEqual(state['incomplete_censuses'],
                             8 if isinstance(error,FileNotFoundError) else 1)
            self.assertFalse(state['failed_census']['complete'])
            self.assertEqual(state['status'],'FAILED_NO_RESUME')

    def test_owner_fields_and_supervisor_rejected_before_signal(self):
        for key in ('pid','tid','pgid','sid','starttime','uid'):
            changed=dict(row());changed[key]+=1
            with patch.object(q,'task',return_value=changed),patch.object(q.os,'killpg') as send:
                with self.assertRaises(ValueError):q.send(OWNER,signal.SIGSTOP,time.monotonic()+1)
                send.assert_not_called()
        with patch.object(q,'task',return_value=row()),patch.object(q.os,'getpgrp',return_value=12345), \
             patch.object(q.os,'killpg') as send:
            with self.assertRaises(ValueError):q.send(OWNER,signal.SIGSTOP,time.monotonic()+1)
            send.assert_not_called()

    def test_malformed_oversized_metadata_and_counts(self):
        for raw in (b'x',b'12345 malformed) T 1',b'x'*4097,b'9 (x) T '+b'1 '*20):
            with self.assertRaises((ValueError,UnicodeError)):q.parse(raw,12345,os.getuid())
        current=q.context(time.monotonic()+1);current['metadata_entries']=8192
        with self.assertRaisesRegex(ValueError,'entry bound'):q.tick(current,Path('/proc/fixed'))
        current=q.context(time.monotonic()-1)
        with self.assertRaisesRegex(ValueError,'deadline'):q.tick(current,Path('/proc/fixed'))

    def test_failed_scan_no_resume_and_deadline(self):
        for failure in ('scan','expired'):
            state=q.new_state(OWNER);signals=[];current=scan([row()])
            def callback(*_):
                if failure=='scan':raise FileNotFoundError('listed entry missing')
                return {}
            times=[0.0,0.0,1.0] if failure=='expired' else None
            with ExitStack() as stack:
                stack.enter_context(patch.object(q,'acquire',return_value=current))
                stack.enter_context(patch.object(q,'verify',return_value=row()))
                stack.enter_context(patch.object(q,'send',lambda _,value,*__:signals.append(value)))
                if times:stack.enter_context(patch.object(q.time,'monotonic',side_effect=times))
                with self.assertRaises((OSError,ValueError)):
                    q.observe(OWNER,state,2.0 if times else time.monotonic()+1,callback)
            self.assertNotIn(signal.SIGCONT,signals)
            self.assertEqual(state['status'],'FAILED_NO_RESUME')

    def test_success_resume_and_zombie_no_resume(self):
        for status in ('T','Z'):
            state=q.new_state(OWNER);signals=[]
            with patch.object(q,'acquire',return_value=scan([row(status)])), \
                 patch.object(q,'verify',return_value=row(status)), \
                 patch.object(q,'send',lambda _,value,*__:signals.append(value)):
                observed,zombie=q.observe(OWNER,state,time.monotonic()+1,lambda *_:dict(bytes=1))
            self.assertEqual(observed,dict(bytes=1))
            self.assertEqual(zombie,status=='Z')
            self.assertEqual(signals,[] if status=='Z' else [signal.SIGCONT])

    def test_signal_errors_and_cleanup_order_no_poll(self):
        state=q.new_state(OWNER)
        with patch.object(q,'send',side_effect=OSError('fixed SIGSTOP refusal')):
            with self.assertRaises(OSError):q.observe(OWNER,state,time.monotonic()+1,lambda *_:{})
        self.assertEqual(state['status'],'FAILED_NO_RESUME')
        events=[]
        class Child:
            pid=12345;returncode=-9
            def wait(self,**_):events.append('WAIT')
            def poll(self):raise AssertionError('poll prohibited')
        with patch.object(q,'verify',return_value=row()), \
             patch.object(q,'send',lambda _,value,*__:events.append(signal.Signals(value).name)), \
             patch.object(q,'group_absent',return_value=True), \
             patch.object(process,'reap_group',lambda _:events.append('REAP')):
            result=process.stop(Child(),OWNER,False)
        self.assertEqual(events,['SIGTERM','SIGKILL','WAIT','REAP'])
        self.assertTrue(result['final_signalling_complete'])

    def test_thread_limit_and_inventory_deadline(self):
        expected=dict(OWNER)
        current=q.context(time.monotonic()+1)
        def fake_task(pid,ctx,tid=None):return dict(row(tid=pid if tid is None else tid))
        def fake_names(path,_ctx):return ['12345'] if path==q.PROC else [str(x) for x in range(1,258)]
        with patch.object(q,'verify',return_value=row()),patch.object(q,'task',fake_task), \
             patch.object(q,'names',fake_names):
            with self.assertRaisesRegex(ValueError,'thread bound'):q.census(expected,current)
        self.assertEqual(len(current['records']),256)
        state=r.new_state();state['quiescent_deadline']=time.monotonic()-1
        with self.assertRaisesRegex(ValueError,'inventory pause/wall deadline'):
            r.runtime_inventory(ROOT,state,'BUILD',True)
        self.assertEqual(state['observation']['status'],'ERROR')

    def test_late_deadline_prevents_lifetime_commit(self):
        state=r.new_state()
        for path in ('.','tmp','tmp/ended'):
            r.bind_directory(state,dict(path=path,st_dev=1,st_ino=len(path),
                uid=os.getuid(),mode=0o40700))
        work=r.lifetime.begin(state,'BUILD',True)
        rows=[dict(path=path,type='S_IFDIR') for path in ('.','tmp')]
        with patch.object(r,'read_directory'), \
             patch.object(r,'observation_deadline',side_effect=[None,None,ValueError('late deadline')]), \
             patch.object(r.lifetime,'commit') as commit:
            with self.assertRaisesRegex(ValueError,'late deadline'):
                r.complete_observation(Path('/fixed'),state,work,rows,'BUILD')
            commit.assert_not_called()
        self.assertEqual(state['lifetimes']['tmp/ended']['status'],'ACTIVE')

    def test_directory_lstat_deadline_before_and_after(self):
        actual=Path(__file__).parent.lstat()
        for times,known in (([2.0],False),([0.0,2.0],True)):
            state=r.new_state();state['quiescent_deadline']=1.0
            with patch.object(r.time,'monotonic',side_effect=times), \
                 patch.object(Path,'lstat',return_value=actual) as observed:
                with self.assertRaisesRegex(ValueError,'deadline'):
                    r.read_directory(Path('/fixed/tmp'),Path('/fixed'),state,'BUILD',1)
            self.assertEqual(observed.call_count,1 if known else 0)
            self.assertEqual(state['diagnostic_candidate']['path'],'tmp')
            self.assertEqual(state['diagnostic_candidate']['type'],'S_IFDIR' if known else 'UNKNOWN')
            self.assertEqual(state['bindings'],{})

    def test_ancestor_and_scandir_deadline_guards(self):
        actual=Path(__file__).parent.lstat();state=r.new_state();state['quiescent_deadline']=1.0
        with patch.object(r.time,'monotonic',side_effect=[0.0,0.0,2.0]), \
             patch.object(Path,'lstat',return_value=actual):
            with self.assertRaisesRegex(ValueError,'deadline'):
                r.ancestors(state,Path('/fixed/tmp/pipe'),Path('/fixed'),'BUILD',1)
        self.assertEqual(state['diagnostic_candidate']['path'],'tmp')
        self.assertEqual(state['diagnostic_candidate']['type'],'UNKNOWN')
        pending=[]
        class Entries:
            def __enter__(self):return iter([type('Entry',(),dict(path='/fixed/file'))()])
            def __exit__(self,*_):return False
        with patch.object(r.os,'scandir',return_value=Entries()), \
             patch.object(r.time,'monotonic',side_effect=[0.0,2.0]):
            with self.assertRaisesRegex(ValueError,'deadline'):
                r.children(Path('/fixed'),pending,[],state)
        self.assertEqual(pending,[])

    def test_end_construction_cannot_publish_after_expiry(self):
        state=r.new_state()
        r.bind_directory(state,dict(path='tmp/end',st_dev=1,st_ino=3,
            uid=os.getuid(),mode=0o40700))
        work=r.lifetime.begin(state,'BUILD',True);work['quiescent_deadline']=1.0
        with patch.object(r.lifetime.time,'monotonic',side_effect=[0.0,2.0]):
            with self.assertRaisesRegex(ValueError,'publication deadline'):
                r.lifetime.commit(state,work,['tmp/end'])
        self.assertEqual(state['lifetimes']['tmp/end']['status'],'ACTIVE')
        self.assertNotIn('observation',state)
        self.assertEqual(work['lifetimes']['tmp/end']['status'],'ENDED')

    def test_owner_loss_cannot_reacquire_after_good_read(self):
        for error in (FileNotFoundError('fixed owner vanished'),ProcessLookupError('fixed owner lost')):
            state=q.new_state(OWNER);called=[]
            with patch.object(q,'send',return_value=None), \
                 patch.object(q,'task',side_effect=[error,row()]) as observed:
                with self.assertRaisesRegex(ValueError,'reserved leader read uncertainty'):
                    q.observe(OWNER,state,time.monotonic()+1,lambda *_:called.append('inventory'))
            self.assertEqual(observed.call_count,1)
            self.assertEqual(called,[])
            self.assertEqual(state['incomplete_censuses'],1)
            self.assertEqual(state['status'],'FAILED_NO_RESUME')
            self.assertIn('reserved leader read uncertainty',state['failed_census']['reason'])

    def test_initial_capture_delay_cannot_reset_phase_deadline(self):
        with patch.object(process.time,'monotonic',return_value=10.0):
            started,_wall,deadline=process.phase_start(3,100.0)
        self.assertEqual(started,10.0)
        self.assertEqual(deadline,13.0)
        captured=[]
        def delayed(_pid,current):captured.append(current['deadline']);return row()
        with patch.object(q.time,'monotonic',side_effect=[10.0,15.0]), \
             patch.object(q,'task',side_effect=delayed):
            with self.assertRaisesRegex(ValueError,'owner capture phase/wall deadline'):
                q.owner(12345,deadline)
        self.assertLessEqual(captured[0],deadline)
        with patch.object(process.time,'monotonic',return_value=15.0), \
             patch.object(process,'drain') as drain,patch.object(q,'observe') as observe:
            with self.assertRaisesRegex(ValueError,'process wall/outer deadline'):
                process.monitor(None,OWNER,None,None,None,deadline,1,r.new_state(),'BUILD')
            drain.assert_not_called();observe.assert_not_called()

    def test_generic_owner_process_and_thread_loss_are_terminal(self):
        for thread in (False,True):
            for error in (FileNotFoundError('generic owner missing'),ProcessLookupError('generic owner lost')):
                state=q.new_state(OWNER);called=[]
                values=[row(),error,row()] if thread else [error,row()]
                with patch.object(q,'send',return_value=None),patch.object(q,'verify',return_value=row()), \
                     patch.object(q,'names',return_value=['12345']), \
                     patch.object(q,'task',side_effect=values) as observed:
                    with self.assertRaisesRegex(ValueError,'reserved leader read uncertainty'):
                        q.observe(OWNER,state,time.monotonic()+1,lambda *_:called.append('inventory'))
                self.assertEqual(observed.call_count,2 if thread else 1)
                self.assertEqual(called,[])
                self.assertEqual(state['incomplete_censuses'],1)
                self.assertEqual(state['status'],'FAILED_NO_RESUME')
        with patch.object(q,'task',side_effect=FileNotFoundError('non-owner vanished')):
            with self.assertRaises(FileNotFoundError):
                q.member_task(OWNER,12346,q.context(time.monotonic()+1))

    def test_no_monitor_reap_and_function_bounds(self):
        raw=h.read(h.DESIGN/'clean_process.py').decode();tree=ast.parse(raw)
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='monitor')
        segment=ast.get_source_segment(raw,node)
        for token in ('.poll(','.wait(','.waitpid(', 'reap_group('):self.assertNotIn(token,segment)
        for p in h.DESIGN.glob('*.py'):
            source=h.read(p);compile(source,str(p),'exec',dont_inherit=True)
            for function in ast.walk(ast.parse(source)):
                if isinstance(function,ast.FunctionDef):
                    self.assertLessEqual(function.end_lineno-function.lineno+1,60,p.name+':'+function.name)


class Signals(unittest.TestCase):
    def run_child(self,name,script,fail=False):
        root=ROOT/name;(root/'tmp').mkdir(mode=0o700,parents=True)
        state=r.new_state();command=['/usr/bin/python3','-I','-S','-B','-c',script]
        if fail:
            with patch.object(process,'runtime_inventory',side_effect=FileNotFoundError('fixed refused scan')):
                result=process.run(command,root,root,h.environment(root),'build',3,time.monotonic()+3,runtime_state=state)
        else:
            result=process.run(command,root,root,h.environment(root),'build',3,time.monotonic()+3,runtime_state=state)
        h.write(root/'signal-result.json',result)
        self.assertTrue(result['terminal_group_absent'],result)
        return result

    def test_signal_1_multithread_private_group(self):
        script='import os,threading,time\npid=os.fork()\nthreads=[threading.Thread(target=time.sleep,args=(0.15,)) for _ in range(2)]\nfor t in threads:t.start()\nfor t in threads:t.join()\nif pid:os.waitpid(pid,0)\nprint("fixed-done")'
        result=self.run_child('signal-1',script)
        self.assertEqual(result['status'],'SUCCESS',result)
        self.assertGreater(result['runtime_inventory']['quiescent']['resumes'],0)

    def test_signal_2_refused_scan_no_resume(self):
        result=self.run_child('signal-2','import time;time.sleep(2)',True)
        self.assertEqual(result['status'],'FAILED')
        self.assertEqual(result['runtime_inventory']['quiescent']['resumes'],0)
        self.assertEqual(result['cleanup_signals'],['SIGTERM','SIGKILL'])

    def test_signal_3_normal_zombie(self):
        result=self.run_child('signal-3','print("fixed-normal")')
        self.assertEqual(result['status'],'SUCCESS',result)
        self.assertEqual(result['cleanup_signals'],[])
        self.assertTrue(result['normal_terminal'])


def main():
    os.umask(0o077);ROOT.mkdir(mode=0o700,exist_ok=False)
    suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(Pure),
                            unittest.defaultTestLoader.loadTestsFromTestCase(Signals)])
    with (ROOT/'unittest.stderr').open('x') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    h.write(ROOT/'report.json',dict(status='PASS' if result.wasSuccessful() else 'FAILED',
        tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),
        skipped=len(result.skipped),actual_signal_controls=3,native_execution='NOT_RUN',
        source_files={p.name:h.pin(h.read(p)) for p in h.DESIGN.glob('*.py')}))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':raise SystemExit(main())
