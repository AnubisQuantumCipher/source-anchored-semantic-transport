"""Finite process-group monitoring with sampled storage refusal thresholds."""
import ctypes
import os
import selectors
import signal
import subprocess
import time

from clean_helpers import CAP, DESIGN, STREAM_CAP, inventory, need, pin, read
from runtime_inventory import exported, new_state, runtime_inventory, strict_readback
import quiescent as quiet


def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    need(libc.prctl(36, 1, 0, 0, 0) == 0, 'subreaper unavailable')


def group_alive(group):
    return not quiet.group_absent(group)


def reap_group(group):
    for _ in range(256):
        try:
            child, _ = os.waitpid(-group, os.WNOHANG)
        except ChildProcessError:
            return
        if child == 0:
            return
    raise ValueError('reap count bound')


def stop(proc, owner, normal):
    signals = []
    quiet.verify(owner, time.monotonic() + 0.5)
    if not normal:
        for value in (signal.SIGTERM, signal.SIGKILL):
            quiet.send(owner, value, time.monotonic() + 0.5)
            signals.append(signal.Signals(value).name)
    # No future group signal is permitted beyond this point; reserve is released now.
    proc.wait(timeout=2)
    for _ in range(40):
        reap_group(proc.pid)
        if quiet.group_absent(proc.pid):
            return dict(terminal_group_absent=True, returncode=proc.returncode,
                        cleanup_signals=signals, final_signalling_complete=True)
        time.sleep(0.05)
    raise ValueError('owned group survives stop/reap')


def cleanup(proc, owner, normal, task, state, cap):
    result = stop(proc, owner, normal)
    state.pop('quiescent_deadline', None)
    try:
        strict_readback(task, state, cap)
    except (OSError, ValueError) as error:
        result.update(status='FAILED', final_inventory_failure=str(error))
    return result


def drain(selector, outputs, sizes):
    for key, _ in selector.select(timeout=0.05):
        try:
            block = os.read(key.fd, 65536)
        except BlockingIOError:
            continue
        if not block:
            selector.unregister(key.fileobj)
            continue
        need(outputs[key.data].write(block) == len(block), 'stream short write')
        outputs[key.data].flush()
        sizes[key.data] += len(block)
        need(sizes[key.data] <= STREAM_CAP, 'captured stream bound')


def monitor(proc, owner, task, selector, outputs, deadline, cap, state, phase):
    peak, sizes = 0, dict(stdout=0, stderr=0)
    def inventory_paused(pause_end, active):
        state['quiescent_deadline'] = pause_end
        try:
            return runtime_inventory(task, state, phase, active, cap)
        finally:
            state.pop('quiescent_deadline', None)
    for _ in range(10000):
        need(time.monotonic() < deadline, 'process wall/outer deadline')
        drain(selector, outputs, sizes)
        need(time.monotonic() < deadline, 'process wall/outer deadline')
        observed, all_zombie = quiet.observe(owner, state['quiescent'], deadline,
                                             inventory_paused)
        peak = max(peak, observed['bytes'])
        need(time.monotonic() < deadline, 'post-observation process deadline')
        if all_zombie and not selector.get_map():
            return dict(peak_bytes=peak, stream_bytes=sizes, normal_terminal=True)
    raise ValueError('monitor iteration bound')


def phase_start(duration, outer_deadline):
    started = time.monotonic()
    return started, time.time_ns(), min(started + duration, outer_deadline)


def cleanup_owner(proc, owner, result):
    if owner is None:
        # The exact Popen leader is still unreaped; identity is for termination only.
        owner = quiet.owner(proc.pid)
        result['cleanup_owner'] = owner
    return owner


def run(command, task, cwd, env, label, duration, outer_deadline, cap=CAP, runtime_state=None):
    need(len(command) <= 24 and duration > 0, 'command bound')
    runtime_state = new_state() if runtime_state is None else runtime_state
    subreaper()
    argv = ['/usr/bin/python3', '-I', '-S', '-B', '-Werror',
            str(DESIGN / 'clean_child.py')] + command
    started, wall, deadline = phase_start(duration, outer_deadline)
    outputs, proc, result, owner = {}, None, {}, None
    selector = selectors.DefaultSelector()
    try:
        for name in ('stdout', 'stderr'):
            outputs[name] = (task / (label + '.' + name)).open('xb')
        proc = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                start_new_session=True, close_fds=True)
        owner = quiet.owner(proc.pid, deadline)
        runtime_state['quiescent'] = quiet.new_state(owner)
        result.update(pid=proc.pid, process_group=proc.pid, owner=owner)
        for name in ('stdout', 'stderr'):
            stream = getattr(proc, name)
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)
        result.update(monitor(proc, owner, task, selector, outputs, deadline,
                              cap, runtime_state, label.upper()))
        result['status'] = 'MONITOR_COMPLETE'
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        result.update(status='FAILED', reason=str(error))
    finally:
        if proc is not None:
            try:
                owner = cleanup_owner(proc, owner, result)
                result.update(cleanup(proc, owner, result.get('normal_terminal', False),
                                      task, runtime_state, cap))
                if result.get('status') == 'MONITOR_COMPLETE':
                    result['status'] = 'SUCCESS' if proc.returncode == 0 else 'FAILED_PROCESS'
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                result.update(status='FAILED', terminal_group_absent=False,
                              cleanup_failure=str(error))
            for name in ('stdout', 'stderr'):
                getattr(proc, name).close()
        selector.close()
        for stream in outputs.values():
            stream.close()
    result['runtime_inventory'] = exported(runtime_state)
    result.update(argv=argv, command=command, cwd=str(cwd), environment=env,
                  wall_start_ns=wall, elapsed_ns=int((time.monotonic()-started)*1e9),
                  capture_complete=result.get('status') in ('SUCCESS', 'FAILED_PROCESS'))
    for name in ('stdout', 'stderr'):
        result[name] = pin(read(task / (label + '.' + name), STREAM_CAP + 65536))
    return result
