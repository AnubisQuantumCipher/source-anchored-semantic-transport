"""Finite process-group monitoring with sampled storage refusal thresholds."""
import ctypes
import os
import selectors
import signal
import subprocess
import time

from clean_helpers import CAP, DESIGN, STREAM_CAP, inventory, need, pin, read
from runtime_inventory import exported, new_state, runtime_inventory, strict_readback


def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    need(libc.prctl(36, 1, 0, 0, 0) == 0, 'subreaper unavailable')


def group_alive(group):
    try:
        os.killpg(group, 0)
        return True
    except ProcessLookupError:
        return False


def signal_group(group, value):
    try:
        os.killpg(group, value)
    except ProcessLookupError:
        pass


def reap_group(group):
    for _ in range(256):
        try:
            child, _ = os.waitpid(-group, os.WNOHANG)
        except ChildProcessError:
            return
        if child == 0:
            return
    raise ValueError('reap count bound')


def stop(proc):
    if proc.poll() is not None:
        reap_group(proc.pid)
        if not group_alive(proc.pid):
            return dict(terminal_group_absent=True, returncode=proc.returncode,
                        cleanup_signals=[])
    signal_group(proc.pid, signal.SIGTERM)
    try:
        proc.wait(timeout=1)
    except subprocess.TimeoutExpired:
        pass
    signal_group(proc.pid, signal.SIGKILL)
    proc.wait(timeout=2)
    for _ in range(40):
        reap_group(proc.pid)
        if not group_alive(proc.pid):
            return dict(terminal_group_absent=True, returncode=proc.returncode,
                        cleanup_signals=['SIGTERM', 'SIGKILL'])
        time.sleep(0.05)
    raise ValueError('owned group survives stop/reap')


def cleanup(proc, task, state, cap):
    result = stop(proc)
    try:
        strict_readback(task, state, cap)
    except (OSError, ValueError) as error:
        result.update(status='FAILED', final_inventory_failure=str(error))
    return result


def drain(selector, outputs, sizes):
    for key, _ in selector.select(timeout=0.05):
        try:
            block = os.read(key.fd, 65536)
        except BlockingIOError:
            continue
        if not block:
            selector.unregister(key.fileobj)
            continue
        need(outputs[key.data].write(block) == len(block), 'stream short write')
        outputs[key.data].flush()
        sizes[key.data] += len(block)
        need(sizes[key.data] <= STREAM_CAP, 'captured stream bound')


def monitor(proc, task, selector, outputs, duration, outer_deadline, cap, state, phase):
    deadline = min(time.monotonic() + duration, outer_deadline)
    peak, sizes = 0, dict(stdout=0, stderr=0)
    for _ in range(10000):
        drain(selector, outputs, sizes)
        observed = runtime_inventory(task, state, phase,
            proc.poll() is None and group_alive(proc.pid), cap)
        peak = max(peak, observed['bytes'])
        if proc.poll() is not None and not selector.get_map():
            return dict(peak_bytes=peak, stream_bytes=sizes)
        need(time.monotonic() < deadline, 'process wall/outer deadline')
    raise ValueError('monitor iteration bound')


def run(command, task, cwd, env, label, duration, outer_deadline, cap=CAP, runtime_state=None):
    need(len(command) <= 24 and duration > 0, 'command bound')
    runtime_state = new_state() if runtime_state is None else runtime_state
    subreaper()
    argv = ['/usr/bin/python3', '-I', '-S', '-B', '-Werror',
            str(DESIGN / 'clean_child.py')] + command
    started, wall = time.monotonic(), time.time_ns()
    outputs, proc, result = {}, None, {}
    selector = selectors.DefaultSelector()
    try:
        for name in ('stdout', 'stderr'):
            outputs[name] = (task / (label + '.' + name)).open('xb')
        proc = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                start_new_session=True, close_fds=True)
        result.update(pid=proc.pid, process_group=proc.pid)
        for name in ('stdout', 'stderr'):
            stream = getattr(proc, name)
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, name)
        result.update(monitor(proc, task, selector, outputs, duration,
                              outer_deadline, cap, runtime_state, label.upper()))
        proc.wait(timeout=1)
        reap_group(proc.pid)
        need(not group_alive(proc.pid), 'lingering owned process group')
        result['status'] = 'SUCCESS' if proc.returncode == 0 else 'FAILED_PROCESS'
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        result.update(status='FAILED', reason=str(error))
    finally:
        if proc is not None:
            try:
                result.update(cleanup(proc, task, runtime_state, cap))
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                result.update(status='FAILED', terminal_group_absent=False,
                              cleanup_failure=str(error))
            for name in ('stdout', 'stderr'):
                getattr(proc, name).close()
        selector.close()
        for stream in outputs.values():
            stream.close()
    result['runtime_inventory'] = exported(runtime_state)
    result.update(argv=argv, command=command, cwd=str(cwd), environment=env,
                  wall_start_ns=wall, elapsed_ns=int((time.monotonic()-started)*1e9),
                  capture_complete=result.get('status') in ('SUCCESS', 'FAILED_PROCESS'))
    for name in ('stdout', 'stderr'):
        result[name] = pin(read(task / (label + '.' + name), STREAM_CAP + 65536))
    return result
