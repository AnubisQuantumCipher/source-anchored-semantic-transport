"""Fixed synthetic controls only. Never launches a compiler or prover."""
import ast
import json
import os
from pathlib import Path
import sys
import stat
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import clean_driver as driver
import clean_helpers as helper
import clean_process as process

ROOT = helper.DESIGN / 'helper-tests-03'


class Controls(unittest.TestCase):
    def folder(self, name):
        path = ROOT / name
        path.mkdir(mode=0o700)
        return path

    def test_summary_positive(self):
        oracle = helper.load(helper.DESIGN / 'proof-oracle.json')
        raw = ('\n'.join([oracle['expected_total_row']] +
                         oracle['expected_unit_rows']) + '\n').encode()
        self.assertEqual(helper.summary(raw, oracle)['status'], 'PROOF_ORACLE_PASS')

    def test_summary_negative_controls(self):
        oracle = helper.load(helper.DESIGN / 'proof-oracle.json')
        lines = [oracle['expected_total_row']] + oracle['expected_unit_rows']
        cases = [lines[1:], lines[:-1], lines + [lines[1]],
                 [lines[0].replace('1368', '1367')] + lines[1:],
                 [lines[0].replace('.          .', '.          1')] + lines[1:],
                 lines + ['1 warnings'], lines + ['warning: rejected'],
                 lines + ['1 pragma Assume statements'], lines + [lines[0]],
                 lines + ['1 unproved'], lines + ['Justified: 1']]
        for lines in cases:
            with self.subTest(lines=lines[-1]), self.assertRaises(ValueError):
                helper.summary(('\n'.join(lines) + '\n').encode(), oracle)

    def test_duplicate_json(self):
        path = self.folder('json') / 'duplicate.json'
        path.write_bytes(b'{"x":1,"x":2}')
        with self.assertRaises(ValueError):
            helper.load(path)

    def test_read_bound_and_symlink(self):
        path = self.folder('reads') / 'file'
        path.write_bytes(b'abc')
        self.assertEqual(helper.read(path), b'abc')
        with self.assertRaises(ValueError):
            helper.read(path, 2)
        alias = path.with_name('alias')
        alias.symlink_to(path)
        with self.assertRaises(OSError):
            helper.read(alias)

    def test_inventory_bounds(self):
        folder = self.folder('inventory')
        (folder / 'data').write_bytes(b'abc')
        self.assertEqual(len(helper.inventory(folder)['entries']), 2)
        with self.assertRaises(ValueError):
            helper.inventory(folder, cap=1)
        with self.assertRaises(ValueError):
            helper.inventory(folder, maximum=1)
        (folder / 'alias').symlink_to(folder / 'data')
        with self.assertRaises(ValueError):
            helper.inventory(folder)

    def test_hash_tamper_and_cap(self):
        path = self.folder('hash') / 'source'
        path.write_bytes(b'first')
        first = helper.file_pin(path)
        path.write_bytes(b'other')
        self.assertNotEqual(first, helper.file_pin(path))
        with self.assertRaises(ValueError):
            helper.file_pin(path, cap=1)

    def test_environment_removes_overrides(self):
        malicious = dict(HOME='/home/sicarii', WHY3CONFIG='/old/session',
                         LD_PRELOAD='/old/library', GPR_PROJECT_PATH='/old/gpr')
        with patch.dict(os.environ, malicious, clear=True):
            env = helper.environment(ROOT)
        self.assertNotIn('WHY3CONFIG', env)
        self.assertNotIn('LD_PRELOAD', env)
        self.assertNotIn('/old/gpr', env['GPR_PROJECT_PATH'])
        self.assertEqual(env['HOME'], '/home/sicarii')
        self.assertEqual(env['TMPDIR'], str(ROOT / 'tmp'))

    def test_fixed_commands(self):
        build, proof = driver.commands()
        self.assertEqual(build[:6], ['/usr/bin/timeout', '120',
            str(helper.BUILD / 'bin/gprbuild'), '-p', '-P', 'evaluation/transport_core.gpr'])
        self.assertIn('-U', proof)
        self.assertIn('--timeout=1', proof)
        self.assertIn('--prover=z3', proof)
        self.assertEqual(proof.count('-j1'), 1)
        self.assertNotIn('-f', proof)
        self.assertNotIn('--clean', proof)

    def test_source_pin_bypass_and_extra(self):
        folder = self.folder('source-fixture')
        for name in ('evaluation', 'evaluation/src', 'src'):
            (folder / name).mkdir(mode=0o700)
        members = {'src/fixed.ads': b'package Fixed is end Fixed;\n',
                   'evaluation/transport_core.gpr': b'project Fixed is end Fixed;\n'}
        manifest = dict(items=[])
        for name, raw in members.items():
            (folder / name).write_bytes(raw)
            manifest['items'].append(dict(path=name, **helper.pin(raw)))
        helper.source_check(folder, manifest)
        (folder / 'src/fixed.ads').write_bytes(b'changed\n')
        with self.assertRaises(ValueError):
            helper.source_check(folder, manifest)
        (folder / 'src/fixed.ads').write_bytes(members['src/fixed.ads'])
        (folder / 'src/extra.ads').write_bytes(b'package Extra is end Extra;\n')
        with self.assertRaises(ValueError):
            helper.source_check(folder, manifest)

    def test_capacity_observation(self):
        observed = driver.capacity()
        self.assertEqual(observed['task_storage_cap'], helper.CAP)
        self.assertEqual(observed['root_reserve'], 10000000000)

    def test_final_checks_independent_after_source_failure(self):
        attempted = []
        def source(*_):
            attempted.append('source')
            raise ValueError('fixed seeded source failure')
        def observed(name, value):
            attempted.append(name)
            return value
        with patch.object(driver, 'source_check', source), \
             patch.object(driver, 'canonical', lambda: observed('canonical', {})), \
             patch.object(driver, 'identities', lambda: observed('tools', {})), \
             patch.object(driver, 'environment', lambda _: observed('environment', {})), \
             patch.object(driver, 'inventory', lambda _: observed('inventory', {})):
            actual = driver.final_checks({}, {}, {}, {})
        self.assertEqual(attempted, ['source', 'source', 'canonical', 'tools',
                                     'environment', 'inventory'])
        self.assertEqual(set(actual['failures']), {'source_after', 'copy_after'})
        self.assertEqual(len(actual['observations']), 4)

    def test_terminal_headroom_refusal(self):
        folder = self.folder('terminal-headroom')
        before = helper.inventory(folder)['bytes']
        result = helper.terminal(folder, dict(status='PASS_CLEAN_PROJECT_PROOF'),
                                 cap=before + 8192)
        self.assertEqual(result['status'], 'FAILED')
        self.assertIn('headroom', result['reason'])
        self.assertEqual(helper.load(folder / 'terminal.json')['status'], 'FAILED')
        helper.inventory(folder, cap=before + 8192)

    def execute_synthetic(self, name, body, wall=2):
        folder = self.folder(name)
        (folder / 'tmp').mkdir(mode=0o700)
        command = ['/usr/bin/python3', '-I', '-S', '-B', '-Werror', '-c', body]
        result = process.run(command, folder, folder, helper.environment(folder),
                             'synthetic', wall, time.monotonic() + 5)
        helper.write(folder / 'process.json', result)
        self.assertTrue(result['terminal_group_absent'])
        return folder, result

    def test_short_success(self):
        folder, result = self.execute_synthetic('success', 'print("synthetic-ok")')
        self.assertEqual(result['status'], 'SUCCESS')
        self.assertEqual((folder / 'synthetic.stdout').read_bytes(), b'synthetic-ok\n')

    def test_nonzero_failure(self):
        _, result = self.execute_synthetic('nonzero', 'raise SystemExit(7)')
        self.assertEqual(result['status'], 'FAILED_PROCESS')
        self.assertEqual(result['returncode'], 7)

    def test_timeout_kill_reap(self):
        _, result = self.execute_synthetic('timeout',
            'import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(4)', .1)
        self.assertEqual(result['status'], 'FAILED')
        self.assertIn('deadline', result['reason'])
        self.assertEqual(result['returncode'], -9)

    def test_grandchild_group_reap(self):
        body = ('import subprocess;subprocess.Popen(["/usr/bin/python3","-I","-S",'
                '"-c","import time;time.sleep(4)"],stdout=subprocess.DEVNULL,'
                'stderr=subprocess.DEVNULL)')
        _, result = self.execute_synthetic('grandchild', body)
        self.assertEqual(result['status'], 'FAILED')
        self.assertIn('lingering', result['reason'])

    def test_stream_overflow(self):
        with patch.object(process, 'STREAM_CAP', 32):
            folder, result = self.execute_synthetic('overflow',
                'import os;os.write(1,b"x"*128)')
        self.assertEqual(result['status'], 'FAILED')
        self.assertIn('stream bound', result['reason'])
        self.assertEqual((folder / 'synthetic.stdout').read_bytes(), b'x' * 128)

    def test_storage_refusal(self):
        folder = self.folder('storage')
        command = ['/usr/bin/python3', '-I', '-S', '-c', 'print("unused")']
        result = process.run(command, folder, folder, helper.environment(folder),
                             'synthetic', 2, time.monotonic() + 5, cap=1)
        helper.write(folder / 'process.json', result)
        self.assertEqual(result['status'], 'FAILED')
        self.assertIn('storage', result['reason'])
        self.assertTrue(result['terminal_group_absent'])

    def test_static_function_size(self):
        for name in ('clean_helpers.py', 'clean_process.py', 'clean_child.py',
                     'clean_driver.py', 'test_clean_helpers.py'):
            raw = helper.read(helper.DESIGN / name)
            compile(raw, name, 'exec', dont_inherit=True)
            tree = ast.parse(raw, name)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    self.assertLessEqual(node.end_lineno - node.lineno + 1, 60,
                                         name + ':' + node.name)


def main():
    os.umask(0o077)
    ROOT.mkdir(mode=0o700, exist_ok=False)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
    with (ROOT / 'unittest.stderr').open('x') as stream:
        result = unittest.TextTestRunner(verbosity=2, stream=stream).run(suite)
    report = dict(schema='transport/clean-proof-runner-helper-controls/1',
                  status='PASS' if result.wasSuccessful() else 'FAILED',
                  tests_run=result.testsRun, errors=len(result.errors),
                  failures=len(result.failures), skipped=len(result.skipped),
                  actual_native_build_or_proof='NOT_RUN',
                  source_files={name: helper.pin(helper.read(helper.DESIGN / name))
                    for name in ('clean_helpers.py', 'clean_process.py', 'clean_child.py',
                                 'clean_driver.py', 'test_clean_helpers.py')})
    helper.write(ROOT / 'report.json', report)
    test_footprint()
    return 0 if result.wasSuccessful() else 1


def test_footprint():
    pending, size = [helper.DESIGN], 0
    for _ in range(8192):
        if not pending:
            return
        path = pending.pop()
        info = path.lstat()
        size += max(info.st_size, info.st_blocks * 512)
        helper.need(size <= 1048576, 'design capacity')
        if stat.S_ISDIR(info.st_mode):
            with os.scandir(path) as entries:
                for entry in entries:
                    helper.need(len(pending) < 8192, 'design entry bound')
                    pending.append(Path(entry.path))
    raise ValueError('design iteration bound')


if __name__ == '__main__':
    raise SystemExit(main())
