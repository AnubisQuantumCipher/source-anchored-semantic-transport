"""One synthetic main-path check for persistence of final IPC refusal metadata."""
import ast
from contextlib import ExitStack
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import clean_driver as driver
import clean_helpers as h

ROOT=h.DESIGN/'terminal-repair-test-01'


class Control(unittest.TestCase):
    def test_final_refusal_exported_after_callbacks(self):
        captured={}
        refusal=dict(path='tmp',type='S_IFDIR',mode=0o40722,st_ino=777,st_dev=29,
                     uid=os.getuid(),phase='FINAL',observation_time_ns=456,
                     partial_bytes=12345,peak_bytes=98765,reason='replaceable directory')
        def binding_failure(_task,state):
            state['refusal']=dict(refusal)
            state['peak_bytes']=98765
            raise ValueError('replaceable directory')
        def terminal(_task,result):
            captured.update(json.loads(json.dumps(result)))
            return result
        patches=[patch.object(driver,'options',return_value=object()),
            patch.object(driver,'admission',return_value=({},b'{}',1)),
            patch.object(driver,'design_checks',return_value=({},dict(source_head='fixed'))),
            patch.object(driver,'source_head',return_value='fixed'),
            patch.object(driver,'source_check',return_value={}),
            patch.object(driver,'identities',return_value={}),
            patch.object(driver,'canonical',return_value={}),
            patch.object(driver,'environment',return_value={}),
            patch.object(driver,'capacity',return_value={}),
            patch.object(driver.os.path,'lexists',return_value=False),
            patch.object(driver,'prepare',return_value={}),
            patch.object(driver,'write',return_value={}),
            patch.object(driver,'execute',return_value={}),
            patch.object(driver,'inventory',return_value={}),
            patch.object(driver,'strict_readback',side_effect=binding_failure),
            patch.object(driver,'terminal',side_effect=terminal),
            patch.object(driver,'print')]
        with ExitStack() as stack:
            for manager in patches:stack.enter_context(manager)
            self.assertEqual(driver.main(),1)
        self.assertEqual(captured['status'],'FAILED')
        self.assertIn('private_bindings_after',captured['final_checks']['failures'])
        self.assertEqual(captured['runtime_inventory_final']['refusal'],refusal)
        self.assertEqual(captured['runtime_inventory_final']['peak_bytes'],98765)
        for path in h.DESIGN.glob('*.py'):
            raw=h.read(path);compile(raw,str(path),'exec',dont_inherit=True)
            for node in ast.walk(ast.parse(raw)):
                if isinstance(node,ast.FunctionDef):
                    self.assertLessEqual(node.end_lineno-node.lineno+1,60)


def main():
    os.umask(0o077);ROOT.mkdir(mode=0o700,exist_ok=False)
    with (ROOT/'unittest.stderr').open('x') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(Control))
    h.write(ROOT/'report.json',dict(status='PASS' if result.wasSuccessful() else 'FAILED',
        tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),
        skipped=len(result.skipped),scope='ONE_FINAL_REFUSAL_TERMINAL_PERSISTENCE_CONTROL',
        actual_native_execution='NOT_RUN',source_files={p.name:h.pin(h.read(p))
            for p in h.DESIGN.glob('*.py')}))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':
    raise SystemExit(main())
