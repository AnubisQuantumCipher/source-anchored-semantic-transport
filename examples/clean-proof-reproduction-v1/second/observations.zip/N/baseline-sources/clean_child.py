"""Set the frozen native address-space limit, then replace this process."""
import os
import resource
import sys


def main():
    if not 2 <= len(sys.argv) <= 32:
        raise ValueError('fixed child argv bound')
    cap = 1073741824
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    if (soft != resource.RLIM_INFINITY and soft < cap or
            hard != resource.RLIM_INFINITY and hard < cap):
        raise ValueError('inherited address space below frozen requirement')
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    os.execve(sys.argv[1], sys.argv[1:], dict(os.environ))


if __name__ == '__main__':
    main()
