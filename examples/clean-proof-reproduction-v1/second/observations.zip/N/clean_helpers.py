"""Bounded trusted-host evidence helpers; no build/proof entry point."""
import hashlib
import json
import os
from pathlib import Path
import re
import stat

DESIGN = Path(__file__).resolve().parent
SOURCE = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
TASK = Path('/dev/shm/semantic-transport-proof-ipc-20261029')
CAP = 268435456
ENTRIES = 8192
STREAM_CAP = 8388608
EVIDENCE_RESERVE = 8454144
GNAT = Path('/home/sicarii/opt/gnat')
PROVE = GNAT / 'gnatprove-aarch64-linux-16.1.0-1'
BUILD = GNAT / 'gprbuild-aarch64-linux-26.0.0-1'
COMPILER = GNAT / 'gnat-aarch64-linux-16.1.0-1'


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def read(path, cap=1048576):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= cap, 'read type/size')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(cap + 1)
        after = os.fstat(fd)
        keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        need(len(raw) == before.st_size and len(raw) <= cap and all(
            getattr(before, k) == getattr(after, k) for k in keys), 'read changed')
        return raw
    finally:
        os.close(fd)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def file_pin(path, cap=268435456):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= cap, 'tool type/size')
        digest, size = hashlib.sha256(), 0
        for _ in range(4097):
            block = os.read(fd, 65536)
            if not block:
                break
            size += len(block)
            need(size <= cap, 'hash bound')
            digest.update(block)
        else:
            raise ValueError('hash iteration bound')
        after = os.fstat(fd)
        keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        need(size == before.st_size and all(getattr(before, k) == getattr(after, k)
             for k in keys), 'hash identity changed')
        return dict(bytes=size, sha256=digest.hexdigest())
    finally:
        os.close(fd)


def pairs(items):
    value = {}
    for key, entry in items:
        need(key not in value, 'duplicate JSON key')
        value[key] = entry
    return value


def load(path):
    return json.loads(read(path), object_pairs_hook=pairs,
                      parse_constant=lambda _: need(False, 'JSON nonfinite'))


def write(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()
    need(len(raw) <= 4194304, 'evidence output bound')
    with path.open('xb') as stream:
        need(stream.write(raw) == len(raw), 'evidence short write')
    return pin(raw)


def inventory(root, cap=CAP, maximum=ENTRIES):
    root = Path(root)
    pending, rows, size = [Path(root)], [], 0
    for _ in range(maximum + 1):
        if not pending:
            return dict(bytes=size, entries=rows)
        path = pending.pop()
        info = path.lstat()
        need(info.st_uid == os.getuid(), 'tree ownership')
        need(not stat.S_ISLNK(info.st_mode), 'tree symlink')
        name = '.' if path == root else str(path.relative_to(root))
        need(stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode), 'tree special')
        size += max(info.st_size, info.st_blocks * 512)
        need(size <= cap, 'task storage bound')
        rows.append(dict(path=name, bytes=info.st_size, allocated=info.st_blocks * 512,
                         mode=stat.S_IMODE(info.st_mode)))
        if stat.S_ISDIR(info.st_mode):
            with os.scandir(path) as iterator:
                for entry in iterator:
                    need(len(pending) + len(rows) < maximum, 'tree entry bound')
                    pending.append(Path(entry.path))
    raise ValueError('tree iteration bound')


def summary(raw, oracle):
    need(len(raw) <= 4194304, 'summary bound')
    text = raw.decode('utf-8', 'strict')
    totals = re.findall(r'^Total\s+.+$', text, re.M)
    need(totals == [oracle['expected_total_row']], 'proof total/unclosed')
    units = re.findall(r'^in unit .+$', text, re.M)
    need(len(units) == len(set(units)) and sorted(units) ==
         sorted(oracle['expected_unit_rows']), 'proof unit inventory')
    need(not re.search(r'\b[1-9]\d*\s+(?:errors?|warnings?|unproved|justified|pragma Assume)\b', text),
         'proof warning/error/assumption')
    need(not re.search(r'\b(?:unproved|justified)\s*[:=]\s*[1-9]', text, re.I),
         'proof nonzero terminal count')
    need(not re.search(r'\b(?:warning|error):', text, re.I), 'proof diagnostic')
    return dict(total_row=totals[0], unit_rows=units, status='PROOF_ORACLE_PASS')


def source_check(root, manifest):
    for folder in (root, root / 'evaluation', root / 'evaluation/src', root / 'src'):
        need(stat.S_ISDIR(folder.lstat().st_mode), 'source directory type')
    expected = {x['path'] for x in manifest['items']}
    actual = {'evaluation/transport_core.gpr'}
    for folder in ('evaluation/src', 'src'):
        with os.scandir(root / folder) as entries:
            for entry in entries:
                need(len(actual) <= 64, 'source name bound')
                if Path(entry.name).suffix in ('.ads', '.adb'):
                    actual.add(folder + '/' + entry.name)
    need(actual == expected and len(expected) == len(manifest['items']), 'source set')
    for item in manifest['items']:
        rel = Path(item['path'])
        need(not rel.is_absolute() and '..' not in rel.parts, 'source path')
        raw = read(root / rel)
        need(pin(raw) == {k: item[k] for k in ('bytes', 'sha256')}, 'source pin')
        need(not re.search(rb'\bpragma\s+(Assume|Suppress|Annotate)\b|Skip_Proof',
                           raw, re.I), 'source proof bypass')
    return dict(status='SOURCE_PINS_PASS', files=len(expected))


def environment(task):
    home = os.environ.get('HOME')
    need(home == '/home/sicarii', 'HOME identity')
    for name in ('.why3.conf', '.config/why3.conf'):
        need(not os.path.lexists(str(Path(home) / name)), 'user Why3 configuration')
    return dict(HOME=home, PATH=':'.join(str(p / 'bin') for p in
                (COMPILER, BUILD, PROVE)) + ':/usr/bin:/bin',
                GPR_PROJECT_PATH=str(PROVE / 'lib/gnat') + ':' +
                str(GNAT / 'auxiliary/share/gpr'), LANG='C', LC_ALL='C', TZ='UTC',
                TMPDIR=str(task / 'tmp'), PYTHONDONTWRITEBYTECODE='1')


def collect_checks(checks):
    need(0 < len(checks) <= 8, 'final check count bound')
    observations, failures = {}, {}
    for name, callback in checks:
        try:
            observations[name] = callback()
        except Exception as error:
            failures[name] = type(error).__name__ + ': ' + str(error)
    return dict(observations=observations, failures=failures)


def unchanged(before, callback, reason):
    after = callback()
    need(after == before, reason)
    return after


def terminal(task, result, cap=CAP):
    try:
        current = inventory(task, cap)['bytes']
        need(current <= cap - 4194304 - 65536, 'terminal evidence headroom')
    except (OSError, ValueError) as error:
        result = dict(schema='transport/clean-proof-run/1', status='FAILED',
                      authority='NONE', reason=str(error),
                      full_terminal_result='NOT_WRITTEN_RESOURCE_REFUSAL',
                      raw_process_evidence='RETAINED_IN_TASK')
    write(task / 'terminal.json', result)
    return result
