"""Bounded metadata-only trusted-child IPC policy; strict inventory stays separate."""
import os
from pathlib import Path
import stat
import time

from clean_helpers import CAP, ENTRIES, inventory, need
import directory_lifetime as lifetime


def new_state():
    return dict(registry={}, bindings={}, lifetimes={}, peak_bytes=0, current_count=0,
                peak_ipc_count=0, partial_bytes=0, visited=0, pending=0)


def kind(mode):
    if stat.S_ISSOCK(mode):
        return 'S_IFSOCK'
    if stat.S_ISFIFO(mode):
        return 'S_IFIFO'
    if stat.S_ISLNK(mode):
        return 'S_IFLNK'
    if stat.S_ISCHR(mode):
        return 'S_IFCHR'
    if stat.S_ISBLK(mode):
        return 'S_IFBLK'
    if stat.S_ISDIR(mode):
        return 'S_IFDIR'
    if stat.S_ISREG(mode):
        return 'S_IFREG'
    return 'UNKNOWN'


def metadata(path, root, info, phase, stamp):
    relative = '.' if path == root else path.relative_to(root).as_posix()
    need(len(relative.encode()) <= 4096, 'diagnostic path bound')
    return dict(path=relative, mode=info.st_mode, type=kind(info.st_mode),
                st_dev=info.st_dev, st_ino=info.st_ino, uid=info.st_uid,
                nlink=info.st_nlink, bytes=info.st_size, blocks=info.st_blocks,
                ctime_ns=info.st_ctime_ns, mtime_ns=info.st_mtime_ns,
                phase=phase, observation_time_ns=stamp)


def bind_directory(state, row):
    state['diagnostic_candidate'] = row
    need(row['uid'] == os.getuid(), 'directory ownership')
    need(row['mode'] & 0o022 == 0, 'replaceable directory')
    identity = (row['st_dev'], row['st_ino'])
    old = state['bindings'].get(row['path'])
    need(old is None or old == identity, 'directory identity changed')
    need(old is not None or len(state['bindings']) < ENTRIES, 'ancestor binding bound')
    lifetime.observe(state, row)
    state['bindings'][row['path']] = identity


def ancestors(state, path, root, phase, stamp):
    relative = path.relative_to(root)
    need(len(relative.parts) <= 256, 'ancestor path bound')
    current = root
    for part in ('.',) + relative.parts[:-1]:
        if part != '.':
            current = current / part
        read_directory(current, root, state, phase, stamp)


def read_directory(path, root, state, phase, stamp):
    state['diagnostic_candidate'] = dict(
        path='.' if path == root else path.relative_to(root).as_posix(),
        type='UNKNOWN', mode='UNKNOWN', st_dev='UNKNOWN', st_ino='UNKNOWN',
        uid='UNKNOWN', nlink='UNKNOWN', phase=phase, observation_time_ns=stamp)
    observation_deadline(state)
    info = path.lstat()
    row = metadata(path, root, info, phase, stamp)
    state['diagnostic_candidate'] = row
    observation_deadline(state)
    need(stat.S_ISDIR(info.st_mode), 'ancestor symlink/type')
    bind_directory(state, row)


def admit_ipc(state, row, active):
    state['current_count'] += 1
    state['peak_ipc_count'] = max(state['peak_ipc_count'], state['current_count'])
    need(active and row['phase'] in ('BUILD', 'PROOF'), 'inactive owned group')
    path = Path(row['path'])
    below = (len(path.parts) > 1 and path.parts[0] == 'tmp' or
             len(path.parts) > 2 and path.parts[:2] == ('obj', 'gnatprove'))
    need(below, 'IPC location/root type')
    need(row['type'] in ('S_IFSOCK', 'S_IFIFO'), 'IPC special type')
    need(row['uid'] == os.getuid(), 'IPC member ownership')
    need(row['nlink'] == 1, 'IPC member nlink')
    need(state['current_count'] <= 16, 'simultaneous IPC bound')
    key = (row['path'], row['st_dev'], row['st_ino'], row['type'])
    old = state['registry'].get(key)
    state['attempted_distinct_count'] = len(state['registry']) + int(old is None)
    need(old is not None or len(state['registry']) < 16, 'distinct IPC bound')
    if old is None:
        old = dict(row, first_phase=row['phase'], first_time=row['observation_time_ns'])
        state['registry'][key] = old
    old.update(last_phase=row['phase'], last_time=row['observation_time_ns'])


def exported(state):
    return {k: v for k, v in state.items() if k not in ('registry', 'bindings')} | dict(
        registry=list(state['registry'].values()), ancestor_bindings=len(state['bindings']),
        distinct_count=len(state['registry']), ancestor_binding_records=state['bindings'])


def runtime_inventory(root, state, phase, active, cap=CAP, publication_guard=None, fd_lease=None):
    original = state
    state = lifetime.begin(original, phase, active)
    root, pending, rows = Path(root), [Path(root)], []
    state.update(current_count=0, partial_bytes=0, visited=0, pending=1)
    current = dict(path='.', type='UNKNOWN', phase=phase)
    try:
        for _ in range(ENTRIES + 1):
            observation_deadline(state)
            if not pending:
                complete_observation(root, original, state, rows, phase, publication_guard)
                return dict(bytes=state['partial_bytes'], entries=rows)
            path = pending.pop()
            current = dict(path=str(path.relative_to(root)), type='UNKNOWN', phase=phase,
                           observation_time_ns=time.time_ns(), mode='UNKNOWN',
                           st_dev='UNKNOWN', st_ino='UNKNOWN', uid='UNKNOWN', nlink='UNKNOWN')
            state['diagnostic_candidate'] = current
            info, stamp = path.lstat(), time.time_ns()
            current = metadata(path, root, info, phase, stamp)
            state['diagnostic_candidate'] = current
            observation_deadline(state)
            state['partial_bytes'] += max(info.st_size, info.st_blocks * 512)
            state['peak_bytes'] = max(state['peak_bytes'], state['partial_bytes'])
            state.update(visited=len(rows) + 1, pending=len(pending))
            need(state['partial_bytes'] <= cap, 'task storage bound')
            need(info.st_uid == os.getuid(), 'tree ownership')
            if stat.S_ISDIR(info.st_mode):
                bind_directory(state, current)
                children(path, pending, rows, state, fd_lease)
            elif not stat.S_ISREG(info.st_mode):
                ancestors(state, path, root, phase, stamp)
                state['diagnostic_candidate'] = current
                admit_ipc(state, current, active)
            rows.append(current)
        raise ValueError('tree iteration bound')
    except (OSError, ValueError) as error:
        state['pending'] = len(pending)
        state['refusal'] = dict(state.get('diagnostic_candidate', current), reason=str(error),
                                partial_bytes=state['partial_bytes'],
                                peak_bytes=state['peak_bytes'], visited=state['visited'],
                                pending=state['pending'], current_count=state['current_count'],
                                distinct_count=len(state['registry']),
                                observation_id=state.get('observation_id', 0))
        lifetime.failed(original, state, error)
        raise


def children(path, pending, rows, state, fd_lease=None):
    import cgroup_io
    observation_deadline(state)
    if fd_lease is not None:cgroup_io.reserve(fd_lease,1)
    try:
        with os.scandir(path) as iterator:
            for entry in iterator:
                observation_deadline(state)
                need(len(pending)+len(rows) < ENTRIES, 'tree entry bound')
                pending.append(Path(entry.path))
        observation_deadline(state)
    finally:
        if fd_lease is not None:cgroup_io.release(fd_lease,1)


def complete_observation(root, original, state, rows, phase, publication_guard=None):
    ended, surviving, missing = lifetime.reconcile(state, rows)
    for relative in missing:
        observation_deadline(state)
        read_directory(root / relative, root, state, phase, time.time_ns())
        raise ValueError('persistent directory absent from complete observation')
    for relative in surviving:
        observation_deadline(state)
        read_directory(root / relative, root, state, phase, time.time_ns())
    observation_deadline(state)
    lifetime.commit(original, state, ended, publication_guard)


def observation_deadline(state):
    deadline = state.get('quiescent_deadline')
    need(deadline is None or time.monotonic() < deadline, 'inventory pause/wall deadline')


def prime_state(root, state):
    result = runtime_inventory(root, state, 'INITIAL', False)
    observed = {row['path'] for row in result['entries'] if row['type'] == 'S_IFDIR'}
    need({'.', 'source', 'obj', 'bin', 'tmp'} <= observed, 'initial persistent roots')
    return result


def strict_readback(root, state, cap=CAP):
    strict_result, strict_error, binding_error = None, None, None
    try:
        strict_result = inventory(root, cap)
    except (OSError, ValueError) as error:
        strict_error = error
    try:
        binding_readback(root, state, cap)
    except (OSError, ValueError) as error:
        binding_error = error
    if strict_error is not None:
        raise strict_error
    if binding_error is not None:
        raise binding_error
    return strict_result


def binding_readback(root, state, cap):
    try:
        runtime_inventory(root, state, 'FINAL', False, cap)
        need(len(state['bindings']) <= ENTRIES, 'final binding count')
    except (OSError, ValueError) as error:
        state['refusal'] = dict(state['diagnostic_candidate'], reason=str(error),
            partial_bytes=state['partial_bytes'], peak_bytes=state['peak_bytes'],
            visited=state['visited'], pending=state['pending'],
            current_count=state['current_count'], distinct_count=len(state['registry']),
                                observation_id=state.get('observation_id', 0))
        raise
