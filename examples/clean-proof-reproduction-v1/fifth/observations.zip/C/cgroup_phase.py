"""One fixed private leaf lifecycle, bounded handshakes and kernel acknowledgments."""
import os
from pathlib import Path
import select
import signal
import time

from clean_helpers import need
import cgroup_io as cg
import quiescent


def initial(lease,deadline):
    cg.open_controls(lease,deadline)
    state=cg.structure(lease,deadline)
    need(state==dict(populated=0,frozen=0),'fresh leaf not empty/unfrozen')
    need(cg.membership(lease,deadline)==([],[]),'fresh leaf member')
    controller_outside(lease,deadline)
    for name in cg.CONTROLS:cg.close_named(lease,name)


def controller_outside(lease,deadline):
    descriptor=cg.checked_open(lease,'controller','/proc/self/cgroup',os.O_RDONLY,deadline)
    try:
        raw=os.read(descriptor,4097);need(len(raw)<=4096,'controller membership bound')
        target=(cg.PARENT.removeprefix('/sys/fs/cgroup')+'/'+lease['name']).encode()
        lines=raw.splitlines();need(len(lines)==1 and lines[0].startswith(b'0::'),'controller cgroup')
        current=lines[0][3:]
        need(current!=target and not current.startswith(target+b'/'),'controller included/ancestor')
    finally:cg.close_named(lease,'controller')


def pipes(lease):
    for first,second in (('ready_r','ready_w'),('go_r','go_w')):
        cg.reserve(lease,2)
        try:pair=os.pipe2(os.O_CLOEXEC)
        except BaseException:cg.release(lease,2);raise
        lease['fds'][first],lease['fds'][second]=pair
    os.set_blocking(lease['fds']['ready_r'],False)


def after_spawn(lease,proc,deadline):
    for name in ('join','ready_w','go_r'):cg.close_named(lease,name)
    lease['owner']=cg.pin_owner(lease,proc.pid,deadline)
    cg.reserve(lease,1)
    try:lease['fds']['pidfd']=os.pidfd_open(proc.pid,0)
    except BaseException:cg.release(lease,1);raise
    cg.open_controls(lease,deadline)


def ready(lease,deadline):
    seen=False
    for _ in range(8):
        cg.tick(lease,'READY',deadline)
        readable,_,_=select.select([lease['fds']['ready_r']],[],[],min(0.01,max(0,deadline-time.monotonic())))
        if not readable:continue
        raw=os.read(lease['fds']['ready_r'],65);need(len(raw)<=64,'READY byte bound')
        if not raw:
            need(seen,'READY missing/EOF');lease['ready']='EXACT_READY_AND_EOF';return
        need(not seen and raw==b'READY\n','READY partial/duplicate/malformed');seen=True
    raise ValueError('READY polling bound')


def bootstrap(lease,proc,deadline):
    end=min(deadline,time.monotonic()+0.5)
    ready(lease,end);cg.check(lease,end);controller_outside(lease,end)
    state=cg.structure(lease,end);need(state==dict(populated=1,frozen=0),'bootstrap leaf state')
    processes,threads=cg.membership(lease,end)
    need(processes==[proc.pid] and threads==[proc.pid],'extra bootstrap process/thread')
    cg.owner_check(lease,end)
    lease['joined']=True;cg.close_named(lease,'ready_r')
    cg.tick(lease,'GO',end)
    need(os.write(lease['fds']['go_w'],b'GO\n')==3,'GO short write')
    lease['go_sent']=True;cg.close_named(lease,'go_w')
    cg.tick(lease,'GO',end);lease['status']='RUNNING'


def frozen(lease,deadline):
    cg.owner_check(lease,deadline)
    state=cg.structure(lease,deadline)
    need(cg.read_fd(lease,'freeze',deadline)==b'1\n' and state['frozen']==1,
         'kernel frozen acknowledgment lost')
    return state


def acknowledgment(lease,value,deadline):
    for _ in range(8):
        state=cg.structure(lease,deadline)
        lease['last_ack']=dict(state,time_ns=time.time_ns())
        if state['frozen']==value:return state
        time.sleep(min(0.01,max(0,deadline-time.monotonic())))
    raise ValueError('kernel acknowledgment poll bound')


def observe(lease,deadline,callback):
    lease['operations']=0;start=time.monotonic_ns();end=min(deadline,time.monotonic()+0.5)
    lease['status']='FREEZING';resumed=False
    initial_write=lease.get('write_sequence',0)
    try:
        cg.owner_check(lease,end)
        cg.write_fd(lease,'freeze',b'1',end)
        acknowledgment(lease,1,end);state=frozen(lease,end)
        cg.membership(lease,end);lease['status']='FROZEN_ACKNOWLEDGED'
        def publication_guard():frozen(lease,end)
        result=callback(end,bool(state['populated']),publication_guard)
        frozen(lease,end);cg.tick(lease,'inventory completed',end)
        empty=not cg.structure(lease,end)['populated']
        if not empty:
            cg.owner_check(lease,end)
            cg.write_fd(lease,'freeze',b'0',end);resumed=True
            acknowledgment(lease,0,end);cg.tick(lease,'thaw completed',end)
        lease['status']='EMPTY_FROZEN' if empty else 'RUNNING'
        return result,empty
    except (OSError,ValueError,UnicodeError) as error:
        thaw=lease.get('last_write',{})
        thaw_applied=resumed or (thaw.get('control')=='freeze' and thaw.get('value')=='0'
                                  and thaw.get('bytes')==1 and thaw.get('sequence',0)>initial_write)
        lease.update(status='FAILED_AFTER_THAW' if thaw_applied else 'FAILED_NO_THAW',reason=str(error))
        lease['failure']=dict(lease.get('last',{}),reason=str(error));raise
    finally:
        elapsed=time.monotonic_ns()-start
        lease['total_pause_ns']=lease.get('total_pause_ns',0)+elapsed
        lease['peak_pause_ns']=max(lease.get('peak_pause_ns',0),elapsed)


def empty(lease,deadline):
    for _ in range(8):
        state=cg.structure(lease,deadline)
        processes,threads=cg.membership(lease,deadline)
        if not state['populated'] and not processes and not threads:return
        time.sleep(min(0.01,max(0,deadline-time.monotonic())))
    raise ValueError('owned leaf not empty')


def pidfd_cleanup(lease,proc,deadline):
    cg.tick(lease,'prejoin cleanup',deadline)
    if lease.get('joined'):return
    if 'pidfd' in lease['fds']:
        try:signal.pidfd_send_signal(lease['fds']['pidfd'],signal.SIGKILL,None,0)
        except ProcessLookupError:
            ready,_,_=select.select([lease['fds']['pidfd']],[],[],0)
            need(bool(ready),'pidfd exit uncertainty')
        lease['prejoin_cleanup']='PIDFD_SIGKILL_OR_CONFIRMED_EXIT'
    else:
        need(not lease.get('go_sent',False),'no pidfd after GO')
        owner=lease.get('owner') or cg.pin_owner(lease,proc.pid,deadline)
        lease['owner']=owner;cg.owner_check(lease,deadline)
        os.kill(proc.pid,signal.SIGKILL)
        lease['prejoin_cleanup']='VERIFIED_UNREAPED_BOOTSTRAP_ONLY_SIGKILL'
    cg.tick(lease,'prejoin cleanup complete',deadline)


def close_handles(lease,keep=()):
    failures=[]
    for name in list(lease['fds']):
        if name not in keep:
            try:cg.close_named(lease,name)
            except OSError as error:failures.append(name+':'+str(error))
    need(not failures,'FD close failures '+str(failures))


def remove(lease,deadline):
    cg.check(lease,deadline);empty(lease,deadline)
    close_handles(lease,('parent','leaf'))
    cg.check(lease,deadline)
    os.rmdir(lease['name'],dir_fd=lease['fds']['parent'])
    lease['removed']=True;lease['status']='REMOVED_EMPTY'
    close_handles(lease)


def exported(lease):
    return {key:value for key,value in lease.items() if key!='fds'} | dict(
        open_handle_names=list(lease['fds']))
