"""Trusted single-thread join, READY/WAIT GO, capability-close, then exact exec."""
import errno
import os
import resource
import stat
import sys


def need(test,message):
    if not test:raise ValueError(message)


def main():
    need(8<=len(sys.argv)<=34,'child argument bound')
    values=sys.argv[1:4]
    need(all(value.isascii() and value.isdigit() and len(value)<=10 for value in values),
         'child FD argument')
    join,ready,go=map(int,values)
    need(len({join,ready,go})==3 and min(join,ready,go)>=3,'child FD identity')
    expected=sys.argv[4:7]
    need(all(value.isascii() and value.isdigit() and len(value)<=20 for value in expected),
         'join identity arguments')
    info=os.fstat(join)
    need((info.st_dev,info.st_ino,info.st_uid)==tuple(map(int,expected)) and
         stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid(),'inherited join FD identity')
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    need(os.write(join,b'0')==1,'child join short write');os.close(join)
    need(os.write(ready,b'READY\n')==6,'child READY short write');os.close(ready)
    message=os.read(go,65)
    need(message==b'GO\n' and os.read(go,1)==b'','child GO missing/duplicate/malformed')
    os.close(go)
    for descriptor in (join,ready,go):
        try:os.fstat(descriptor)
        except OSError as error:need(error.errno==errno.EBADF,'child FD close uncertainty')
        else:raise ValueError('child capability inherited after GO')
    os.execve(sys.argv[7],sys.argv[7:],dict(os.environ))


if __name__=='__main__':main()
