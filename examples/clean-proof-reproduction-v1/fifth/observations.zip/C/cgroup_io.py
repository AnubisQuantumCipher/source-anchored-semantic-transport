"""Fixed FD-relative cgroup2 lease primitives; no discovery or fallback writes."""
import os
from pathlib import Path
import stat
import time

from clean_helpers import DESIGN, load, need

PARENT='/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/app.slice'
PREFIX='semantic-transport-proof-cgroup-20261029-'
FLAGS=os.O_CLOEXEC|os.O_NOFOLLOW
CONTROLS={'procs':('cgroup.procs',os.O_RDONLY),'threads':('cgroup.threads',os.O_RDONLY),
          'events':('cgroup.events',os.O_RDONLY),'freeze':('cgroup.freeze',os.O_RDWR),
          'kill':('cgroup.kill',os.O_WRONLY),'type':('cgroup.type',os.O_RDONLY),
          'stat':('cgroup.stat',os.O_RDONLY)}


def identity(info):
    return dict(dev=info.st_dev,ino=info.st_ino,uid=info.st_uid,mode=info.st_mode)


def tick(lease, path, deadline):
    lease['last']=dict(path=str(path),time_ns=time.time_ns(),metadata='UNKNOWN')
    lease['operations']+=1;lease['total_operations']+=1
    need(lease['operations']<=8192 and lease['total_operations']<=100000000,'metadata bound')
    need(time.monotonic()<deadline,'cgroup phase/pause/cleanup deadline')


def reserve(lease, amount):
    need(0<=amount<=16 and lease['extra_fds']+amount<=16,'extra FD bound')
    lease['extra_fds']+=amount
    lease['peak_extra_fds']=max(lease['peak_extra_fds'],lease['extra_fds'])


def release(lease, amount):
    need(0<=amount<=lease['extra_fds'],'FD accounting underflow')
    lease['extra_fds']-=amount


def close_named(lease, name):
    descriptor=lease['fds'].pop(name)
    try:os.close(descriptor)
    except OSError:
        lease.setdefault('uncertain_fds',{})[name]=descriptor
        raise
    else:release(lease,1)


def checked_open(lease, name, path, flags, deadline, directory=None):
    reserve(lease,1)
    try:
        tick(lease,path,deadline)
        descriptor=os.open(path,flags|FLAGS,dir_fd=directory)
    except BaseException:
        release(lease,1);raise
    lease['fds'][name]=descriptor
    return descriptor


def read_fd(lease, name, deadline):
    tick(lease,name,deadline);need(name in lease['fds'],'control not open '+name)
    descriptor=lease['fds'][name]
    os.lseek(descriptor,0,os.SEEK_SET)
    raw=os.read(descriptor,4097)
    need(len(raw)<=4096,'control read bound')
    tick(lease,name,deadline)
    lease['last']['value']=raw.decode('ascii')
    return raw


def write_fd(lease, name, raw, deadline):
    need(raw in (b'0',b'1'),'fixed control write')
    check(lease,deadline);tick(lease,name,deadline)
    need(name in lease['fds'],'control not open '+name)
    lease['write_sequence']=lease.get('write_sequence',0)+1
    sequence=lease['write_sequence']
    lease['write_attempt']=dict(control=name,value=raw.decode(),time_ns=time.time_ns(),sequence=sequence)
    written=os.write(lease['fds'][name],raw)
    lease['last_write']=dict(control=name,value=raw.decode(),time_ns=time.time_ns(),bytes=written,sequence=sequence)
    need(written==len(raw),'control short write')
    tick(lease,name,deadline)


def numbers(raw):
    fields=raw.splitlines()
    need(len(fields)<=256,'workload task bound')
    need(all(value and len(value)<=20 and value.isdigit() for value in fields),'member format')
    values=[int(value) for value in fields]
    need(all(value>0 for value in values) and len(values)==len(set(values)),'member identity')
    return values


def flat(raw, required):
    result={}
    for line in raw.decode('ascii').splitlines():
        fields=line.split()
        need(len(fields)==2 and fields[0] not in result and fields[1] in ('0','1'),
             'events duplicate/malformed')
        result[fields[0]]=int(fields[1])
    need(set(result)==set(required),'events missing/unknown')
    return result


def check(lease,deadline):
    tick(lease,lease['name'],deadline)
    need(all(key in lease['fds'] for key in ('parent','leaf')) and
         'leaf_identity' in lease and 'parent_identity' in lease,'partial leaf identity unconfirmed')
    parent=identity(os.fstat(lease['fds']['parent']))
    need(parent==lease['parent_identity'],'parent identity changed')
    current=os.stat(lease['name'],dir_fd=lease['fds']['parent'],follow_symlinks=False)
    need(identity(current)==lease['leaf_identity'] and stat.S_ISDIR(current.st_mode),
         'leaf substituted/type/owner')
    need(identity(os.fstat(lease['fds']['leaf']))==lease['leaf_identity'],'leaf FD identity')
    need(current.st_uid==os.getuid() and current.st_mode&0o022==0,'private leaf ownership')
    for name,expected in lease.get('control_identities',{}).items():
        if name in lease['fds']:
            need(identity(os.fstat(lease['fds'][name]))==expected,'control FD identity changed')
    lease['last']['metadata']=identity(current)


def mount_check(lease,deadline):
    descriptor=checked_open(lease,'mountinfo','/proc/self/mountinfo',os.O_RDONLY,deadline)
    data=b''
    try:
        for _ in range(16):
            tick(lease,'mountinfo',deadline);block=os.read(descriptor,4096)
            if not block:break
            data+=block
        else:raise ValueError('mountinfo chunk bound')
        found=[]
        for line in data.decode('ascii').splitlines():
            fields=line.split();separator=fields.index('-')
            if fields[4]=='/sys/fs/cgroup':found.append(fields)
        need(len(found)==1,'cgroup mount ambiguity')
        fields=found[0];separator=fields.index('-')
        need(fields[3]=='/' and 'rw' in fields[5].split(',') and
             fields[separator+1]=='cgroup2' and 'rw' in fields[separator+3].split(','),
             'cgroup2 writable mount')
    finally:close_named(lease,'mountinfo')


def create(label, deadline):
    need(label in ('build','proof','control1','control2','control3'),'fixed leaf label')
    lease=dict(name=PREFIX+label,fds={},extra_fds=0,peak_extra_fds=0,operations=0,
        total_operations=0,joined=False,created=False,removed=False,status='CREATING')
    try:
        parent=checked_open(lease,'parent',PARENT,os.O_RDONLY|os.O_DIRECTORY,deadline)
        expected=load(DESIGN/'proof-acquisition-design-review-02.json')['local_read_only_observations']['parent_identity']
        observed=identity(os.fstat(parent))
        need(observed['dev']==expected['dev'] and observed['ino']==expected['ino'] and
             observed['uid']==os.getuid() and observed['mode']&0o022==0,'parent held identity')
        lease['parent_identity']=observed;mount_check(lease,deadline)
        os.mkdir(lease['name'],mode=0o700,dir_fd=parent);lease['created']=True
        leaf=checked_open(lease,'leaf',lease['name'],os.O_RDONLY|os.O_DIRECTORY,deadline,parent)
        lease['leaf_identity']=identity(os.fstat(leaf));check(lease,deadline)
        join=checked_open(lease,'join','cgroup.procs',os.O_WRONLY,deadline,leaf)
        info=os.fstat(join)
        need(stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and
             info.st_dev==lease['leaf_identity']['dev'],'join FD ownership/type')
        lease['control_identities']={'join':identity(info)}
        lease['status']='EMPTY_CREATED'
        return lease
    except BaseException as error:
        error.cgroup_lease=lease
        raise


def open_controls(lease,deadline):
    check(lease,deadline)
    for key,(name,flags) in CONTROLS.items():
        descriptor=lease['fds'].get(key)
        if descriptor is None:
            descriptor=checked_open(lease,key,name,flags,deadline,lease['fds']['leaf'])
        info=os.fstat(descriptor)
        need(stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and
             info.st_dev==lease['leaf_identity']['dev'],'control FD ownership/type')
        lease.setdefault('control_identities',{})[key]=identity(info)
    need(read_fd(lease,'type',deadline)==b'domain\n','valid domain leaf')


def structure(lease,deadline):
    check(lease,deadline)
    need(read_fd(lease,'type',deadline)==b'domain\n','domain changed')
    fields={}
    for line in read_fd(lease,'stat',deadline).decode('ascii').splitlines():
        parts=line.split();need(len(parts)==2 and parts[1].isdigit(),'cgroup stat format')
        need(parts[0] not in fields,'duplicate cgroup stat');fields[parts[0]]=int(parts[1])
    need(fields.get('nr_descendants')==0 and fields.get('nr_dying_descendants')==0,
         'unexpected subgroup')
    return flat(read_fd(lease,'events',deadline),('populated','frozen'))


def metadata(lease,pid,deadline,thread=None):
    path='/proc/'+str(pid)+('/task/'+str(thread) if thread is not None else '')
    descriptor=checked_open(lease,'member-meta',path+'/stat',os.O_RDONLY,deadline)
    try:
        info=os.fstat(descriptor);raw=os.read(descriptor,4097)
        need(len(raw)<=4096 and info.st_uid==os.getuid(),'member stat bound/uid')
        import quiescent
        row=quiescent.parse(raw,pid if thread is None else thread,info.st_uid)
        row['pid']=pid;tick(lease,path,deadline)
        return row
    finally:close_named(lease,'member-meta')


def membership(lease,deadline):
    processes=numbers(read_fd(lease,'procs',deadline))
    threads=numbers(read_fd(lease,'threads',deadline))
    records=[]
    for pid in processes:
        row=metadata(lease,pid,deadline);records.append(row)
        descriptor=checked_open(lease,'membership','/proc/'+str(pid)+'/cgroup',os.O_RDONLY,deadline)
        try:
            raw=os.read(descriptor,4097);need(len(raw)<=4096,'membership byte bound')
            expected=('0::'+PARENT.removeprefix('/sys/fs/cgroup')+'/'+lease['name']+'\n').encode()
            need(raw==expected,'migration/membership uncertainty')
        finally:close_named(lease,'membership')
    thread_records=[metadata(lease,tid,deadline) for tid in threads]
    need(bool(processes)==bool(threads),'process/thread membership mismatch')
    lease['thread_records']=thread_records
    if len(threads)>lease.get('peak_tasks',0):lease['peak_thread_records']=thread_records
    lease['processes']=processes;lease['threads']=threads;lease['member_records']=records
    lease['peak_tasks']=max(lease.get('peak_tasks',0),len(threads))
    return processes,threads


def owner_check(lease,deadline):
    owner=lease['owner'];row=metadata(lease,owner['pid'],deadline)
    need(all(row[key]==value for key,value in owner.items()),'reserved leader identity uncertainty')
    return row


def pin_owner(lease,pid,deadline):
    row=metadata(lease,pid,deadline)
    need(row['pgid']==row['sid']==pid and row['uid']==os.getuid() and
         pid!=os.getpgrp(),'private bootstrap ownership/session')
    return {key:row[key] for key in ('pid','tid','pgid','sid','starttime','uid')}
