"""Bounded observed quiescence of one reserved private Linux process group."""
import os
from pathlib import Path
import signal
import time

from clean_helpers import need

PROC = Path('/proc')


def tick(context, path, amount=1):
    context['attempted_path'] = str(path)
    context['known'] = 'UNKNOWN'
    context['metadata_entries'] += amount
    need(context['metadata_entries'] <= 8192, 'proc metadata entry bound')
    need(time.monotonic() < context['deadline'], 'quiescent pause/wall deadline')


def names(path, context):
    result = []
    tick(context, path)
    with os.scandir(path) as entries:
        for entry in entries:
            tick(context, Path(entry.path))
            need(len(entry.name) <= 256, 'proc entry name bound')
            result.append(entry.name)
    return result


def parse(raw, identity, uid):
    need(len(raw) <= 4096, 'proc stat byte bound')
    text = raw.decode('ascii')
    prefix, separator, fields = text.rpartition(') ')
    need(separator and prefix.startswith(str(identity) + ' ('), 'proc stat pid format')
    values = fields.split()
    need(20 <= len(values) <= 64 and len(values[0]) == 1, 'proc stat fields')
    need(values[0] in 'RSDZTWtXxKPI', 'proc task state format')
    for index in (2, 3, 19):
        need(values[index].isascii() and values[index].isdigit(), 'proc identity field')
    return dict(tid=identity, state=values[0], pgid=int(values[2]),
                sid=int(values[3]), starttime=int(values[19]), uid=uid)


def task(pid, context, tid=None):
    base = PROC / str(pid)
    if tid is not None:
        base = base / 'task' / str(tid)
    tick(context, base)
    uid = base.stat().st_uid
    path = base / 'stat'
    tick(context, path)
    with path.open('rb', buffering=0) as stream:
        raw = stream.read(4097)
    tick(context, path, 0)
    row = parse(raw, pid if tid is None else tid, uid)
    row['pid'] = pid
    context['known'] = dict(row)
    return row


def context(deadline):
    return dict(deadline=deadline, metadata_entries=0, attempted_path='UNKNOWN',
                known='UNKNOWN', records=[], complete=False)


def owner(pid, deadline=None):
    end = time.monotonic() + 0.5
    end = end if deadline is None else min(end, deadline)
    row = task(pid, context(end))
    need(time.monotonic() < end, 'owner capture phase/wall deadline')
    need(row['pgid'] == row['sid'] == pid and row['uid'] == os.getuid(),
         'private leader ownership/session')
    need(pid != os.getpgrp(), 'supervisor group target')
    return {key: row[key] for key in ('pid', 'tid', 'pgid', 'sid', 'starttime', 'uid')}


def verify(expected, deadline, current=None):
    current = context(deadline) if current is None else current
    try:
        row = task(expected['pid'], current)
    except (OSError, ValueError, UnicodeError) as error:
        raise ValueError('reserved leader read uncertainty: ' + str(error)) from error
    need(all(row[key] == value for key, value in expected.items()),
         'reserved leader identity mismatch')
    need(expected['pgid'] != os.getpgrp() and expected['uid'] == os.getuid(),
         'foreign/supervisor group target')
    return row


def send(expected, value, deadline):
    verify(expected, deadline)
    need(time.monotonic() < deadline, 'signal deadline')
    os.killpg(expected['pgid'], value)


def member_task(expected, pid, current, tid=None):
    reserved = pid == expected['pid'] and (tid is None or tid == expected['tid'])
    need(tid != expected['tid'] or pid == expected['pid'], 'reserved TID under foreign PID')
    if not reserved:
        return task(pid, current, tid)
    current['attempted_path'] = str(PROC / str(pid) / 'stat' if tid is None else
                                    PROC / str(pid) / 'task' / str(tid) / 'stat')
    try:
        row = task(pid, current, tid)
    except (OSError, ValueError, UnicodeError) as error:
        raise ValueError('reserved leader read uncertainty: ' + str(error)) from error
    need(all(row[key] == value for key,value in expected.items()),
         'reserved leader member/thread identity mismatch')
    return row


def census(expected, current):
    verify(expected, current['deadline'], current)
    for name in names(PROC, current):
        if not name.isascii() or not name.isdigit():
            continue
        pid = int(name)
        member = member_task(expected, pid, current)
        if member['pgid'] != expected['pgid']:
            continue
        need(member['sid'] == expected['sid'] and member['uid'] == expected['uid'],
             'group member ownership/session')
        for entry in names(PROC / name / 'task', current):
            need(entry.isascii() and entry.isdigit(), 'thread entry format')
            row = member_task(expected, pid, current, int(entry))
            need(row['pgid'] == expected['pgid'] and row['sid'] == expected['sid']
                 and row['uid'] == expected['uid'], 'thread ownership/session')
            need(len(current['records']) < 256, 'group thread bound')
            current['records'].append(row)
    current['records'].sort(key=lambda row: (row['pid'], row['tid']))
    need(any(row['pid'] == expected['pid'] and row['tid'] == expected['pid']
             and row['starttime'] == expected['starttime'] for row in current['records']),
         'reserved leader absent from census')
    tick(current, PROC, 0)
    current['complete'] = True
    return current


def acquire(expected, state, deadline):
    previous = None
    for round_number in range(1, 9):
        send(expected, signal.SIGSTOP, deadline)
        current = context(deadline)
        current['round'] = round_number
        try:
            census(expected, current)
            state['complete_censuses'] += 1
        except (OSError, ValueError, UnicodeError) as error:
            current.update(reason=str(error), complete=False)
            state['incomplete_censuses'] += 1
            state['failed_census'] = dict(current)
            state['latest_census'] = current
            if not isinstance(error, (FileNotFoundError, ProcessLookupError)):
                raise
        state['latest_census'] = current
        stopped = current['complete'] and all(row['state'] in 'TtZ'
                                               for row in current['records'])
        if stopped and previous == current['records']:
            return current
        previous = list(current['records']) if stopped else None
    raise ValueError('quiescent stable census round bound')


def new_state(expected):
    return dict(owner=expected, pauses=0, complete_censuses=0, incomplete_censuses=0,
                total_pause_ns=0, peak_pause_ns=0, resumes=0, status='UNOBSERVED')


def observe(expected, state, deadline, callback):
    start = time.monotonic_ns()
    pause_end = min(deadline, time.monotonic() + 0.5)
    state.update(pauses=state['pauses'] + 1, status='ACQUIRING')
    resumed = False
    try:
        current = acquire(expected, state, pause_end)
        need(time.monotonic() < pause_end, 'pre-inventory pause/wall deadline')
        state['status'] = 'QUIESCENT_OBSERVED'
        all_zombie = all(row['state'] == 'Z' for row in current['records'])
        result = callback(pause_end, not all_zombie)
        need(time.monotonic() < pause_end, 'post-inventory pause/wall deadline')
        verify(expected, pause_end)
        if not all_zombie:
            send(expected, signal.SIGCONT, pause_end)
            state['resumes'] += 1
            resumed = True
            need(time.monotonic() < pause_end, 'post-resume pause/wall deadline')
        state['status'] = 'COMPLETE'
        return result, all_zombie
    except (OSError, ValueError, UnicodeError) as error:
        state.update(status='FAILED_AFTER_RESUME' if resumed else 'FAILED_NO_RESUME',
                     reason=str(error))
        raise
    finally:
        elapsed = time.monotonic_ns() - start
        state['total_pause_ns'] += elapsed
        state['peak_pause_ns'] = max(state['peak_pause_ns'], elapsed)


def group_absent(group):
    current = context(time.monotonic() + 0.5)
    for name in names(PROC, current):
        if name.isascii() and name.isdigit():
            if task(int(name), current)['pgid'] == group:
                return False
    return True
