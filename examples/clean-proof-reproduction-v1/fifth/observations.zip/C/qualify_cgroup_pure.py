"""Prebudgeted current-source pure selection; never discover process controls."""
import json
import os
from pathlib import Path
import stat
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parent))
import clean_helpers as h
import test_cgroup as current
import test_clean_helpers as helper
import test_runtime_inventory as ipc
import test_review_repairs as repairs
import test_terminal_refusal as terminal
import test_directory_lifetime as lifetime

EXCLUDED=('test_short_success','test_nonzero_failure','test_timeout_kill_reap',
          'test_grandchild_group_reap','test_stream_overflow','test_storage_refusal')


def footprint(root):
    pending=[root];size=0
    for _ in range(8192):
        if not pending:return size
        path=pending.pop();info=path.lstat();size+=max(info.st_size,info.st_blocks*512)
        if stat.S_ISDIR(info.st_mode):
            with os.scandir(path) as iterator:
                for entry in iterator:
                    h.need(len(pending)<8192,'pure footprint entry bound');pending.append(Path(entry.path))
    raise ValueError('pure footprint iteration bound')


def selected(case,excluded=()):
    names=unittest.defaultTestLoader.getTestCaseNames(case)
    h.need(len(names)<=32 and all(name in names for name in excluded),'pure selection bound')
    return unittest.TestSuite(case(name) for name in names if name not in excluded)


class BoundedLog:
    def __init__(self,stream):self.stream=stream;self.used=0
    def write(self,value):
        size=len(value.encode('utf-8'))
        h.need(self.used+size<=32768,'pure raw log bound')
        self.used+=size;return self.stream.write(value)
    def flush(self):self.stream.flush()


def main():
    os.umask(0o077);mode='optimized' if sys.flags.optimize else 'normal'
    h.need(footprint(h.DESIGN)+98304+32768<=1048576,'pure peak+final write prebudget')
    root=h.DESIGN/('po3' if sys.flags.optimize else 'pn3');root.mkdir(mode=0o700)
    for index,module in enumerate((helper,ipc,repairs,terminal,lifetime)):
        module.ROOT=root/str(index);module.ROOT.mkdir(mode=0o700)
    suite=unittest.TestSuite([selected(current.Controls),selected(helper.Controls,EXCLUDED),
        selected(ipc.Controls,('test_real_owned_child_ipc_window','test_calendar_ceiling_and_headroom')),
        selected(repairs.Controls),selected(terminal.Control),selected(lifetime.Controls)])
    with (root/'unittest.stderr').open('x') as stream:
        result=unittest.TextTestRunner(stream=BoundedLog(stream),verbosity=2).run(suite)
    size=footprint(h.DESIGN);arena=footprint(root)
    status='PASS' if result.wasSuccessful() and size<=1048576 and arena<=98304 else 'FAILED'
    h.write(root/'report.json',dict(status=status,tests_run=result.testsRun,errors=len(result.errors),
        failures=len(result.failures),skipped=len(result.skipped),mode=mode,actual_controls=0,
        workspace_before_report=size,arena_before_report=arena,arena_reserved_bytes=98304,
        source_files={p.name:h.pin(h.read(p)) for p in h.DESIGN.glob('*.py')},
        exclusions=dict(helper=list(EXCLUDED),ipc=['test_real_owned_child_ipc_window',
            'test_calendar_ceiling_and_headroom: replaced by current adopted calendar controls']),
        actual_cgroup_process_signals_native='NOT_RUN'))
    h.need(footprint(h.DESIGN)<=1048576 and footprint(root)<=98304,'post-report footprint')
    return 0 if status=='PASS' else 1


if __name__=='__main__':raise SystemExit(main())
