"""One bounded owned cgroup phase; no global-proc or numeric-group fallback."""
import ctypes
import os
import selectors
import subprocess
import time

from clean_helpers import CAP,DESIGN,STREAM_CAP,need,pin,read
from runtime_inventory import exported,new_state,runtime_inventory,strict_readback
import cgroup_io as cg
import cgroup_phase as phase


def subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    need(libc.prctl(36,1,0,0,0)==0,'subreaper unavailable')


def reap_owned(deadline):
    records=[]
    for _ in range(256):
        need(time.monotonic()<deadline,'reap cleanup deadline')
        try:pid,status=os.waitpid(-1,os.WNOHANG)
        except ChildProcessError:return records
        need(pid!=0,'live adopted child after leaf empty')
        records.append(dict(pid=pid,status=status))
    raise ValueError('adopted reap bound')


def drain(selector,outputs,sizes):
    for key,_ in selector.select(timeout=0.01):
        try:block=os.read(key.fd,65536)
        except BlockingIOError:continue
        if not block:selector.unregister(key.fileobj);continue
        need(outputs[key.data].write(block)==len(block),'stream short write')
        outputs[key.data].flush();sizes[key.data]+=len(block)
        need(sizes[key.data]<=STREAM_CAP,'captured stream bound')


def spawn(lease,command,cwd,env,deadline):
    phase.pipes(lease)
    argv=['/usr/bin/python3','-I','-S','-B','-Werror',str(DESIGN/'clean_child.py')]
    argv += [str(lease['fds'][name]) for name in ('join','ready_w','go_r')]
    argv += [str(lease['control_identities']['join'][key]) for key in ('dev','ino','uid')]+command
    cg.check(lease,deadline)
    need(lease['extra_fds']==7,'Popen entry FD staging')
    for descriptor in (0,1,2):os.fstat(descriptor)
    cg.reserve(lease,7) # two output pipes(4), transient devnull(1), errorpipe(2).
    try:
        proc=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,
            close_fds=True,pass_fds=tuple(lease['fds'][n] for n in ('join','ready_w','go_r')))
    finally:cg.release(lease,7)
    cg.reserve(lease,2) # surviving Popen stdout/stderr read ends.
    return proc,argv


def outputs_open(lease,proc,task,label):
    cg.reserve(lease,3) # selector plus two retained evidence streams.
    selector=selectors.DefaultSelector();outputs={}
    try:
        for name in ('stdout','stderr'):
            outputs[name]=(task/(label+'.'+name)).open('xb')
            stream=getattr(proc,name);os.set_blocking(stream.fileno(),False)
            selector.register(stream,selectors.EVENT_READ,name)
    except BaseException:
        selector.close()
        for stream in outputs.values():stream.close()
        cg.release(lease,3);raise
    return selector,outputs


def monitor(lease,task,selector,outputs,deadline,cap,state,label):
    sizes=dict(stdout=0,stderr=0);peak=0
    def paused(end,active,publication_guard):
        state['quiescent_deadline']=end
        try:return runtime_inventory(task,state,label,active,cap,publication_guard,lease)
        finally:state.pop('quiescent_deadline',None)
    for _ in range(10000):
        need(time.monotonic()<deadline,'phase wall deadline')
        drain(selector,outputs,sizes)
        observed,empty=phase.observe(lease,deadline,paused)
        peak=max(peak,observed['bytes'])
        need(time.monotonic()<deadline,'post-observation phase deadline')
        if empty and not selector.get_map():
            return dict(peak_bytes=peak,stream_bytes=sizes,normal_terminal=True)
    raise ValueError('monitor iteration bound')


def cleanup(lease,proc,task,state,cap,outer):
    end=min(outer,time.monotonic()+3);lease['operations']=0
    result=dict(terminal_group_absent=False);errors={};empty=False
    for name in ('join','ready_w','go_r','ready_r','go_w'):
        if name in lease['fds']:
            try:cg.close_named(lease,name)
            except (OSError,ValueError) as error:errors['close_'+name]=str(error)
    try:
        cg.open_controls(lease,end)
    except (OSError,ValueError,UnicodeError) as error:errors['control_setup']=str(error)
    try:
        cg.write_fd(lease,'kill',b'1',end)
    except (OSError,ValueError,UnicodeError) as error:errors['kill']=str(error)
    try:
        if proc is not None:phase.pidfd_cleanup(lease,proc,end)
    except (OSError,ValueError,UnicodeError) as error:errors['prejoin']=str(error)
    lease['final_signalling_complete']=True
    try:phase.empty(lease,end);empty=True
    except (OSError,ValueError,UnicodeError) as error:errors['empty']=str(error)
    try:
        if proc is not None:
            proc.wait(timeout=max(0.001,min(2,end-time.monotonic())))
            result.update(returncode=proc.returncode,reaped_adopted=reap_owned(end))
        need(time.monotonic()<end,'cleanup wall deadline')
    except (OSError,ValueError,subprocess.SubprocessError) as error:errors['reap']=str(error)
    result['terminal_group_absent']=empty and 'reap' not in errors and not errors
    try:
        cg.reserve(lease,1) # The unchanged strict iterative validator opens at most one directory.
        try:strict_readback(task,state,cap)
        finally:cg.release(lease,1)
    except (OSError,ValueError) as error:errors['final_inventory']=str(error)
    try:
        need(empty and 'reap' not in errors,'unconfirmed empty/reap; retain leaf')
        phase.remove(lease,end)
    except (OSError,ValueError,UnicodeError) as error:errors['remove']=str(error)
    try:phase.close_handles(lease)
    except (OSError,ValueError) as error:errors['close']=str(error)
    if errors:result.update(status='FAILED',cleanup_failures=errors)
    return result


def resources_close(lease,proc,selector,outputs):
    errors=[]
    for stream in outputs.values():
        try:stream.close()
        except OSError as error:errors.append(str(error))
    if selector is not None:selector.close();cg.release(lease,3)
    if proc is not None:
        for name in ('stdout','stderr'):
            try:getattr(proc,name).close()
            except OSError as error:errors.append(str(error))
        cg.release(lease,2)
    need(not errors,'stream close failure '+str(errors))


def evidence(result,lease,state,task,label,argv,command,cwd,env,started,wall):
    result['runtime_inventory']=exported(state)
    result['cgroup']=phase.exported(lease) if lease is not None else dict(status='NOT_CREATED')
    result.update(argv=argv,command=command,cwd=str(cwd),environment=env,wall_start_ns=wall,
        elapsed_ns=int((time.monotonic()-started)*1e9),
        capture_complete=result.get('status') in ('SUCCESS','FAILED_PROCESS'))
    for name in ('stdout','stderr'):
        path=task/(label+'.'+name)
        result[name]=pin(read(path,STREAM_CAP+65536)) if path.exists() else dict(status='NOT_CREATED')
    return result


def run(command,task,cwd,env,label,duration,outer_deadline,cap=CAP,runtime_state=None):
    need(len(command)<=24 and duration>0,'command bound')
    need(hasattr(os,'pidfd_open') and hasattr(__import__('signal'),'pidfd_send_signal'),'pidfd APIs')
    state=new_state() if runtime_state is None else runtime_state
    started,wall=time.monotonic(),time.time_ns();deadline=min(started+duration,outer_deadline-3)
    proc=lease=selector=None;outputs={};result={};argv=[]
    subreaper()
    try:
        lease=cg.create(label,deadline);phase.initial(lease,deadline)
        proc,argv=spawn(lease,command,cwd,env,deadline)
        phase.after_spawn(lease,proc,deadline);phase.bootstrap(lease,proc,deadline)
        selector,outputs=outputs_open(lease,proc,task,label)
        result.update(monitor(lease,task,selector,outputs,deadline,cap,state,
                              'PROOF' if label=='proof' else 'BUILD'),status='MONITOR_COMPLETE')
    except (OSError,ValueError,UnicodeError,subprocess.SubprocessError) as error:
        result.update(status='FAILED',reason=str(error))
        if lease is None:lease=getattr(error,'cgroup_lease',None)
    finally:
        if lease is not None:
            try:
                if lease.get('created'):
                    result.update(cleanup(lease,proc,task,state,cap,outer_deadline))
                else:phase.close_handles(lease)
                if result.get('status')=='MONITOR_COMPLETE':
                    result['status']='SUCCESS' if proc.returncode==0 else 'FAILED_PROCESS'
            except (OSError,ValueError,UnicodeError,subprocess.SubprocessError) as error:
                result.update(status='FAILED',terminal_group_absent=False,cleanup_failure=str(error))
            try:resources_close(lease,proc,selector,outputs)
            except (OSError,ValueError) as error:result.update(status='FAILED',close_failure=str(error))
    return evidence(result,lease,state,task,label,argv,command,cwd,env,started,wall)
