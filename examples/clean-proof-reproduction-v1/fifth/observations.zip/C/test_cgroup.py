"""Current-source pure cgroup/FD/bootstrap/cleanup controls; no real kernel action."""
import ast
from contextlib import ExitStack
import errno
import os
from pathlib import Path
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import clean_helpers as h
import clean_process as process
import clean_child as child
import cgroup_io as cg
import cgroup_phase as phase
import runtime_inventory as runtime

OWNER=dict(pid=12345,tid=12345,pgid=12345,sid=12345,starttime=99,uid=os.getuid())


def lease():
    return dict(name=cg.PREFIX+'control1',fds={},extra_fds=0,peak_extra_fds=0,
                operations=0,total_operations=0,owner=dict(OWNER),write_sequence=0)


def info(ino,mode=stat.S_IFREG|0o600):
    return SimpleNamespace(st_dev=31,st_ino=ino,st_uid=os.getuid(),st_mode=mode)


class Controls(unittest.TestCase):
    def test_FD_budget_peak_and_uncertain_close(self):
        state=lease();cg.reserve(state,14);cg.reserve(state,2)
        self.assertEqual(state['peak_extra_fds'],16)
        with self.assertRaisesRegex(ValueError,'FD bound'):cg.reserve(state,1)
        state['fds']['failed']=100
        with patch.object(cg.os,'close',side_effect=OSError('fixed close failure')):
            with self.assertRaises(OSError):cg.close_named(state,'failed')
        self.assertEqual(state['extra_fds'],16)
        self.assertEqual(state['uncertain_fds'],{'failed':100})

    def test_control_writes_durable_before_post_tick(self):
        state=lease();state['fds']['freeze']=100
        with patch.object(cg,'check'),patch.object(cg,'tick',side_effect=[None,ValueError('post tick')]), \
             patch.object(cg.os,'write',return_value=1):
            with self.assertRaisesRegex(ValueError,'post tick'):cg.write_fd(state,'freeze',b'0',100)
        self.assertEqual(state['last_write']['value'],'0')
        self.assertEqual(state['last_write']['bytes'],1)
        self.assertEqual(state['last_write']['sequence'],1)

    def test_strict_events_and_membership_bounds(self):
        for raw in (b'frozen 1\n',b'frozen 1\nfrozen 1\npopulated 1\n',
                    b'frozen x\npopulated 1\n',b'frozen 1\npopulated 1\nextra 0\n'):
            with self.assertRaises(ValueError):cg.flat(raw,('populated','frozen'))
        for raw in (b'1\n1\n',b'0\n',b'x\n',b'1\n'*257):
            with self.assertRaises(ValueError):cg.numbers(raw)
        self.assertEqual(cg.flat(b'populated 0\nfrozen 1\n',('populated','frozen')),
                         dict(populated=0,frozen=1))

    def test_read_overrun_and_short_write(self):
        state=lease();state['fds'].update(events=100,kill=101)
        with patch.object(cg,'tick'),patch.object(cg.os,'lseek'), \
             patch.object(cg.os,'read',return_value=b'x'*4097):
            with self.assertRaisesRegex(ValueError,'read bound'):cg.read_fd(state,'events',100)
        with patch.object(cg,'tick'),patch.object(cg,'check'),patch.object(cg.os,'write',return_value=0):
            with self.assertRaisesRegex(ValueError,'short write'):cg.write_fd(state,'kill',b'1',100)
        self.assertEqual(state['last_write']['bytes'],0)

    def test_leaf_parent_join_FD_substitution(self):
        state=lease();parent=info(10,stat.S_IFDIR|0o755);leaf=info(11,stat.S_IFDIR|0o700)
        state.update(fds=dict(parent=10,leaf=11,join=12),parent_identity=cg.identity(parent),
                     leaf_identity=cg.identity(leaf),control_identities=dict(join=cg.identity(info(12))))
        def observed(fd):return {10:parent,11:leaf,12:info(999)}[fd]
        with patch.object(cg,'tick'),patch.object(cg.os,'stat',return_value=leaf), \
             patch.object(cg.os,'fstat',side_effect=observed):
            with self.assertRaisesRegex(ValueError,'control FD identity'):cg.check(state,100)
        for changed in (info(999,stat.S_IFDIR|0o700),info(11,stat.S_IFLNK|0o777)):
            with patch.object(cg,'tick'),patch.object(cg.os,'stat',return_value=changed), \
                 patch.object(cg.os,'fstat',side_effect=observed):
                with self.assertRaises(ValueError):cg.check(state,100)

    def test_existing_leaf_never_adopted(self):
        state=lease();parent=info(6496,stat.S_IFDIR|0o755)
        def opened(current,name,*_):current['fds'][name]=10;current['extra_fds']=1;return 10
        with patch.object(cg,'checked_open',side_effect=opened),patch.object(cg,'mount_check'), \
             patch.object(cg,'load',return_value={'local_read_only_observations':{'parent_identity':{'dev':31,'ino':6496}}}), \
             patch.object(cg.os,'fstat',return_value=parent),patch.object(cg.os,'mkdir',side_effect=FileExistsError('exists')):
            with self.assertRaises(FileExistsError) as captured:cg.create('build',100)
        self.assertFalse(captured.exception.cgroup_lease['created'])
        self.assertNotIn('leaf',captured.exception.cgroup_lease['fds'])

    def test_READY_exact_EOF_and_bad_messages(self):
        state=lease();state['fds']['ready_r']=100
        with patch.object(cg,'tick'),patch.object(phase.select,'select',return_value=([100],[],[])), \
             patch.object(phase.os,'read',side_effect=[b'READY\n',b'']):phase.ready(state,100)
        self.assertEqual(state['ready'],'EXACT_READY_AND_EOF')
        for messages in ([b''],[b'RE'],[b'x'*65],[b'READY\n',b'READY\n']):
            with patch.object(cg,'tick'),patch.object(phase.select,'select',return_value=([100],[],[])), \
                 patch.object(phase.os,'read',side_effect=messages):
                with self.assertRaises(ValueError):phase.ready(state,100)

    def test_extra_bootstrap_member_never_GO(self):
        state=lease();state['fds']['go_w']=100
        with patch.object(phase,'ready'),patch.object(cg,'check'),patch.object(phase,'controller_outside'), \
             patch.object(cg,'structure',return_value=dict(populated=1,frozen=0)), \
             patch.object(cg,'membership',return_value=([12345,12346],[12345])), \
             patch.object(phase.os,'write') as write:
            with self.assertRaisesRegex(ValueError,'extra bootstrap'):phase.bootstrap(state,Mock(pid=12345),100)
        write.assert_not_called();self.assertFalse(state.get('go_sent',False))

    def test_child_wait_GO_and_capability_closure(self):
        events=[];join_info=info(20)
        def fstat(fd):
            if not events:return join_info
            raise OSError(errno.EBADF,'closed')
        def write(fd,raw):events.append(('write',fd,raw));return len(raw)
        def close(fd):events.append(('close',fd))
        argv=['child','10','11','12','31','20',str(os.getuid()),'/fixed/native','--fixed']
        with patch.object(child.sys,'argv',argv),patch.object(child.os,'fstat',side_effect=fstat), \
             patch.object(child.resource,'setrlimit'),patch.object(child.os,'write',side_effect=write), \
             patch.object(child.os,'close',side_effect=close),patch.object(child.os,'read',side_effect=[b'GO\n',b'']), \
             patch.object(child.os,'execve',side_effect=SystemExit(0)) as execute:
            with self.assertRaises(SystemExit):child.main()
        execute.assert_called_once_with('/fixed/native',['/fixed/native','--fixed'],dict(os.environ))
        self.assertEqual(events,[('write',10,b'0'),('close',10),('write',11,b'READY\n'),
                                 ('close',11),('close',12)])

    def test_child_wrong_join_identity_no_write(self):
        argv=['child','10','11','12','31','999',str(os.getuid()),'/fixed/native']
        with patch.object(child.sys,'argv',argv),patch.object(child.os,'fstat',return_value=info(20)), \
             patch.object(child.os,'write') as write,patch.object(child.os,'execve') as execute:
            with self.assertRaisesRegex(ValueError,'join FD identity'):child.main()
        write.assert_not_called();execute.assert_not_called()

    def observe(self,bad=False,post_thaw=False):
        state=lease();events=[]
        def write(current,name,value,_deadline):
            current['write_sequence']+=1
            current['last_write']=dict(control=name,value=value.decode(),bytes=1,sequence=current['write_sequence'])
            events.append(value)
            if post_thaw and value==b'0':raise ValueError('post thaw expiry')
        def callback(_end,_active,guard):
            events.append('SCAN');guard()
            if bad:raise FileNotFoundError('listed entry missing')
            return dict(bytes=1)
        with patch.object(cg,'owner_check'),patch.object(cg,'write_fd',side_effect=write), \
             patch.object(phase,'acknowledgment'),patch.object(phase,'frozen',return_value=dict(populated=1,frozen=1)), \
             patch.object(cg,'membership'),patch.object(cg,'structure',return_value=dict(populated=1,frozen=1)), \
             patch.object(cg,'tick'):
            try:phase.observe(state,__import__('time').monotonic()+1,callback)
            except (OSError,ValueError):pass
        return state,events

    def test_freeze_scan_thaw_sequence(self):
        state,events=self.observe();self.assertEqual(events,[b'1','SCAN',b'0'])
        self.assertEqual(state['status'],'RUNNING')
        state,events=self.observe(bad=True);self.assertEqual(events,[b'1','SCAN'])
        self.assertEqual(state['status'],'FAILED_NO_THAW')

    def test_post_thaw_expiry_and_stale_marker(self):
        state,events=self.observe(post_thaw=True)
        self.assertEqual(state['status'],'FAILED_AFTER_THAW')
        state=lease();state.update(write_sequence=7,last_write=dict(control='freeze',value='0',bytes=1,sequence=7))
        with patch.object(cg,'owner_check',side_effect=ValueError('owner lost')):
            with self.assertRaises(ValueError):phase.observe(state,100,lambda *_:{})
        self.assertEqual(state['status'],'FAILED_NO_THAW')

    def test_owner_revalidated_even_empty_and_mismatch(self):
        for populated in (0,1):
            with patch.object(cg,'owner_check',side_effect=ValueError('owner mismatch')) as owner, \
                 patch.object(cg,'structure',return_value=dict(populated=populated,frozen=1)):
                with self.assertRaisesRegex(ValueError,'owner mismatch'):phase.frozen(lease(),100)
            owner.assert_called_once()
        current=lease()
        with patch.object(cg,'metadata',return_value=dict(OWNER,starttime=100)):
            with self.assertRaisesRegex(ValueError,'leader identity'):cg.owner_check(current,100)

    def test_no_ack_has_eight_polls(self):
        with patch.object(cg,'structure',return_value=dict(populated=1,frozen=0)) as states, \
             patch.object(phase.time,'sleep'):
            with self.assertRaisesRegex(ValueError,'poll bound'):phase.acknowledgment(lease(),1,100)
        self.assertEqual(states.call_count,8)

    def test_failed_publication_does_not_END(self):
        state=runtime.new_state()
        runtime.bind_directory(state,dict(path='tmp/end',st_dev=1,st_ino=1,uid=os.getuid(),mode=0o40700))
        work=runtime.lifetime.begin(state,'BUILD',True)
        def lost():raise ValueError('frozen acknowledgment lost at publication')
        with self.assertRaisesRegex(ValueError,'acknowledgment lost'):
            runtime.lifetime.commit(state,work,['tmp/end'],lost)
        self.assertEqual(state['lifetimes']['tmp/end']['status'],'ACTIVE')

    def test_cleanup_close_failure_continues_owned_kill(self):
        state=lease();state.update(created=True,fds=dict(ready_r=100,kill=101))
        events=[];proc=Mock(pid=12345,returncode=-9)
        with patch.object(cg,'close_named',side_effect=OSError('close fault')), \
             patch.object(cg,'write_fd',side_effect=lambda *_:events.append('KILL')), \
             patch.object(phase,'pidfd_cleanup',side_effect=lambda *_:events.append('PIDFD')), \
             patch.object(phase,'empty'),patch.object(process,'reap_owned',return_value=[]), \
             patch.object(process,'strict_readback'),patch.object(phase,'remove'),patch.object(phase,'close_handles'):
            result=process.cleanup(state,proc,Path('/fixed'),runtime.new_state(),1,__import__('time').monotonic()+5)
        self.assertEqual(events,['KILL','PIDFD'])
        self.assertEqual(result['status'],'FAILED');self.assertIn('close_ready_r',result['cleanup_failures'])

    def test_pidfd_failure_no_unreserved_signal(self):
        state=lease();state.update(joined=False,go_sent=True)
        with patch.object(cg,'tick'),patch.object(phase.os,'kill') as kill:
            with self.assertRaisesRegex(ValueError,'no pidfd after GO'):
                phase.pidfd_cleanup(state,Mock(pid=12345),100)
        kill.assert_not_called()

    def test_FD_staging_composition(self):
        state=lease();cg.reserve(state,7);cg.reserve(state,7)
        self.assertEqual(state['extra_fds'],14)
        cg.release(state,7);cg.reserve(state,2);cg.release(state,3)
        cg.reserve(state,1);cg.reserve(state,7)
        self.assertEqual(state['extra_fds'],14)
        cg.reserve(state,1);cg.release(state,1);cg.release(state,2)
        cg.reserve(state,3);cg.reserve(state,1)
        self.assertEqual(state['extra_fds'],16);self.assertEqual(state['peak_extra_fds'],16)

    def test_integrated_spawn_bootstrap_outputs_FD_accounting(self):
        state=lease();state['fds'].update(parent=10,leaf=11,join=12)
        state['control_identities']={'join':dict(dev=31,ino=12,uid=os.getuid())}
        cg.reserve(state,3);proc=Mock(pid=12345)
        proc.stdout.fileno.return_value=70;proc.stderr.fileno.return_value=71
        def popen(*args,**kwargs):
            self.assertEqual(state['extra_fds'],14)
            self.assertEqual(kwargs['pass_fds'],(12,41,42));return proc
        def controls(current,_deadline):
            for index,name in enumerate(cg.CONTROLS):
                cg.reserve(current,1);current['fds'][name]=80+index
        with ExitStack() as scope:
            for target,name,value in ((cg,'check',None),(cg.os,'close',None),
                    (cg.os,'fstat',info(1)),(cg.os,'set_blocking',None),
                    (cg,'pin_owner',dict(OWNER)),(cg.os,'pidfd_open',72),
                    (phase,'ready',None),(phase,'controller_outside',None),
                    (cg,'structure',dict(populated=1,frozen=0)),
                    (cg,'membership',([12345],[12345])),(cg,'owner_check',None),
                    (cg,'tick',None),(phase.os,'write',3)):
                scope.enter_context(patch.object(target,name,return_value=value))
            scope.enter_context(patch.object(cg.os,'pipe2',side_effect=[(40,41),(42,43)]))
            scope.enter_context(patch.object(process.subprocess,'Popen',side_effect=popen))
            scope.enter_context(patch.object(cg,'open_controls',side_effect=controls))
            child_proc,_=process.spawn(state,['/fixed/native'],Path('/fixed'),{},100)
            phase.after_spawn(state,child_proc,100)
            self.assertEqual(state['extra_fds'],14)
            phase.bootstrap(state,child_proc,100)
            self.assertEqual(state['extra_fds'],12)
            selector=Mock();scope.enter_context(patch.object(process.selectors,'DefaultSelector',return_value=selector))
            task=Mock();task.__truediv__=Mock(return_value=Mock())
            selector,outputs=process.outputs_open(state,child_proc,task,'control1')
            self.assertEqual(state['extra_fds'],15)
            cg.reserve(state,1);self.assertEqual(state['peak_extra_fds'],16);cg.release(state,1)
            process.resources_close(state,child_proc,selector,outputs)
            self.assertEqual(state['extra_fds'],10)
            phase.close_handles(state);self.assertEqual(state['extra_fds'],0)

    def test_partial_control_setup_still_attempts_owned_cleanup(self):
        state=lease();state.update(created=True,fds={'kill':101})
        events=[]
        with ExitStack() as scope:
            scope.enter_context(patch.object(cg,'open_controls',side_effect=ValueError('partial setup')))
            scope.enter_context(patch.object(cg,'write_fd',side_effect=lambda *_:events.append('KILL')))
            for target,name in ((phase,'empty'),(process,'strict_readback'),(phase,'remove'),(phase,'close_handles')):
                scope.enter_context(patch.object(target,name))
            result=process.cleanup(state,None,Path('/fixed'),runtime.new_state(),1,__import__('time').monotonic()+5)
        self.assertEqual(events,['KILL']);self.assertEqual(result['status'],'FAILED')
        self.assertIn('partial setup',result['cleanup_failures']['control_setup'])

    def test_current_calendar_strict_headroom(self):
        import clean_driver as driver
        from datetime import datetime
        end=datetime.fromisoformat('2026-10-29T23:14:00+00:00')
        with patch.object(driver,'calendar_ceiling',return_value=end):
            driver.calendar_check(end,end.timestamp()-451)
            for now in (end.timestamp()-450,end.timestamp()-449,
                        datetime.fromisoformat('2026-10-29T22:43:59+00:00').timestamp()):
                with self.assertRaises(ValueError):driver.calendar_check(end,now)

    def test_source_control_flow_and_functions(self):
        for path in h.DESIGN.glob('*.py'):
            raw=h.read(path);compile(raw,str(path),'exec',dont_inherit=True)
            for node in ast.walk(ast.parse(raw)):
                if isinstance(node,ast.FunctionDef):
                    self.assertLessEqual(node.end_lineno-node.lineno+1,60,path.name+':'+node.name)
        raw=h.read(h.DESIGN/'clean_process.py').decode()
        self.assertNotIn('proc.poll(',raw);self.assertNotIn('os.killpg(',raw)
