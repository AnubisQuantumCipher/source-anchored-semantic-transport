import pathlib,sys,time,io,unittest,hashlib,json,os
from unittest.mock import patch,Mock,MagicMock
C=pathlib.Path('/dev/shm/semantic-transport-proof-cgroup-design-20261029')
sys.path.insert(0,str(C));import test_cgroup as t
cg=t.cg;p=t.process;phase=t.phase
def audit(event,args):
 if event in ('subprocess.Popen','os.kill','os.killpg','os.fork','os.posix_spawn','os.exec','os.execve'):raise RuntimeError('forbidden actual control')
 if event=='open' and isinstance(args[0],str):
  if args[0].startswith(('/sys/fs/cgroup','/proc/')):raise RuntimeError('forbidden kernel read')
  if args[2]&3:raise RuntimeError('no writes')
sys.addaudithook(audit)
def forbidden_wait(*_):raise RuntimeError('forbidden raw waitpid')
os.waitpid=forbidden_wait
class Independent(unittest.TestCase):
 def test_missing_kill_handle_is_caught_and_prejoin_cleanup_continues(self):
  state=t.lease();state['fds']={};state['created']=True
  with patch.object(cg,'open_controls',side_effect=PermissionError('fixed missing control')),patch.object(cg,'check'),patch.object(cg,'tick'),patch.object(phase,'pidfd_cleanup') as prejoin,patch.object(phase,'empty'),patch.object(p,'reap_owned',return_value=[]),patch.object(p,'strict_readback'),patch.object(phase,'remove'),patch.object(phase,'close_handles'):
   outcome=p.cleanup(state,Mock(pid=12345),pathlib.Path('/fixed'),t.runtime.new_state(),1,time.monotonic()+5)
  prejoin.assert_called_once();self.assertEqual(outcome['status'],'FAILED');self.assertIn('control not open kill',outcome['cleanup_failures']['kill'])
 def test_spawn_Popen_raises_releases_transient_reservation(self):
  state=t.lease();state['fds']=dict(parent=10,leaf=11,join=12)
  state['control_identities']={'join':dict(dev=31,ino=12,uid=os.getuid())};cg.reserve(state,3)
  with patch.object(cg.os,'pipe2',side_effect=[(40,41),(42,43)]),patch.object(cg.os,'set_blocking'),patch.object(cg,'check'),patch.object(cg.os,'fstat',return_value=t.info(1)),patch.object(p.subprocess,'Popen',side_effect=OSError('fixed spawn refused')):
   with self.assertRaisesRegex(OSError,'spawn refused'):p.spawn(state,['/fixed/native'],pathlib.Path('/fixed'),{},time.monotonic()+1)
  self.assertEqual(state['extra_fds'],7);self.assertEqual(state['peak_extra_fds'],14)
 def test_output_open_partial_failure_closes_selector_stream_and_reservation(self):
  state=t.lease();cg.reserve(state,12);selector=Mock();proc=Mock();stream=Mock();target=MagicMock()
  target.__truediv__.return_value.open.side_effect=[stream,OSError('second output refused')]
  with patch.object(p.selectors,'DefaultSelector',return_value=selector),patch.object(p.os,'set_blocking'):
   with self.assertRaisesRegex(OSError,'second output'):p.outputs_open(state,proc,target,'control1')
  selector.close.assert_called_once();stream.close.assert_called_once();self.assertEqual(state['extra_fds'],12)
stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Independent))
print(json.dumps(dict(status='PASS_CORRECTED_MOCK_ISOLATION' if result.wasSuccessful() else 'FAILED',tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),optimize=sys.flags.optimize,blocker='PROVISIONAL_BLOCKER_DISPROVED_BY_CURRENT_GUARD',raw=stream.getvalue())))
if not result.wasSuccessful():raise ValueError('independent control failure')
