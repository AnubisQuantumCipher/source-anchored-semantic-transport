import pathlib,stat,json,hashlib,sys,io,unittest,os
from unittest.mock import patch
C=pathlib.Path('/dev/shm/semantic-transport-proof-cgroup-design-20261029')
R=pathlib.Path('/dev/shm/semantic-transport-cgroup-independent-review-20261029')
def require(ok,message):
 if not ok:raise ValueError(message)
def footprint(root):
 pending=[root];size=0;count=0
 while pending:
  p=pending.pop();s=p.lstat();count+=1;size+=max(s.st_size,s.st_blocks*512)
  require(count<=8192,'footprint entries')
  if stat.S_ISDIR(s.st_mode):pending.extend(p.iterdir())
 return dict(bytes=size,entries=count)
before=footprint(C);require(before['bytes']<=1048576,'C cap')
raw=(C/'runner-index.json').read_bytes()
require(hashlib.sha256(raw).hexdigest()=='1a4dfd81899fad0a709c305fe98e6766c8dc3395d73a8826b393927a29f68783','held index')
index=json.loads(raw)
for name,pin in index['files'].items():
 b=(C/name).read_bytes();require(len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],'pin '+name)
mode='optimized' if sys.flags.optimize else 'normal'
require(not (R/mode).exists(),'new reviewer arena')
require(footprint(R)['bytes']+112640<=262144,'review arena prebudget')
arena=R/mode;arena.mkdir(mode=0o700)
def audit(event,args):
 if event in ('subprocess.Popen','os.kill','os.killpg','os.fork','os.posix_spawn','os.exec','os.execve'):raise RuntimeError('forbidden actual process/signal/exec')
 if event=='open':
  p=args[0]
  if isinstance(p,str):
   require(not p.startswith('/sys/fs/cgroup'),'no actual cgroup open')
   require(not(p.startswith('/proc/') and p!='/proc/meminfo'),'no actual proc metadata')
   if args[2]&3:require(p.startswith(str(arena)+'/'),'write outside review arena')
 if event=='socket.bind':require(isinstance(args[1],str) and args[1].startswith(str(arena)+'/'),'foreign socket')
sys.addaudithook(audit);sys.path.insert(0,str(C))
import qualify_cgroup_pure as selection
for number,module in enumerate((selection.helper,selection.ipc,selection.repairs,selection.terminal,selection.lifetime)):
 module.ROOT=arena/str(number);module.ROOT.mkdir(mode=0o700)
suite=unittest.TestSuite([selection.selected(selection.current.Controls),selection.selected(selection.helper.Controls,selection.EXCLUDED),selection.selected(selection.ipc.Controls,('test_real_owned_child_ipc_window','test_calendar_ceiling_and_headroom')),selection.selected(selection.repairs.Controls),selection.selected(selection.terminal.Control),selection.selected(selection.lifetime.Controls)])
stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
after=footprint(C);own=footprint(arena);require(before==after,'C unchanged')
require(hashlib.sha256((C/'runner-index.json').read_bytes()).hexdigest()==index and False,'unused') if False else None
require(hashlib.sha256((C/'runner-index.json').read_bytes()).hexdigest()=='1a4dfd81899fad0a709c305fe98e6766c8dc3395d73a8826b393927a29f68783','index unchanged')
require(own['bytes']<=112640 and footprint(R)['bytes']<=262144,'review fixture cap')
output=dict(status='PASS' if result.wasSuccessful() else 'FAILED',tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),skipped=len(result.skipped),mode=mode,before=before,after=after,review_arena=own,review_total=footprint(R),C_writes=0,actual_process_cgroup_signal_controls=0,T5_absent=not pathlib.Path('/dev/shm/semantic-transport-proof-cgroup-20261029').exists(),raw_unittest_output=stream.getvalue())
print(json.dumps(output,sort_keys=True));require(result.wasSuccessful(),'tests failed')
