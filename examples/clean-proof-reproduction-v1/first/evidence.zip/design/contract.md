# Single clean native proof reproduction proposal

Status: FROZEN_DESIGN_NOT_EXECUTED. Owner admission and independent review remain pending. This is one local engineering reproduction, not a heldout/model/human campaign or a new development round.

Target HEAD b8aefc51a51d6f391e58460b95074f28f654f50a. Freeze the complete current proof04 source-manifest.json and tool-identities.json externally before execution. Compare all copied bytes to these held pins both before and after; source inventory must equal every .ads/.adb in evaluation/src and src plus evaluation/transport_core.gpr. The live inventory comparison found no missing/extra source names and no pin mismatch. Copy only these regular nonsymlink source members into a new private task/source tree, preserving relative layout. No old object, ALI, generated GPR config, VC, session, proof result, binary, or symlink is eligible input. Keep canonical source and binary paths untouched.

The project sets Source_Dirs to evaluation/src and src, Object_Dir/Exec_Dir through TRANSPORT_CORE_OBJ/BIN, and no imported projects or Proof_Dir override. -U covers all project files, including unused native units. A successful fresh run would reproduce current declared SPARK closure on this toolchain, with native IO/main entries explicitly SPARK Off, not whole-system correctness. All source exemptions and proof04 exclusions remain unchanged.

## Execution shape

Use a new mode-0700 /dev/shm task directory, exclusively owned by this attempt, separate from this design directory. All outputs, generated configs, TMPDIR, object/proof sessions, native executable and evidence live inside it. Refuse a pre-existing task/source, task/obj or task/bin. Assert empty obj/bin/tmp/cache locations before the first command; retain directory inventories. Original commands are exact apart from fresh source cwd and fresh absolute object/bin paths:

    timeout 120 gprbuild -p -P evaluation/transport_core.gpr \
      -XTRANSPORT_CORE_OBJ="$SAT_CORE_WORK/obj" \
      -XTRANSPORT_CORE_BIN="$SAT_CORE_WORK/bin"

    timeout 300 gnatprove -P evaluation/transport_core.gpr -U \
      --level=2 --report=all --warnings=error -j1 \
      --prover=z3 --timeout=1 --counterexamples=off \
      -XTRANSPORT_CORE_OBJ="$SAT_CORE_WORK/obj" \
      -XTRANSPORT_CORE_BIN="$SAT_CORE_WORK/bin"

Separate task-local build/proof stdout and stderr are mandatory. Record exact resolved executables, argv, cwd, sanitized environment, process statuses/signals, monotonic and wall timestamps, and source/tool pins. Set the original ulimit -v 1048576 (1 GiB address space per process); TMPDIR is task/tmp. Do not add -f, --clean, replay, output-msg-only, limit selectors, no-global-generation, alternate prover/config, weaker warning/contract options, larger timeout/memory/disk allowance, or retries. A zero process exit is insufficient: enforce oracle.json against the fresh report, individual unit rows and source bypass scan. No executable runtime tests or second native build are admitted by this item.

## Cache and environment boundary

Build/prove from a sanitized allowlist: fixed trusted toolchain PATH, fixed GPR_PROJECT_PATH containing only the two installed paths from env.sh, C locale, UTC, task TMPDIR and Python no-bytecode if the runner is Python. Preserve the existing HOME value if required by tool runtime; never redirect or edit it. Reject inherited WHY3CONFIG, extra GPR/ADA search paths, GCC_EXEC_PREFIX/COMPILER_PATH/LIBRARY_PATH, LD_PRELOAD/LD_LIBRARY_PATH, user gnatprove options, TRANSPORT_CORE_OBJ/BIN overrides, or provider/network cache settings. Construct argv explicitly; shell input cannot append flags.

Installed gnatprove help exposes --memcached-server=host:port and file:directory, --why3-conf, --replay, --output-msg-only and -m. None is allowed. gnatwhy3 help exposes --proof-dir for saved sessions/manual proofs. The fresh project has no Proof_Dir attribute. No old obj/gnatprove, proof/sessions, why3session.xml, spark result cache, memcached directory/service, or earlier task is copied or selected. At inspection ~/.why3.conf and ~/.config/why3.conf were absent; preflight must require they remain absent, and forbid other externally selected config. Pin installed gnatprove.conf and capture generated task-local Why3/GPR configuration to verify only the declared Z3 lane and no external result cache. If inspection cannot establish no old result/session inputs, label cleanliness UNKNOWN and FAIL this clean-reproduction claim.

This is clean PROJECT ARTIFACT reproduction on the existing trusted installed toolchain. Installed compiler/runtime libraries, GNATprove theories/drivers, OS libraries, filesystem/page caches and CPU caches are not rebuilt, emptied or formally verified. Selected executable hashes are observations, not a complete transitive toolchain attestation. There is no hostile same-user filesystem isolation proof or physical cold-cache claim. A successful build's binary need not match the canonical qualified binary and must never replace it.

## Resource admission and terminal outcome

Original 10 GB root reserve remains unchanged: root build/scratch/cache writes are prohibited while root is below reserve. No cleanup, iPad, install, network, outreach, release or spending is part of this item. At inspection root available bytes were 9036066816, /dev/shm available bytes 18502860800 and MemAvailable 20145332224; remeasure before owner admission.

Task storage ceiling: 268435456 bytes (256 MiB), including source copies, build/proof objects, tmp, executable, logs, config and evidence. Design allowance: 1048576 bytes, separate. Retain raw failures. Admit only when the 256 MiB reservation fits existing free tmpfs and memory headroom without reducing reserve policy; count existing task footprint before launch. Use a bounded sampling monitor with explicit byte/inode/time bounds, stop the complete owned process group on threshold violation, and retain measured peak and sampling interval. Such monitoring is a refusal threshold, not a filesystem quota or hard aggregate descendant containment; require the trusted toolchain not to escape its group. No resource escalation follows failure.

Recommendation: conditionally ready for independent review and one bounded owner admission, provided source/tool/environment checks and the task-local refusal monitor are implemented and reviewed before launch. Success narrows only the explicitly unclaimed clean-reproduction limitation in REPRODUCE.md:58-61. It cannot establish semantic fidelity, external validation, benefit, supported installation or final acceptance.
