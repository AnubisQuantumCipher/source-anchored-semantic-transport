# Reviewed single-attempt runner handoff

Implementation and synthetic-helper qualification only. Actual native build and proof remain NOT_RUN. The immutable contract.md, oracle-v2.json, index-v2.json and all original design files were preserved. Runner sources and final helper observations are bound by runner-index.json; owner must hold its digest independently and give it to the reviewer before launch.

The final helper suite ran 17 fixed tests under Python -I -S -B -Werror with no compiler/prover invocation. It covers summary positives and tampering (missing/duplicate units and total, nonzero unproved/justified/errors/warnings/Assume); input type/bounds/symlink refusal; duplicate JSON keys; source mutation/extra source; hash bounds/tamper; strict flags; capacity observations; environment sanitization; successful and nonzero short synthetic processes; stream/storage refusal; ignored TERM timeout escalated to KILL; adopted grandchild process-group cleanup and terminal group disappearance; and syntax/function bodies <=60 lines. Individual synthetic process records and raw stdout/stderr remain under helper-tests-05. helper-controls-final.json and .stderr are exact copies of the final observations.

The initial helper-tests-01 had all 15 unit controls pass, then failed its enclosing capacity check because product inventory correctly rejected an intentionally created test symlink. That failed enclosing command remains a failure. terminal-failure.json describes it. The corrected harness uses bounded nonfollowing design-footprint accounting. Exact prior source snapshots were reconstructed from the known edits and verified against each historical report's held byte hashes; source-snapshot under helper-tests-01/02 is labelled by that method here, not claimed as a contemporaneous capture. Later tests add source/capacity controls and strengthen nonzero summary diagnostics. All attempts and raw synthetic process evidence remain.

## Owner launch admission

After independent review of runner-index.json, owner may write a separately pinned UTF-8 JSON launch receipt with these fields:

    schema: transport/clean-proof-launch-admission/1
    status: ADMITTED_SINGLE_BUILD_AND_PROOF
    task_root: /dev/shm/semantic-transport-clean-proof-20261029
    source_head: value from oracle-v2.json
    design_index_sha256: digest of exact index-v2.json bytes
    runner_index_sha256: digest of exact runner-index.json bytes
    deadline_utc: timezone-qualified ISO8601 timestamp, no later than 2026-10-29T21:29:00+00:00

The runner requires 450 seconds to remain before that prepaid deadline at admission; it uses a finite monotonic outer deadline plus original 120/300-second command deadlines. No attempt is admitted if the fixed task directory already exists. There is no retry, resume, force, alternate task path, alternate flag, alternate model or extra campaign option.

Owner execution, only after separate launch admission:

    python3 -I -S -B -Werror /dev/shm/semantic-transport-clean-proof-20261029-design/clean_driver.py \
      --launch-admission /ABS/OWNER_LAUNCH_RECEIPT.json \
      --expect-launch-sha256 HELD_EXACT_RECEIPT_SHA256

The root report must retain the launch receipt, independently reviewed runner-index digest, actual command exit, task terminal.json and each build/proof process receipt. Missing terminal success, nonzero command exit or any FAILED status blocks the clean-reproduction claim. Root admission is not inferred from these instructions.

## Boundedness and trust

Source is copied only from exact source-manifest members into a newly created private tmpfs source tree. No old object, ALI, generated config, binary, VC or proof session is copied. All selected tool hashes and actual canonical qualified binary identity are checked before and after. The actual canonical path is read from the pinned existing native receipt; it is never guessed or executed. New native output must be a separate executable under task/bin and is never promoted.

The process helper sets Linux subreaper mode, uses a new process session, records PID/PGID, samples storage with at most 8192 entries and a finite 10000-iteration monitor, then sends bounded TERM/KILL and reaps before requiring group absence. Sampling is normally at most 50 ms apart plus bounded tree-scan time; it is not a hard quota, aggregate process-memory theorem or hostile escape containment. The trusted installed toolchain must not escape its group. RLIMIT_AS is the original 1 GiB; core dumps are disabled. Each captured stream has an 8 MiB refusal threshold, with at most one extra 65536-byte observed block retained to preserve overflow evidence. A failed stream can be incomplete and is explicitly marked capture_complete=false; no truncated stream can support success. Aggregate task storage remains 256 MiB with sampled fail-closed refusal and no escalation.

Generated GPR/Why3 configurations stay in task storage, are pinned and checked for external memcached/proof-dir/file cache selectors. The default Why3 configuration lists multiple provers, which is not itself use of those provers; actual immutable command selects Z3 only. No user Why3 configuration or inherited environment-selected cache path is admitted. Installed compiler/runtime libraries, prover theories/drivers, OS libraries and OS/CPU caches remain trusted and are not rebuilt or emptied. Cleanliness is specifically fresh project artifacts on the existing installed toolchain.

The source build and proof have not yet run. Whole-system proof, semantic fidelity, model behavior, task benefit, external validation and final acceptance remain unestablished by helper tests or a future scoped clean-proof success.
