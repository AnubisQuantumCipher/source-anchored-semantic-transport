"""One admitted clean native build/proof, with no retry or fallback."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from clean_helpers import (BUILD, CAP, DESIGN, PROVE, SOURCE, TASK, environment,
                           file_pin, inventory, load, need, pin, read,
                           source_check, summary, write)
from clean_process import run

IMPLEMENTATION_ADMISSION = Path('/home/sicarii/Projects/source-anchored-semantic-transport/evidence/acceptance-v1-preflight-20261029/engineering-admission-01/clean-repro-cli-boundary-admission-01.json')
CANONICAL_RECEIPT = SOURCE / 'examples/semantic-core-v3/evidence/native/receipt.json'


def options():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch-admission', required=True, type=Path)
    parser.add_argument('--expect-launch-sha256', required=True)
    args = parser.parse_args()
    need(len(sys.argv) == 5 and re.fullmatch('[0-9a-f]{64}',
         args.expect_launch_sha256) is not None, 'runner arguments')
    return args


def identities():
    spec = load(DESIGN / 'tool-identities.json')
    result = {}
    need(0 < len(spec['tools']) <= 32, 'tool inventory bound')
    for name, expected in spec['tools'].items():
        observed = file_pin(Path(name))
        need(observed == {k: expected[k] for k in ('bytes', 'sha256')}, 'tool pin')
        result[name] = observed
    result['/usr/bin/python3'] = file_pin(Path('/usr/bin/python3').resolve())
    result['/usr/bin/timeout'] = file_pin(Path('/usr/bin/timeout').resolve())
    frozen = load(DESIGN / 'runner-index.json')['launcher_tools']
    for path, expected in frozen.items():
        need(file_pin(Path(path).resolve()) == expected, 'launcher tool pin')
    return result


def admission(args):
    raw = read(args.launch_admission, 65536)
    need(pin(raw)['sha256'] == args.expect_launch_sha256, 'launch admission pin')
    value = load(args.launch_admission)
    need(value['schema'] == 'transport/clean-proof-launch-admission/1' and
         value['status'] == 'ADMITTED_SINGLE_BUILD_AND_PROOF', 'launch status')
    need(value['task_root'] == str(TASK), 'launch task path')
    need(value['source_head'] == load(DESIGN / 'oracle-v2.json')['source_head'], 'launch source')
    for key, name in [('design_index_sha256', 'index-v2.json'),
                      ('runner_index_sha256', 'runner-index.json')]:
        need(value[key] == pin(read(DESIGN / name))['sha256'], 'launch index pin')
    end = datetime.fromisoformat(value['deadline_utc'])
    need(end.tzinfo is not None, 'timezone missing')
    hard_end = datetime.fromisoformat('2026-10-29T21:29:00+00:00')
    need(end <= hard_end and time.time() + 450 < end.timestamp(), 'admission deadline')
    implementation = load(IMPLEMENTATION_ADMISSION)
    need(implementation['status'] ==
         'ADMITTED_RUNNER_IMPLEMENTATION_ONLY_EXECUTION_PENDING_REVIEW', 'implementation receipt')
    return value, raw, time.monotonic() + 450


def design_checks():
    for name in ('index-v2.json', 'runner-index.json'):
        index = load(DESIGN / name)
        need(0 < len(index['files']) <= 32, 'design inventory bound')
        for relative, expected in index['files'].items():
            path = Path(relative)
            need(len(path.parts) == 1 and path.name == relative, 'design path')
            need(pin(read(DESIGN / path, 4194304)) == expected, 'design file pin')
    oracle = load(DESIGN / 'oracle-v2.json')
    need(pin(read(DESIGN / oracle['source_manifest_path'])) ==
         oracle['source_manifest'], 'active manifest pin')
    return load(DESIGN / 'source-manifest.json'), oracle


def source_head():
    result = subprocess.run(['/usr/bin/git', '-C', str(SOURCE), 'rev-parse', 'HEAD'],
                            stdin=subprocess.DEVNULL, capture_output=True, timeout=3,
                            env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'})
    need(result.returncode == 0 and result.stderr == b'' and len(result.stdout) <= 128,
         'source HEAD command')
    return result.stdout.decode('ascii').strip()


def canonical():
    need(pin(read(CANONICAL_RECEIPT)) ==
         load(DESIGN / 'runner-index.json')['canonical_receipt'], 'canonical receipt pin')
    value = load(CANONICAL_RECEIPT)['binary']
    path = Path(value['path'])
    need(path.is_absolute() and not path.is_relative_to(TASK), 'canonical location')
    result = file_pin(path)
    need(result['sha256'] == value['sha256'], 'canonical qualified binary pin')
    return dict(path=str(path), **result, receipt=pin(read(CANONICAL_RECEIPT)))


def capacity():
    shm, root = os.statvfs('/dev/shm'), os.statvfs('/')
    with Path('/proc/meminfo').open('rb') as stream:
        raw = stream.read(65537)
    need(len(raw) <= 65536, 'memory observation bound')
    text = raw.decode('ascii')
    match = re.search(r'^MemAvailable:\s+(\d+) kB$', text, re.M)
    need(match is not None, 'memory observation')
    available = int(match.group(1)) * 1024
    need(shm.f_bavail * shm.f_frsize > CAP and available > CAP + 1073741824,
         'task memory/tmpfs admission')
    return dict(root_available=root.f_bavail * root.f_frsize,
                root_reserve=10000000000, tmpfs_available=shm.f_bavail * shm.f_frsize,
                memory_available=available, task_storage_cap=CAP,
                resource_contract='SAMPLED_STORAGE_REFUSAL_NOT_QUOTA')


def prepare(manifest):
    need(not os.path.lexists(str(TASK)), 'task already exists; no retry')
    TASK.mkdir(mode=0o700)
    for name in ('source', 'source/evaluation', 'source/evaluation/src', 'source/src',
                 'obj', 'bin', 'tmp'):
        (TASK / name).mkdir(mode=0o700)
    for item in manifest['items']:
        relative = Path(item['path'])
        raw = read(SOURCE / relative)
        with (TASK / 'source' / relative).open('xb') as stream:
            need(stream.write(raw) == len(raw), 'source copy write')
    source_check(TASK / 'source', manifest)
    for name in ('obj', 'bin', 'tmp'):
        need(not any((TASK / name).iterdir()), 'nonempty clean input')
    return inventory(TASK)


def commands():
    suffix = ['-XTRANSPORT_CORE_OBJ=' + str(TASK / 'obj'),
              '-XTRANSPORT_CORE_BIN=' + str(TASK / 'bin')]
    build = ['/usr/bin/timeout', '120', str(BUILD / 'bin/gprbuild'), '-p', '-P',
             'evaluation/transport_core.gpr'] + suffix
    proof = ['/usr/bin/timeout', '300', str(PROVE / 'bin/gnatprove'), '-P',
             'evaluation/transport_core.gpr', '-U', '--level=2', '--report=all',
             '--warnings=error', '-j1', '--prover=z3', '--timeout=1',
             '--counterexamples=off'] + suffix
    return build, proof


def configurations():
    state = inventory(TASK)
    found = {}
    for row in state['entries']:
        name = row['path']
        path = TASK / name
        if path.suffix in ('.conf', '.cgpr'):
            raw = read(path)
            need(not re.search(rb'memcached|spark_memcached_wrapper|--proof-dir|file:',
                               raw, re.I), 'external proof cache/config selection')
            found[name] = pin(raw)
    expected = 'obj/gnatprove/why3.conf'
    need(expected in found and b'command = "z3 -smt2' in read(TASK / expected),
         'generated Why3 Z3 lane missing')
    return found


def execute(manifest, oracle, env, outer):
    build, proof = commands()
    for label, command, duration in [('build', build, 120), ('proof', proof, 300)]:
        observed = run(command, TASK, TASK / 'source', env, label, duration, outer)
        write(TASK / (label + '-process.json'), observed)
        need(observed['status'] == 'SUCCESS' and observed['terminal_group_absent'],
             label + ' failed; attempt terminal')
        source_check(TASK / 'source', manifest)
        if label == 'build':
            need(not (TASK / 'obj/gnatprove').exists(), 'preproof session input')
            need(os.access(TASK / 'bin/transport_core_native', os.X_OK), 'built binary missing')
    report = summary(read(TASK / 'obj/gnatprove/gnatprove.out', 4194304), oracle)
    for label in ('build', 'proof'):
        for stream in ('stdout', 'stderr'):
            text = read(TASK / (label + '.' + stream), 8454144).decode('utf-8', 'strict')
            need(not re.search(r'\b(?:warning|error):', text, re.I), 'stream diagnostic')
    return dict(proof=report, generated_configurations=configurations(),
                built_binary=file_pin(TASK / 'bin/transport_core_native'))


def main():
    os.umask(0o077)
    result = dict(schema='transport/clean-proof-run/1', status='FAILED', authority='NONE')
    args = options()
    admitted, admission_raw, outer = admission(args)
    manifest, oracle = design_checks()
    need(source_head() == oracle['source_head'], 'current source HEAD')
    source_check(SOURCE, manifest)
    before_tools, before_binary = identities(), canonical()
    env, space = environment(TASK), capacity()
    need(not os.path.lexists(str(TASK)), 'task already exists; no retry')
    try:
        before_inventory = prepare(manifest)
        write(TASK / 'launch-admission.json', admitted)
        write(TASK / 'before.json', dict(source=source_check(SOURCE, manifest),
              tools=before_tools, canonical=before_binary, capacity=space,
              empty_state_inventory=before_inventory, environment=env,
              launch_admission_pin=pin(admission_raw)))
        result.update(execute(manifest, oracle, env, outer), status='PASS_CLEAN_PROJECT_PROOF')
    except (OSError, ValueError, subprocess.SubprocessError, UnicodeError) as error:
        result.update(status='FAILED', reason=str(error))
    finally:
        try:
            result['source_after'] = source_check(SOURCE, manifest)
            result['copy_after'] = source_check(TASK / 'source', manifest)
            need(canonical() == before_binary, 'canonical binary changed')
            need(identities() == before_tools, 'tool identities changed')
            need(environment(TASK) == env, 'environment/user configuration changed')
            result['canonical_unchanged'] = True
            result['tools_unchanged'] = True
            result['after_inventory'] = inventory(TASK)
        except (OSError, ValueError) as error:
            result.update(status='FAILED', final_verification_error=str(error))
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write(TASK / 'terminal.json', result)
    print(json.dumps(dict(status=result['status'], terminal=str(TASK / 'terminal.json'))))
    return 0 if result['status'] == 'PASS_CLEAN_PROJECT_PROOF' else 1


if __name__ == '__main__':
    raise SystemExit(main())
