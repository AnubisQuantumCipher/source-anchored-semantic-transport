This is the reviewed deletion-only directory-lifetime supervisor implementation.
Current authority is the pinned proof-lifetime implementation-only root grant;
historical N/P grants, index status strings and failed attempts grant no launch.
T1 and T2 remain FAILED. T3 has not been created or executed. Native compatibility
and complete clean proof remain UNPROVEN.

Only strict descendants of task/tmp may transition ACTIVE to ENDED. All entries,
including regular files, are reconciled against historical directory paths.
Only a complete, error-free scan followed by persistent and surviving metadata
checks commits staged END records. Listed lstat ENOENT fails UNKNOWN. tmp itself,
source directories, obj/bin, conditional obj/gnatprove and every directory outside
tmp remain persistent. Tombstones are cumulative (8192); reappearance fails with
same or changed identity. The single attempt IPC registry (16) is never reset.

Initial prepare is followed by prime_state before any child launch. Final strict
inventory remains the original regular-only validator; inactive lifetime binding
readback independently runs after it, and the driver exports final state after
all callbacks. Latest failed observation remains available after a later complete
cleanup; END records retain completed observation identity, phase and time.
Metadata observations are bounded walks, not atomic snapshots or authenticated
creator/deletion provenance. Trusted installed tools and local private-task/OS
assumptions remain. No special member is opened/read/connected/executed.

baseline-n-v3-complete.zip preserves all N-v3 indexed members and its exact index
as inert regular data; baseline-v3 holds exact original active source for direct
diff review. lifetime-final-v1.diff explains every active-source difference.
qualification-evidence-v1.zip holds current PASS report/stdout-independent raw
unittest stderr; qualification-report-v1.json pins current source and each member.
The earlier FAILED control-only assertion and exact sources are preserved in
qualification-evidence.zip / lifetime-control-first-failure-sources.zip. It was a
wrong test-key label, not native execution; it remains FAILED.

commands.json freezes unchanged 120-second build and 300-second -U --level=2,
-j1, z3 --timeout=1 proof commands, except fixed fresh T3 obj/bin paths, plus exact
synthetic test commands. AS=1GiB, task=256MiB, entries=8192, evidence file=4MiB,
outer=450s and reviewed calendar ceiling 22:29 UTC stay unchanged. Successful
launch needs 450s remaining, independent implementation review PASS and a new
held-SHA launch receipt. No automatic retry, deadline extension or escalation.

After separate owner admission only, the fixed command is:
/usr/bin/python3 -I -S -B -Werror /dev/shm/semantic-transport-proof-lifetime-design-20261029/clean_driver.py --launch-admission OWNER_JSON --expect-launch-sha256 HELD_SHA256
The placeholders are not a launch authorization. No compiler/prover/native action
occurred during this implementation qualification.
