"""Targeted synthetic controls for the two independently seeded review failures."""
import ast
import json
import os
from pathlib import Path
import stat
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import clean_driver as driver
import clean_helpers as h
import runtime_inventory as r

ROOT=h.DESIGN/'repair-tests-02'


class Controls(unittest.TestCase):
    def tree(self,name):
        root=ROOT/name
        (root/'tmp').mkdir(mode=0o700,parents=True)
        return root

    def test_second_ancestor_lstat_failure(self):
        root=self.tree('stat-error')
        fifo=root/'tmp/pipe';os.mkfifo(fifo,0o600)
        actual=Path.lstat;calls=[];state=r.new_state()
        def seeded(path):
            if path==root/'tmp':
                calls.append(str(path))
                if len(calls)==2:raise FileNotFoundError('fixed second tmp lstat')
            return actual(path)
        try:
            with patch.object(Path,'lstat',seeded):
                with self.assertRaisesRegex(OSError,'second tmp'):
                    r.runtime_inventory(root,state,'PROOF',True)
            self.assertEqual(len(calls),2)
            self.assertEqual(state['refusal']['path'],'tmp')
            self.assertEqual(state['refusal']['type'],'UNKNOWN')
            self.assertEqual(state['refusal']['st_ino'],'UNKNOWN')
            self.assertEqual(state['refusal']['phase'],'PROOF')
            self.assertIn('partial_bytes',state['refusal'])
        finally:fifo.unlink()

    def test_ancestor_type_failure_preserves_metadata(self):
        root=self.tree('type-error')
        fifo=root/'tmp/pipe';os.mkfifo(fifo,0o600)
        actual=Path.lstat;calls=[];state=r.new_state()
        replacement=(root/'tmp/pipe').lstat()
        def seeded(path):
            if path==root/'tmp':
                calls.append(str(path))
                if len(calls)==2:return replacement
            return actual(path)
        try:
            with patch.object(Path,'lstat',seeded):
                with self.assertRaisesRegex(ValueError,'ancestor symlink/type'):
                    r.runtime_inventory(root,state,'PROOF',True)
            observed=state['refusal']
            self.assertEqual(observed['path'],'tmp')
            self.assertEqual(observed['type'],'S_IFIFO')
            self.assertEqual(observed['st_ino'],replacement.st_ino)
            self.assertEqual(observed['mode'],replacement.st_mode)
        finally:fifo.unlink()

    def test_final_writable_directory_refuses(self):
        root=self.tree('writable');state=r.new_state()
        r.runtime_inventory(root,state,'PROOF',True)
        (root/'tmp').chmod(0o722)
        h.inventory(root)
        with self.assertRaisesRegex(ValueError,'replaceable directory'):
            r.strict_readback(root,state)
        self.assertEqual(state['refusal']['path'],'tmp')
        self.assertEqual(state['refusal']['phase'],'FINAL')

    def test_final_replaced_directory_refuses(self):
        root=self.tree('replaced');state=r.new_state()
        r.runtime_inventory(root,state,'PROOF',True)
        (root/'tmp').rename(root/'old-tmp')
        (root/'tmp').mkdir(mode=0o700)
        h.inventory(root)
        with self.assertRaisesRegex(ValueError,'identity changed'):
            r.strict_readback(root,state)
        self.assertEqual(state['refusal']['path'],'tmp')

    def test_final_missing_bound_directory_refuses(self):
        root=self.tree('missing');state=r.new_state()
        r.runtime_inventory(root,state,'PROOF',True)
        (root/'tmp').rmdir()
        h.inventory(root)
        with self.assertRaises(OSError):r.strict_readback(root,state)
        self.assertEqual(state['refusal']['path'],'tmp')
        self.assertEqual(state['refusal']['type'],'UNKNOWN')

    def test_both_final_validators_attempted(self):
        attempted=[];state=r.new_state()
        def strict(*_):attempted.append('strict');raise ValueError('fixed strict failure')
        def bound(*_):attempted.append('binding');raise ValueError('fixed binding failure')
        with patch.object(r,'inventory',strict),patch.object(r,'binding_readback',bound):
            with self.assertRaisesRegex(ValueError,'strict failure'):
                r.strict_readback(ROOT,state)
        self.assertEqual(attempted,['strict','binding'])

    def test_driver_final_binding_check_is_independent(self):
        attempted=[]
        def bad(*_):attempted.append('source');raise ValueError('seeded source failure')
        def observed(name,value):attempted.append(name);return value
        with patch.object(driver,'source_check',bad), \
             patch.object(driver,'canonical',lambda:observed('canonical',{})), \
             patch.object(driver,'identities',lambda:observed('tools',{})), \
             patch.object(driver,'environment',lambda _:observed('environment',{})), \
             patch.object(driver,'inventory',lambda _:observed('inventory',{})), \
             patch.object(driver,'strict_readback',lambda *_:observed('bindings',{})):
            result=driver.final_checks({}, {}, {}, {},r.new_state())
        self.assertEqual(attempted,['source','source','canonical','tools','environment',
                                    'inventory','bindings'])
        self.assertIn('private_bindings_after',result['observations'])
        self.assertEqual(set(result['failures']),{'source_after','copy_after'})

    def test_final_success_no_registry_reset(self):
        root=self.tree('positive');state=r.new_state()
        r.runtime_inventory(root,state,'BUILD',True)
        entry=dict(path='tmp/old',st_dev=1,st_ino=1,type='S_IFSOCK',phase='BUILD',
                   observation_time_ns=1,uid=os.getuid(),nlink=1)
        r.admit_ipc(state,entry,True)
        r.strict_readback(root,state)
        self.assertEqual(len(state['registry']),1)
        self.assertEqual(state['current_count'],0)

    def test_function_size_and_strict_source_continuity(self):
        for path in h.DESIGN.glob('*.py'):
            raw=h.read(path);compile(raw,str(path),'exec',dont_inherit=True)
            for node in ast.walk(ast.parse(raw)):
                if isinstance(node,ast.FunctionDef):
                    self.assertLessEqual(node.end_lineno-node.lineno+1,60,
                                         path.name+':'+node.name)
        before=(h.DESIGN/'baseline-v3/clean_helpers.py').read_text()
        after=(h.DESIGN/'clean_helpers.py').read_text()
        for name in ('inventory','source_check','summary'):
            segments=[]
            for raw in (before,after):
                node=next(n for n in ast.parse(raw).body if
                          isinstance(n,ast.FunctionDef) and n.name==name)
                segments.append(ast.get_source_segment(raw,node))
            self.assertEqual(*segments)


def main():
    os.umask(0o077);ROOT.mkdir(mode=0o700,exist_ok=False)
    with (ROOT/'unittest.stderr').open('x') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
    h.write(ROOT/'report.json',dict(status='PASS' if result.wasSuccessful() else 'FAILED',
        tests_run=result.testsRun,errors=len(result.errors),failures=len(result.failures),
        skipped=len(result.skipped),scope='TARGETED_REVIEW_REPAIR_CONTROLS_ONLY',
        actual_native_execution='NOT_RUN',source_files={p.name:h.pin(h.read(p))
            for p in h.DESIGN.glob('*.py')}))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':
    raise SystemExit(main())
