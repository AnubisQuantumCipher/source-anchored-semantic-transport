"""Synthetic controls for frozen L01..L14 and review staging clarifications."""
import ast
import json
import os
from pathlib import Path
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import clean_driver as driver
import clean_helpers as h
import directory_lifetime as life
import runtime_inventory as r

ROOT = h.DESIGN / 'lifetime-tests-03'


class Controls(unittest.TestCase):
    def tree(self, name):
        root = ROOT / name
        for path in ('source/evaluation/src', 'obj', 'bin', 'tmp/GPR.x'):
            (root / path).mkdir(mode=0o700, parents=True)
        state = r.new_state()
        r.prime_state(root, state)
        return root, state

    def test_L01_L11_complete_absence_and_snapshot(self):
        root, state = self.tree('stable')
        r.runtime_inventory(root, state, 'BUILD', True)
        record = dict(state['lifetimes']['tmp/GPR.x'])
        (root / 'tmp/GPR.x').rmdir()
        r.runtime_inventory(root, state, 'PROOF', True)
        ended = state['lifetimes']['tmp/GPR.x']
        self.assertEqual(ended['status'], 'ENDED')
        self.assertEqual(ended['st_ino'], record['st_ino'])
        self.assertEqual(ended['end_observation'], 3)
        self.assertEqual(ended['end_observation_status'], 'COMPLETE')
        self.assertEqual(ended['end_observed_phase'], 'PROOF')
        self.assertEqual(ended['first_phase'], 'INITIAL')
        self.assertEqual(ended['owner_uid'], os.getuid())
        self.assertEqual(state['observation']['id'], 3)
        self.assertEqual(state['observation']['status'], 'COMPLETE')
        self.assertEqual(state['observation']['committed_ends'], ['tmp/GPR.x'])
        self.assertEqual(state['observation']['phase'], 'PROOF')
        self.assertTrue(state['observation']['group_active'])
        self.assertLessEqual(state['observation']['begin_time_ns'],
                             state['observation']['end_time_ns'])
        r.strict_readback(root, state)
        self.assertEqual(state['lifetimes']['tmp/GPR.x'], ended)
        self.assertEqual(len(state['lifetimes']), len(state['bindings']))

    def test_L02_L03_L04_L05_missing_persistent(self):
        for label, relative in [('L02','tmp'), ('L03','source/evaluation/src'),
                                ('L04','obj/gnatprove'), ('L05','obj/ordinary')]:
            root, state = self.tree(label)
            if relative.startswith('obj/'):
                (root / relative).mkdir(mode=0o700)
                r.runtime_inventory(root, state, 'BUILD', True)
            (root / 'tmp/GPR.x').rmdir()
            (root / relative).rmdir()
            with self.assertRaises(OSError):
                r.strict_readback(root, state)
            self.assertEqual(state['refusal']['path'], relative)
            self.assertEqual(state['refusal']['type'], 'UNKNOWN')
            self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')
            self.assertEqual(state['observation']['committed_ends'], [])

    def test_L06_active_identity_replaced(self):
        root, state = self.tree('live-replacement')
        (root / 'tmp/GPR.x').rename(root / 'tmp/retained-original')
        (root / 'tmp/GPR.x').mkdir(mode=0o700)
        with self.assertRaisesRegex(ValueError, 'identity changed'):
            r.runtime_inventory(root, state, 'PROOF', True)
        self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')

    def test_L07_same_and_changed_inode_reappearance(self):
        for label, same in [('same',True), ('changed',False)]:
            root, state = self.tree('reappear-' + label)
            original = (root / 'tmp/GPR.x').lstat().st_ino
            if same:
                (root / 'tmp/GPR.x').rename(ROOT / ('held-' + label))
            else:
                (root / 'tmp/GPR.x').rmdir()
            r.runtime_inventory(root, state, 'BUILD', True)
            if same:
                (ROOT / ('held-' + label)).rename(root / 'tmp/GPR.x')
                self.assertEqual((root / 'tmp/GPR.x').lstat().st_ino, original)
            else:
                (root / 'tmp/GPR.x').mkdir(mode=0o700)
            with self.assertRaises(ValueError):
                r.runtime_inventory(root, state, 'PROOF', True)
            self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ENDED')

    def test_L08_present_regular_is_not_absent(self):
        root, state = self.tree('regular')
        (root / 'tmp/GPR.x').rmdir()
        (root / 'tmp/GPR.x').write_bytes(b'fixed')
        with self.assertRaisesRegex(ValueError, 'present wrong type'):
            r.runtime_inventory(root, state, 'PROOF', True)
        self.assertEqual(state['refusal']['type'], 'S_IFREG')
        self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')
        self.assertEqual(state['observation']['committed_ends'], [])

    def test_L08_writable_symlink_and_wrong_owner(self):
        for label in ('writable', 'symlink', 'owner'):
            root, state = self.tree(label)
            target = root / 'tmp/GPR.x'
            actual = Path.lstat
            if label == 'writable': target.chmod(0o722)
            if label == 'symlink':
                target.rmdir(); target.symlink_to(root / 'obj', target_is_directory=True)
            def seeded(path):
                info = actual(path)
                if label == 'owner' and path == target:
                    names = ('st_mode','st_uid','st_nlink','st_size','st_blocks',
                             'st_dev','st_ino','st_ctime_ns','st_mtime_ns')
                    return SimpleNamespace(**{key: info.st_uid + 1 if key == 'st_uid'
                                               else getattr(info,key) for key in names})
                return info
            with patch.object(Path, 'lstat', seeded):
                with self.assertRaises(ValueError):
                    r.runtime_inventory(root, state, 'PROOF', True)
            self.assertEqual(state['refusal']['path'], 'tmp/GPR.x')
            self.assertNotEqual(state['refusal']['type'], 'UNKNOWN')
            self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')

    def test_L09_listed_lstat_ENOENT_is_unknown(self):
        root, state = self.tree('listed-race')
        actual = Path.lstat
        def seeded(path):
            if path == root / 'tmp/GPR.x':
                raise FileNotFoundError('fixed listed entry race')
            return actual(path)
        with patch.object(Path, 'lstat', seeded):
            with self.assertRaises(OSError):
                r.runtime_inventory(root, state, 'BUILD', True)
        self.assertEqual(state['refusal']['path'], 'tmp/GPR.x')
        self.assertEqual(state['refusal']['type'], 'UNKNOWN')
        self.assertEqual(state['observation']['status'], 'ERROR')
        self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')
        r.strict_readback(root, state)
        self.assertEqual(state['last_failed_observation']['status'], 'ERROR')
        self.assertEqual(state['last_failed_observation']['id'], 2)
        self.assertEqual(state['observation']['status'], 'COMPLETE')

    def test_L10_partial_storage_and_late_failure_no_commit(self):
        root, state = self.tree('partial')
        (root / 'tmp/GPR.x').rmdir()
        with self.assertRaisesRegex(ValueError, 'storage bound'):
            r.runtime_inventory(root, state, 'BUILD', True, cap=1)
        self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')
        self.assertEqual(state['observation']['committed_ends'], [])
        original = r.read_directory
        def seeded(path, *args):
            if path == root / 'obj': raise OSError('fixed late surviving readback')
            return original(path, *args)
        with patch.object(r, 'read_directory', seeded):
            with self.assertRaises(OSError):
                r.runtime_inventory(root, state, 'PROOF', True)
        self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ACTIVE')
        self.assertEqual(state['observation']['committed_ends'], [])
        self.assertEqual(state['observation']['status'], 'ERROR')

    def test_L11_IPC_history_survives_ended_tmp(self):
        root, state = self.tree('no-reset')
        row = dict(path='tmp/GPR.x/pipe', st_dev=1, st_ino=9, type='S_IFIFO',
                   phase='BUILD', observation_time_ns=1, uid=os.getuid(), nlink=1)
        r.admit_ipc(state, row, True)
        registry = dict(state['registry'])
        (root / 'tmp/GPR.x').rmdir()
        r.runtime_inventory(root, state, 'PROOF', True)
        r.strict_readback(root, state)
        self.assertEqual(state['registry'], registry)
        self.assertEqual(state['lifetimes']['tmp/GPR.x']['status'], 'ENDED')
        self.assertEqual(len(state['registry']), 1)

    def test_L12_cumulative_tombstone_bound_no_eviction(self):
        state = r.new_state()
        for index in range(h.ENTRIES):
            row = dict(path='tmp/' + str(index), st_dev=1, st_ino=index,
                       uid=os.getuid(), mode=0o40700)
            r.bind_directory(state, row)
            state['lifetimes'][row['path']]['status'] = 'ENDED'
        with self.assertRaisesRegex(ValueError, 'binding bound'):
            r.bind_directory(state, dict(path='tmp/overflow', st_dev=1,
                st_ino=h.ENTRIES, uid=os.getuid(), mode=0o40700))
        self.assertEqual(len(state['lifetimes']), h.ENTRIES)
        self.assertEqual(len(state['bindings']), h.ENTRIES)
        self.assertTrue(all(row['status'] == 'ENDED' for row in state['lifetimes'].values()))

    def test_L13_final_IPC_stays_rejected(self):
        root, state = self.tree('final-ipc')
        fifo = root / 'tmp/pipe'; os.mkfifo(fifo, 0o600)
        try:
            r.runtime_inventory(root, state, 'BUILD', True)
            with self.assertRaises(ValueError): r.strict_readback(root, state)
            self.assertEqual(state['refusal']['path'], 'tmp/pipe')
            self.assertEqual(state['refusal']['type'], 'S_IFIFO')
        finally: fifo.unlink()

    def test_L14_all_callbacks_and_final_metadata(self):
        root, state = self.tree('callbacks')
        (root / 'obj').rmdir(); attempted = []
        def source(*_): attempted.append('source'); raise ValueError('fixed source failure')
        def value(name): attempted.append(name); return {}
        with patch.object(driver, 'TASK', root), \
             patch.object(driver, 'source_check', source), \
             patch.object(driver, 'canonical', lambda: value('canonical')), \
             patch.object(driver, 'identities', lambda: value('tools')), \
             patch.object(driver, 'environment', lambda _: value('environment')):
            result = driver.final_checks({}, {}, {}, {}, state)
        self.assertEqual(attempted, ['source','source','canonical','tools','environment'])
        self.assertIn('inventory_after', result['observations'])
        self.assertIn('private_bindings_after', result['failures'])
        exported = r.exported(state)
        self.assertEqual(exported['refusal']['path'], 'obj')
        self.assertEqual(exported['refusal']['type'], 'UNKNOWN')
        self.assertEqual(exported['refusal']['observation_id'], 2)
        self.assertEqual(exported['observation']['status'], 'ERROR')
        for key in ('partial_bytes', 'peak_bytes', 'visited', 'pending'):
            self.assertIn(key, exported['refusal'])

    def test_frozen_oracles_and_function_bounds(self):
        oracle = h.load(h.DESIGN / 'lifetime-contract.json')['literal_oracles']
        self.assertEqual([row[0] for row in oracle],
            ['L01','L02','L03','L04','L05','L06','L07','L08','L09','L10','L11','L12','L13','L14'])
        for path in h.DESIGN.glob('*.py'):
            raw = h.read(path); compile(raw, str(path), 'exec', dont_inherit=True)
            for node in ast.walk(ast.parse(raw)):
                if isinstance(node, ast.FunctionDef):
                    self.assertLessEqual(node.end_lineno-node.lineno+1, 60, path.name+':'+node.name)


def main():
    os.umask(0o077); ROOT.mkdir(mode=0o700, exist_ok=False)
    with (ROOT / 'unittest.stderr').open('x') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(Controls))
    h.write(ROOT / 'report.json', dict(status='PASS' if result.wasSuccessful() else 'FAILED',
        tests_run=result.testsRun, errors=len(result.errors), failures=len(result.failures),
        skipped=len(result.skipped), actual_native_execution='NOT_RUN',
        frozen_oracle=h.pin(h.read(h.DESIGN/'lifetime-contract.json')),
        source_files={p.name:h.pin(h.read(p)) for p in h.DESIGN.glob('*.py')}))
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
