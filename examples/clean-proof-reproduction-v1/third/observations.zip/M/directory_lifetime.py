"""Deletion-only tmp directory history, committed after a complete checked walk."""
import time

from clean_helpers import ENTRIES, need


def begin(state, phase, active):
    sequence = state.get('observation_id', 0) + 1
    need(sequence <= 65536, 'observation count bound')
    state['observation_id'] = sequence
    work = dict(state)
    work['bindings'] = dict(state['bindings'])
    work['lifetimes'] = {key: dict(value) for key, value in
                         state.get('lifetimes', {}).items()}
    work['observation'] = dict(id=sequence, phase=phase, group_active=active,
        begin_time_ns=time.time_ns(), status='IN_PROGRESS', current_entries=[])
    return work


def observe(state, row):
    history = state.setdefault('lifetimes', {})
    path = row['path']
    old = history.get(path)
    need(old is None or old['status'] == 'ACTIVE', 'ended directory reappeared')
    need(old is not None or len(history) < ENTRIES, 'directory history bound')
    if old is None:
        old = dict(path=path, st_dev=row['st_dev'], st_ino=row['st_ino'],
            lifetime_class='EPHEMERAL_TMP' if path.startswith('tmp/') else 'PERSISTENT',
            status='ACTIVE', first_observation=state.get('observation_id', 0),
            first_type='S_IFDIR', owner_uid=row['uid'], private_mode=row['mode'],
            first_phase=row.get('phase', 'UNKNOWN'),
            first_time_ns=row.get('observation_time_ns', 'UNKNOWN'))
        history[path] = old
    old['last_observation'] = state.get('observation_id', 0)
    old['last_metadata'] = dict(row)


def reconcile(state, rows):
    current = {row['path']: row for row in rows}
    need(len(current) == len(rows) <= ENTRIES, 'all-entry observation bound')
    state['observation']['current_entries'] = [
        dict(path=row['path'], type=row['type']) for row in rows]
    ended, surviving, persistent_missing = [], [], []
    for path, record in state['lifetimes'].items():
        row = current.get(path)
        if row is not None:
            state['diagnostic_candidate'] = row
            need(record['status'] == 'ACTIVE', 'ended directory reappeared')
            need(row['type'] == 'S_IFDIR', 'historical directory present wrong type')
            surviving.append(path)
        elif record['status'] == 'ACTIVE':
            if record['lifetime_class'] == 'EPHEMERAL_TMP':
                ended.append(path)
            else:
                persistent_missing.append(path)
    return ended, surviving, persistent_missing


def commit(state, work, ended):
    end_time = time.time_ns()
    work['observation'].update(status='COMPLETE', end_time_ns=end_time,
                               committed_ends=list(ended))
    for path in ended:
        work['lifetimes'][path].update(status='ENDED',
            end_observation=work['observation_id'],
            end_observed_phase=work['observation']['phase'],
            end_observed_time_ns=end_time,
            end_observation_begin_time_ns=work['observation']['begin_time_ns'],
            end_observation_group_active=work['observation']['group_active'],
            end_observation_status='COMPLETE')
    state.update(work)


def failed(state, work, error):
    work['observation'].update(status='ERROR', end_time_ns=time.time_ns(),
                               error=str(error), committed_ends=[])
    work['last_failed_observation'] = dict(work['observation'])
    for key, value in work.items():
        if key not in ('bindings', 'lifetimes'):
            state[key] = value
