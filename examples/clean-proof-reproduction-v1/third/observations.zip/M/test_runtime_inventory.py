"""Frozen synthetic IPC controls. No compiler, prover or old native executable."""
import ast
from datetime import timedelta
import builtins
import json
import os
from pathlib import Path
import socket
import stat
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import clean_helpers as h
import runtime_inventory as r
import clean_driver as driver
import clean_process as process

ROOT = h.DESIGN / 'ipc-tests-05'
ORACLE = h.load(h.DESIGN / 'oracle-v2.json')
BASE = h.load(h.DESIGN / 'literal-oracle.json')
RESULTS = []


def row(identity, phase='BUILD', stamp=10, uid=None, nlink=1):
    return dict(identity, phase=phase, observation_time_ns=stamp,
                uid=os.getuid() if uid is None else uid, nlink=nlink,
                mode=stat.S_IFSOCK | 0o600, bytes=0, blocks=0,
                ctime_ns=stamp, mtime_ns=stamp)


def named(label):
    return dict(path='tmp/' + label, st_dev=1, st_ino=int(label[3:]), type='S_IFSOCK')


def sample(state, identities, phase, active, stamp):
    state['current_count'] = 0
    for identity in identities:
        r.admit_ipc(state, row(identity, phase, stamp), active)


class Controls(unittest.TestCase):
    def test_frozen_state_sequences(self):
        for case in ORACLE['stateful_controls'][:2]:
            state = r.new_state()
            for step in case['steps']:
                identities = step.get('observed', [named(x) for x in
                                      step.get('observed_identity_labels', [])])
                expected = step['expected']
                if expected['status'].startswith('REFUSED'):
                    with self.assertRaisesRegex(ValueError, 'distinct IPC bound'):
                        sample(state, identities, step['phase'], step['group_active'], step['time'])
                    self.assertEqual(len(state['registry']), 16)
                    self.assertEqual(state['attempted_distinct_count'], 17)
                else:
                    sample(state, identities, step['phase'], step['group_active'], step['time'])
                    self.assertEqual(state['current_count'], expected['current_count'])
                    self.assertEqual(len(state['registry']), expected['distinct_count'])
                    for observed, want in zip(state['registry'].values(), expected.get('registry', [])):
                        for key, value in want.items():
                            self.assertEqual(observed[key], value)
            RESULTS.append(dict(id=case['id'], status='PASS'))

    def test_repeat_and_inode_reuse(self):
        identities = ORACLE['literal_identity_definitions']
        state = r.new_state()
        for stamp in range(16):
            sample(state, [identities['A']], 'BUILD', True, stamp)
        self.assertEqual(len(state['registry']), 1)
        sample(state, [identities['B']], 'PROOF', True, 20)
        self.assertEqual(len(state['registry']), 2)
        self.assertEqual(state['current_count'], 1)
        RESULTS.extend([dict(id='S03_REPEATED_IDENTITY_BOUNDED_REGISTRY', status='PASS'),
                        dict(id='S04_PATH_REUSED_WITH_NEW_INODE', status='PASS')])

    def test_base_literal_policy_cases(self):
        for case in BASE['cases']:
            state = r.new_state()
            count = case['distinct_seen'] - 1
            for number in range(min(count, 16)):
                identity = dict(path='tmp/old'+str(number), st_dev=1,
                                st_ino=1000+number, type='S_IFSOCK')
                sample(state, [identity], 'BUILD', True, number)
            state['current_count'] = case['simultaneous'] - 1
            entry = row(dict(path=case['path'], st_dev=1, st_ino=9999, type=case['type']),
                        'PROOF' if case['context']=='runtime-proof' else 'BUILD',
                        uid=os.getuid() if case['uid_matches'] else os.getuid()+1,
                        nlink=case['nlink'])
            active = case['context'] in ('runtime-build', 'runtime-proof')
            if case['expected'] == 'REFUSED':
                with self.assertRaises(ValueError):
                    r.admit_ipc(state, entry, active)
            else:
                r.admit_ipc(state, entry, active)
                self.assertEqual(state['current_count'], case['simultaneous'])
            RESULTS.append(dict(id=case['id'], status='PASS'))

    def test_private_directory_bindings(self):
        base = row(dict(path='tmp', st_dev=1, st_ino=1, type='S_IFDIR'))
        base['mode'] = stat.S_IFDIR | 0o700
        for change, reason in [({'uid':os.getuid()+1},'ownership'),
                               ({'mode':stat.S_IFDIR|0o722},'replaceable'),
                               ({'st_ino':2},'identity changed')]:
            state = r.new_state()
            r.bind_directory(state, base)
            with self.assertRaisesRegex(ValueError, reason):
                r.bind_directory(state, dict(base, **change))
        for case in ORACLE['all_other_special_class_controls']:
            with self.assertRaises(ValueError):
                r.admit_ipc(r.new_state(), row(dict(path='tmp/entry',st_dev=1,
                    st_ino=1,type=case['type'])), True)
        with self.assertRaisesRegex(ValueError,'nlink'):
            r.admit_ipc(r.new_state(),row(dict(path='tmp/entry',st_dev=1,
                st_ino=1,type='S_IFSOCK'),nlink=0),True)

    def test_frozen_root_control_matrix(self):
        for case in ORACLE['private_root_and_ancestor_controls']:
            identity = row(dict(path='tmp',st_dev=1,st_ino=1,type='S_IFDIR'))
            identity['mode']=stat.S_IFDIR|0o700
            state=r.new_state()
            r.bind_directory(state,identity)
            category=case['id'].split('_')[0]
            if category in ('R01','R02'):
                altered=dict(identity,uid=os.getuid()+1)
            elif category in ('R03','R04'):
                altered=dict(identity,mode=stat.S_IFDIR|0o722)
            elif category in ('R07','R08'):
                altered=dict(identity,st_ino=2)
            else:
                altered=None
            if altered is not None:
                with self.assertRaises(ValueError):r.bind_directory(state,altered)
            elif category in ('R05','R06','R09'):
                entry=row(dict(path='tmp',st_dev=1,st_ino=2,type='S_IFLNK'))
                with self.assertRaises(ValueError):r.admit_ipc(state,entry,True)
            else:
                entry=row(dict(path='tmp/entry',st_dev=1,st_ino=2,type='S_IFSOCK'),
                          nlink=0 if category=='R10' else 1,
                          uid=os.getuid()+1 if category=='R11' else os.getuid())
                with self.assertRaises(ValueError):r.admit_ipc(state,entry,True)
            RESULTS.append(dict(id=case['id'],status='PASS'))

    def test_real_fifo_socket_and_no_open(self):
        folder = ROOT / 'real-ipc'
        (folder / 'tmp/nested').mkdir(mode=0o700, parents=True)
        fifo = folder / 'tmp/pipe'
        os.mkfifo(fifo, 0o600)
        endpoint = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        endpoint.bind(str(folder / 'tmp/nested/socket'))
        state = r.new_state()
        try:
            with patch.object(builtins, 'open', side_effect=AssertionError('open called')), \
                 patch.object(os, 'open', side_effect=AssertionError('os.open called')):
                observed = r.runtime_inventory(folder,state,'PROOF',True)
            self.assertEqual(state['current_count'], 2)
            self.assertEqual(len(state['registry']), 2)
            self.assertGreater(observed['bytes'], 0)
            with self.assertRaises(ValueError):
                r.strict_readback(folder,state)
            self.assertIn(state['refusal']['type'], ['S_IFSOCK','S_IFIFO'])
            self.assertIn('partial_bytes', state['refusal'])
            self.assertIn('peak_bytes', state['refusal'])
        finally:
            endpoint.close()
            (folder / 'tmp/nested/socket').unlink()
            fifo.unlink()
        r.strict_readback(folder,state)
        RESULTS.append(dict(id='S05_FINAL_IPC_RESIDUE', status='PASS'))

    def test_symlink_replaceable_and_replaced_ancestor(self):
        folder = ROOT / 'ancestors'
        (folder / 'tmp/inner').mkdir(mode=0o700, parents=True)
        state = r.new_state()
        r.runtime_inventory(folder,state,'BUILD',True)
        (folder / 'tmp/inner').rmdir()
        (folder / 'tmp/inner').mkdir(mode=0o700)
        with self.assertRaisesRegex(ValueError, 'identity changed'):
            r.runtime_inventory(folder,state,'PROOF',True)
        self.assertEqual(state['refusal']['path'], 'tmp/inner')
        folder2 = ROOT / 'symlinks'
        folder2.mkdir(mode=0o700)
        (folder2 / 'tmp').symlink_to(folder / 'tmp')
        with self.assertRaises(ValueError):
            r.runtime_inventory(folder2,r.new_state(),'PROOF',True)
        self.assertEqual(r.kind(0), 'UNKNOWN')

    def test_partial_storage_and_diagnostic(self):
        folder = ROOT / 'partial'
        folder.mkdir(mode=0o700)
        (folder/'file').write_bytes(b'x')
        state = r.new_state()
        with self.assertRaisesRegex(ValueError,'storage bound'):
            r.runtime_inventory(folder,state,'PROOF',True,cap=1)
        self.assertGreater(state['refusal']['partial_bytes'],1)
        self.assertEqual(state['refusal']['path'],'.')
        self.assertEqual(state['refusal']['phase'],'PROOF')
        self.assertGreater(state['refusal']['observation_time_ns'],0)

    def test_stat_failure_records_actual_path(self):
        folder=ROOT/'stat-error';folder.mkdir(mode=0o700)
        state=r.new_state()
        with patch.object(Path,'lstat',side_effect=FileNotFoundError('fixed missing')):
            with self.assertRaises(OSError):r.runtime_inventory(folder,state,'PROOF',True)
        self.assertEqual(state['refusal']['path'],'.')
        self.assertEqual(state['refusal']['type'],'UNKNOWN')
        self.assertEqual(state['refusal']['st_ino'],'UNKNOWN')

    def test_calendar_ceiling_and_headroom(self):
        ceiling=driver.calendar_ceiling()
        driver.calendar_check(ceiling,ceiling.timestamp()-451)
        with self.assertRaisesRegex(ValueError,'headroom'):
            driver.calendar_check(ceiling,ceiling.timestamp()-450)
        with self.assertRaisesRegex(ValueError,'ceiling'):
            driver.calendar_check(ceiling+timedelta(seconds=1),ceiling.timestamp()-900)
        with self.assertRaises(ValueError):
            driver.calendar_check(ceiling.replace(tzinfo=None),ceiling.timestamp()-900)

    def test_real_owned_child_ipc_window(self):
        import time
        folder=ROOT/'child-ipc';(folder/'tmp').mkdir(mode=0o700,parents=True)
        body=('import socket,os,time;s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);'
              'p=os.environ["TMPDIR"]+"/child.sock";s.bind(p);print("ready",flush=True);'
              'time.sleep(.5);os.unlink(p);s.close()')
        state=r.new_state()
        result=process.run(['/usr/bin/python3','-I','-S','-B','-c',body],folder,folder,
            h.environment(folder),'proof',2,time.monotonic()+5,runtime_state=state)
        h.write(folder/'process.json',result)
        self.assertEqual(result['status'],'SUCCESS')
        self.assertTrue(result['terminal_group_absent'])
        self.assertEqual(len(state['registry']),1)
        self.assertEqual(result['runtime_inventory']['registry'][0]['path'],'tmp/child.sock')
        h.inventory(folder)

    def test_strict_source_functions_unchanged(self):
        old = (h.DESIGN/'baseline-v3/clean_helpers.py').read_bytes()
        current = (h.DESIGN/'clean_helpers.py').read_bytes()
        for name in ('inventory','source_check','summary'):
            values=[]
            for raw in (old,current):
                tree=ast.parse(raw)
                node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
                values.append(ast.get_source_segment(raw.decode(),node))
            self.assertEqual(values[0],values[1])

    def test_all_function_sizes(self):
        for path in h.DESIGN.glob('*.py'):
            raw=h.read(path);compile(raw,str(path),'exec',dont_inherit=True)
            for node in ast.walk(ast.parse(raw)):
                if isinstance(node,ast.FunctionDef):
                    self.assertLessEqual(node.end_lineno-node.lineno+1,60,
                                         path.name+':'+node.name)


def main():
    os.umask(0o077)
    ROOT.mkdir(mode=0o700,exist_ok=False)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
    with (ROOT/'unittest.stderr').open('x') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    h.write(ROOT/'report.json',dict(status='PASS' if result.wasSuccessful() else 'FAILED',
        tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        skipped=len(result.skipped),literal_results=RESULTS,actual_native_build_or_proof='NOT_RUN',
        source_files={p.name:h.pin(h.read(p)) for p in h.DESIGN.glob('*.py')}))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':
    raise SystemExit(main())
