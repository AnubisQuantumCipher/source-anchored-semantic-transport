from pathlib import Path
import importlib.util
import json
import sys

ROOT = Path(__file__).absolute().parent
REPO = Path('/home/sicarii/Work/semantic-transport-evidence-links-20261028')
sys.path.insert(0, str(REPO / 'install'))
from transport_install_support import canonical, confined, read_regular, require, sha, write_new


def main():
    spec = importlib.util.spec_from_file_location('local_exporter', ROOT / 'export_evidence.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for name in ('canonical', 'confined', 'read_regular', 'require', 'sha', 'write_new'):
        setattr(module, name, globals()[name])
    plan = json.loads(read_regular(ROOT / 'base-selection.json'))
    roots, checks = dict(repo=REPO, evidence=ROOT.parent), []
    for name in ('../x', '/x', 'x//y', 'x/', 'x\\y', '.'):
        refused(checks, 'unsafe-name:' + name, lambda name=name: module.safe_name(name))
    item = next(item for item in plan['entries'] if item['category'] == 'source_code')
    refused(checks, 'protected-data-redaction', lambda: module.frozen_read(roots[item['root']], item | dict(mode='mapped_metadata')))
    refused(checks, 'stale-selected-input', lambda: module.frozen_read(roots[item['root']], item | dict(sha256='0' * 64)))
    refused(checks, 'duplicate-export-name', lambda: module.collect(plan | dict(entries=plan['entries'] + [plan['entries'][0]]), roots))
    refused(checks, 'entry-byte-bound', lambda: module.archive_bytes({'x': b'x' * (module.MAX_ENTRY + 1)}))
    refused(checks, 'entry-count-bound', lambda: module.archive_bytes({str(i): b'' for i in range(module.MAX_ENTRIES + 1)}))
    refused(checks, 'unsupported-summary-source', lambda: module.receipt_summary(b'{}'))
    raw = b'/home/sicarii/synthetic-path'
    exact, exactmap = module.transform(raw, dict(mode='exact', root='evidence', source='synthetic', target='synthetic', category='source'))
    mapped, mapping = module.transform(raw, dict(mode='mapped_metadata', root='evidence', source='synthetic', target='synthetic', category='metadata'))
    require(exact == raw and exactmap['host_path_replacements'] == 0, 'protected byte preservation')
    require(mapped == b'[HOST]/synthetic-path' and mapping['original_sha256'] == sha(raw)
            and mapping['exported_sha256'] == sha(mapped), 'explicit mapping')
    checks.append(dict(check='protected-exact-and-explicit-metadata-map', status='PASS'))
    receipt = dict(schema='transport/exporter-preflight/1', script_sha256=sha(read_regular(ROOT / 'export_evidence.py')),
                   checks=checks, status='TESTED_SCOPED', final_export='NOT_PERFORMED', prior_failure='exporter-controls-01.failure.txt')
    write_new(ROOT / 'exporter-controls-02.json', canonical(receipt))
    print(canonical(dict(checks=len(checks), status='TESTED_SCOPED')).decode())


def refused(checks, label, callback):
    try:
        callback()
    except (ValueError, KeyError):
        checks.append(dict(check=label, status='REFUSED_AS_EXPECTED'))
        return
    raise ValueError('negative probe accepted: ' + label)


if __name__ == '__main__':
    main()
