#!/usr/bin/env python3
"""Explicit pinned, selected-evidence export. Imports no archive-supplied code.

Run --check-only before final export; final ZIP and receipt are create-only.
Metadata remapping never changes protected source/candidate/package/contract/code
entries. A mapped receipt still refers to original hashes unless stated otherwise.
"""
import argparse
import io
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

MAX_ENTRIES, MAX_ENTRY, MAX_EXPANDED, MAX_ARCHIVE = 256, 131072, 4194304, 1048576
MAX_INPUT = 4194304
PROTECTED = {'source', 'candidate', 'package', 'contract', 'source_code'}
MODES = {'exact', 'mapped_metadata', 'integration_receipt_summary'}
HOST_PREFIX, REPLACEMENT = b'/home/sicarii/', b'[HOST]/'


def safe_name(name):
    require(type(name) is str and 0 < len(name) <= 512 and '\\' not in name and '\0' not in name,
            'invalid archive-relative name')
    path = PurePosixPath(name)
    require(bool(path.parts) and not path.is_absolute() and str(path) == name and all(part not in ('', '.', '..') for part in path.parts),
            'unsafe or noncanonical relative name')
    return name


def frozen_read(root, item):
    require(set(item) == {'root', 'source', 'target', 'mode', 'category', 'bytes', 'sha256'}, 'selection fields')
    require(item['root'] in ('repo', 'evidence'), 'selection root')
    require(item['mode'] in MODES, 'selection mode')
    require(item['category'] in PROTECTED | {'metadata', 'capture', 'documentation'}, 'selection category')
    require(item['mode'] == 'exact' or item['category'] in ('metadata', 'capture'), 'protected bytes cannot be mapped')
    safe_name(item['source'])
    safe_name(item['target'])
    require(type(item['bytes']) is int and 0 <= item['bytes'] <= MAX_INPUT, 'input size declaration')
    require(type(item['sha256']) is str and len(item['sha256']) == 64, 'input digest declaration')
    path = confined(root, item['source'])
    raw = read_regular(path, MAX_INPUT)
    require(len(raw) == item['bytes'] and sha(raw) == item['sha256'], 'selected input changed: ' + item['source'])
    return raw


def receipt_summary(raw):
    value = json.loads(raw)
    required = {'schema', 'status', 'arms', 'tests_run', 'processes', 'input_freeze_sha256', 'outputs',
                'errors', 'failures', 'scope', 'semantics', 'formal_proof', 'models', 'transport_decoder'}
    require(type(value) is dict and set(value) == required, 'unsupported integration receipt summary source')
    outputs = value['outputs']
    require(type(outputs) is dict and set(outputs) == {'bytes', 'files'} and type(outputs['files']) is list,
            'integration output inventory shape')
    require(len(outputs['files']) <= 2048, 'integration output inventory bound')
    summary = {key: value[key] for key in required if key != 'outputs'}
    summary['original_output_inventory'] = dict(bytes=outputs['bytes'], files=len(outputs['files']),
                                               sha256=sha(canonical(dict(files=outputs['files']))))
    return canonical(dict(schema='transport/derived-integration-receipt-summary/1',
        representation='DERIVED_SELECTED_FIELDS_NOT_ORIGINAL_RECEIPT', original_bytes=len(raw),
        original_sha256=sha(raw), omitted_fields=['outputs.files'], summary=summary))


def transform(raw, item):
    mode = item['mode']
    result = receipt_summary(raw) if mode == 'integration_receipt_summary' else raw
    replaced = 0
    if mode != 'exact':
        result.decode('utf-8', errors='strict')
        replaced = result.count(HOST_PREFIX)
        result = result.replace(HOST_PREFIX, REPLACEMENT)
    require(len(result) <= MAX_ENTRY, 'exported entry size bound: ' + item['target'])
    return result, dict(source_root=item['root'], source=item['source'], original_bytes=len(raw),
        original_sha256=sha(raw), exported_bytes=len(result), exported_sha256=sha(result),
        category=item['category'], transformation=mode, host_path_replacements=replaced)


def inventory(repo, declarations):
    require(type(declarations) is list and 1 <= len(declarations) <= 64, 'source inventory count bound')
    records, seen = [], set()
    for item in declarations:
        require(type(item) is dict and set(item) == {'path', 'bytes', 'sha256', 'role'}, 'source inventory fields')
        name = safe_name(item['path'])
        require(name not in seen and item['role'] in ('product', 'test', 'build', 'dependency'), 'inventory duplicate/role')
        raw = read_regular(confined(repo, name), MAX_ENTRY)
        require(len(raw) == item['bytes'] and sha(raw) == item['sha256'], 'source inventory changed: ' + name)
        records.append(item)
        seen.add(name)
    return dict(schema='transport/public-source-inventory/1', files=records,
        scope='EXACT_NAMED_PRODUCT_TEST_AND_HELPER_FILES; not whole-repository or formal proof',
        external_dependencies=['Python and host runtime', 'Native decoder bundle only for transport-arm reproduction'],
        decoder_dependency_status='NOT_INCLUDED; exact installed identity recorded in retained input freezes')


def collect(plan, roots):
    require(type(plan) is dict and set(plan) == {'schema', 'entries', 'source_inventory', 'gate_sources'}, 'selection plan fields')
    require(plan['schema'] == 'transport/public-evidence-selection/1', 'selection schema')
    entries = plan['entries']
    require(type(entries) is list and 1 <= len(entries) <= MAX_ENTRIES - 2, 'selected entry count bound')
    files, provenance, original = {}, {}, {}
    for item in entries:
        require(type(item) is dict, 'selection entry object')
        raw = frozen_read(roots[item['root']], item)
        name = item['target']
        require(name not in files and name not in ('MANIFEST.json', 'SOURCE-INVENTORY.json'), 'duplicate or reserved export name')
        files[name], provenance[name] = transform(raw, item)
        original[name] = raw
    source_inventory = inventory(roots['repo'], plan['source_inventory'])
    files['SOURCE-INVENTORY.json'] = canonical(source_inventory)
    require(len(files['SOURCE-INVENTORY.json']) <= MAX_ENTRY, 'inventory entry byte bound')
    return files, provenance, original, source_inventory


def gate_observations(plan, files):
    declarations = plan['gate_sources']
    require(type(declarations) is list and 1 <= len(declarations) <= 16, 'gate sources count bound')
    result = []
    for item in declarations:
        require(type(item) is dict and set(item) == {'entry', 'fields'}, 'gate source fields')
        name = safe_name(item['entry'])
        require(name in files and type(item['fields']) is list and 1 <= len(item['fields']) <= 16, 'gate source missing/bound')
        value = json.loads(files[name])
        observed = {}
        for field in item['fields']:
            require(type(field) is str and field in value and field not in observed, 'gate field missing/duplicate')
            observed[field] = value[field]
        result.append(dict(entry=name, sha256=sha(files[name]), observed_fields=observed))
    require(len(canonical(dict(gates=result))) <= 65536, 'gate summary bound')
    return result


def archive_bytes(files):
    require(1 <= len(files) <= MAX_ENTRIES and sum(len(raw) for raw in files.values()) <= MAX_EXPANDED, 'archive count/expansion bound')
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(files):
            safe_name(name)
            require(len(files[name]) <= MAX_ENTRY, 'archive member byte bound')
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.create_system, entry.external_attr = 3, (stat.S_IFREG | 0o644) << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, files[name], compresslevel=9)
    raw = buffer.getvalue()
    require(len(raw) <= MAX_ARCHIVE, 'compressed archive bound')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        require(archive.namelist() == sorted(files), 'archive readback entry order differs')
        for item in archive.infolist():
            require(stat.S_ISREG(item.external_attr >> 16) and item.file_size == len(files[item.filename]), 'unsafe archive member')
            require(archive.read(item) == files[item.filename], 'archive member readback mismatch')
    return raw


def build(plan, roots, plan_raw):
    files, provenance, originals, source_inventory = collect(plan, roots)
    gates = gate_observations(plan, files)
    manifest = dict(schema='transport/selected-public-evidence-manifest/1', selection_plan_sha256=sha(plan_raw),
        entries={name: dict(bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(files.items())},
        provenance=provenance, excluded=['MANIFEST.json'],
        scope='SELECTED_EVIDENCE_NOT_COMPLETE_PRIVATE_CORPUS', decoder_bundle_included=False,
        redaction='Only explicitly marked metadata/captures; source/candidate/package/contract/code bytes unchanged')
    files['MANIFEST.json'] = canonical(manifest)
    raw = archive_bytes(files)
    require(archive_bytes(files) == raw, 'deterministic ZIP construction differs')
    for item in plan['entries']:
        require(frozen_read(roots[item['root']], item) == originals[item['target']], 'input changed during construction')
    require(inventory(roots['repo'], plan['source_inventory']) == source_inventory, 'source inventory changed during construction')
    receipt = dict(schema='transport/checked-evidence-public-receipt/1', status='LOCAL_SELECTED_EXPORT_VERIFIED',
        archive_bytes=len(raw), archive_sha256=sha(raw), manifest_sha256=sha(files['MANIFEST.json']),
        entry_count=len(files), expanded_bytes=sum(len(data) for data in files.values()),
        largest_entry_bytes=max(len(data) for data in files.values()),
        bounds=dict(entries=MAX_ENTRIES, entry_bytes=MAX_ENTRY, expanded_bytes=MAX_EXPANDED, archive_bytes=MAX_ARCHIVE),
        selection_plan_sha256=sha(plan_raw), gate_observations=gates,
        source_inventory_sha256=sha(files['SOURCE-INVENTORY.json']), source_candidate_package_bytes_changed=False,
        all_entry_readbacks_equal=True, deterministic_construction_checked=True,
        semantic_completeness='UNPROVEN', entailment='NOT_ASSESSED', execution_authority='NONE', formal_proof='NOT_CLAIMED',
        scope='Selected test/review/recipient records; not the complete private corpus or proof of comparative superiority',
        redaction=dict(source=HOST_PREFIX.decode(), replacement=REPLACEMENT.decode(), mapping='MANIFEST.json provenance'),
        decoder_bundle_included=False)
    return raw, canonical(receipt)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--selection', type=Path, required=True)
    parser.add_argument('--zip', type=Path)
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo / 'install'))
    global canonical, confined, read_regular, require, sha, write_new
    from transport_install_support import canonical, confined, read_regular, require, sha, write_new
    require(args.repo.is_absolute() and args.evidence.is_absolute(), 'absolute source roots required')
    plan_raw = read_regular(args.selection, MAX_ENTRY)
    plan = json.loads(plan_raw)
    raw, receipt = build(plan, dict(repo=args.repo, evidence=args.evidence), plan_raw)
    if not args.check_only:
        require(args.zip is not None and args.receipt is not None, 'output ZIP and receipt required')
        require(args.zip != args.receipt and not args.zip.exists() and not args.receipt.exists(), 'create-only output targets')
        write_new(args.zip, raw, MAX_ARCHIVE)
        write_new(args.receipt, receipt, MAX_ENTRY)
        require(read_regular(args.zip, MAX_ARCHIVE) == raw and read_regular(args.receipt, MAX_ENTRY) == receipt, 'published output readback')
    print(receipt.decode())
    return 0


if __name__ == '__main__':
    sys.exit(main())
