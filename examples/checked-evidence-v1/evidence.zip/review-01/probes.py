"""Independent bounded probes; read-only source, create-only local evidence."""
import base64
import copy
import json
from pathlib import Path
import resource
import sys
from types import SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path('/home/sicarii/Work/semantic-transport-evidence-links-20261028')
OUT = Path(__file__).absolute().parent
sys.path.insert(0, str(ROOT / 'install'))
import transport_response_evidence as evidence
import transport_handoff_reader as reader
import transport_checked_finish as checked
from transport_install_support import canonical, sha

NAMES = ('transport_response_evidence.py', 'test_response_evidence.py',
         'transport_handoff_inputs.py', 'transport_handoff_reader.py',
         'transport_handoff_session.py', 'transport_handoff_client.py',
         'transport_checked_finish.py', 'transport_response_contract.py',
         'transport_response_contract_model.py', 'transport_install_support.py',
         'transport_install_layout.py', 'transport_handoff_prepare.py',
         'transport_handoff_prepare_inputs.py', 'freeze_response_contract_tests.py')
RAW = 'Approval revoked. λ café e\u0301\r\n'.encode('utf-8')
SOURCES = {'RULE': RAW}
HELD = {'RULE': sha(RAW)}
CONTRACT = dict(schema=evidence.SCHEMA, description='Review exact citations only',
                response_contract_sha256='1' * 64, selectors=[['citations', '*']])
ANCHOR = dict(source_id='RULE', source_sha256=HELD['RULE'], start=0,
              end=len(RAW), quote=RAW.decode('utf-8'))
VALUE = dict(citations=[ANCHOR], claim='Publication is approved now.')
RESULTS = []


def save(name, value):
    with (OUT / name).open('xb') as stream:
        stream.write(canonical(value) + b'\n')


def snapshot():
    paths = [ROOT / 'install' / name for name in NAMES] + [Path(sys.executable).resolve()]
    return [dict(path=str(path), bytes=len(path.read_bytes()), sha256=sha(path.read_bytes())) for path in paths]


def check(name, operation, refused=False):
    try:
        observed = operation()
    except (ValueError, UnicodeError, KeyError, TypeError) as error:
        RESULTS.append(dict(case=name, passed=refused, outcome='REFUSED', reason=str(error)))
    else:
        RESULTS.append(dict(case=name, passed=not refused, outcome='RETURNED', result=observed))


def assess(value=None, contract=None, sources=None, held=None):
    return evidence.validate(canonical(VALUE if value is None else value),
        canonical(CONTRACT if contract is None else contract), SOURCES if sources is None else sources,
        HELD if held is None else held)


def changed_anchor(**changes):
    return dict(citations=[dict(ANCHOR, **changes)])


def boundary_probes():
    for name, change in (('unknown_source', dict(source_id='OTHER')),
        ('wrong_revision', dict(source_sha256='0' * 64)), ('boolean_offset', dict(start=False)),
        ('negative_offset', dict(start=-1)), ('end_past_source', dict(end=len(RAW) + 1)),
        ('empty_span', dict(end=0)), ('fabricated_quote', dict(quote='Approval granted.')),
        ('normalized_quote', dict(quote=RAW.decode().replace('e\u0301', 'é'))),
        ('newline_normalized', dict(quote=RAW.decode().replace('\r\n', '\n')))):
        check(name, lambda change=change: assess(changed_anchor(**change)), True)
    for name, value, contract in (
        ('missing_selected_field', {}, CONTRACT), ('empty_selected_list', dict(citations=[]), CONTRACT),
        ('unselected_good_array_cannot_replace_missing_selection', dict(other=[ANCHOR]), CONTRACT),
        ('unmatched_second_selector', VALUE, dict(CONTRACT, selectors=[['citations', '*'], ['missing']])),
        ('duplicate_selector', VALUE, dict(CONTRACT, selectors=[['citations', '*'], ['citations', '*']]))):
        check(name, lambda value=value, contract=contract: assess(value, contract), True)
    for size, refused in ((32768, False), (32769, True)):
        raw = canonical(VALUE)
        padded = raw + b' ' * (size - len(raw))
        check('candidate_bytes_' + str(size), lambda padded=padded: evidence.validate(
            padded, canonical(CONTRACT), SOURCES, HELD), refused)
    check('source_changed_while_pin_held', lambda: assess(sources={'RULE': RAW + b'!'}), True)
    check('same_id_new_pin_old_candidate', lambda: assess(sources={'RULE': RAW + b'!'},
          held={'RULE': sha(RAW + b'!')}), True)


def record_false_claim_limit():
    result = assess()
    assert result['status'] == 'SOURCE_SPANS_MATCH'
    assert result['semantics'] == 'NOT_ASSESSED' and result['execution_authority'] == 'NONE'
    assert result['context_adequacy'] == 'UNPROVEN'
    return result


def session_case(label, mocked=None):
    location = OUT / label
    args = SimpleNamespace(manifest=OUT / 'nominal-manifest.json', expect_manifest_sha256='2' * 64,
                           session=location, request_error='')
    manifest = dict(arm='original', held_source_sha256=HELD)
    raw = canonical(dict(action='describe'))
    reader.logged_call(args, manifest, None, SOURCES, raw, len(raw))
    request = dict(action='finish_evidence', candidate_base64=base64.b64encode(canonical(VALUE)).decode(),
        evidence_contract_base64=base64.b64encode(canonical(CONTRACT)).decode(),
        expect_evidence_contract_sha256=sha(canonical(CONTRACT)))
    raw = canonical(request)
    if mocked is None:
        answer = reader.logged_call(args, manifest, None, SOURCES, raw, len(raw))
    else:
        with patch.object(reader.evidence, 'validate', return_value=mocked):
            answer = reader.logged_call(args, manifest, None, SOURCES, raw, len(raw))
    result = json.loads(answer)
    if mocked is not None:
        assert result['status'] == 'REFUSED' and not (location / 'candidate.json').exists()
    else:
        assert result['status'] == 'OK'
        assert result['result']['manifest_sha256'] == args.expect_manifest_sha256
        assert (location / 'candidate.json').read_bytes() == canonical(VALUE)
        try:
            reader.logged_call(args, manifest, None, SOURCES, raw, len(raw))
        except ValueError as error:
            assert 'already finished' in str(error)
        else:
            raise AssertionError('second finish was not refused')
    return dict(response=result, candidate_exists=(location / 'candidate.json').exists())


def receipt_probe(field):
    candidate = canonical(VALUE)
    verdict = assess()
    response = dict(result=dict(status='DRAFT_SAVED_SOURCE_LINKED', candidate=checked.inputs.record(candidate),
        manifest_sha256='2' * 64, source_evidence=verdict))
    if field == 'manifest':
        response['result']['manifest_sha256'] = '3' * 64
    elif field is not None:
        response['result']['source_evidence'][field] = '3' * 64
    state = dict(evidence_contract_sha256=sha(canonical(CONTRACT)))
    return checked.saved_result(state, response, dict(action='finish_evidence'), candidate, '1' * 64, '2' * 64)


def conditional_probes():
    base = dict(contract=OUT / 'structure.json', candidate=OUT / 'candidate-input.json', binding=OUT / 'binding.json')
    check('both_optional_flags_absent_is_explicit_legacy', lambda: checked.finish_request({},
        SimpleNamespace(**base), canonical(VALUE), '1' * 64))
    for label, changes in (('evidence_path_without_pin', dict(evidence_contract=OUT / 'not-opened.json')),
        ('evidence_pin_without_path', dict(expect_evidence_contract_sha256='1' * 64))):
        check(label, lambda changes=changes: checked.finish_request({}, SimpleNamespace(**base, **changes),
              canonical(VALUE), '1' * 64), True)


def main():
    resource.setrlimit(resource.RLIMIT_AS, (268435456, 1073741824))
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    before = snapshot()
    save('source-before.json', dict(files=before))
    assert before[0]['sha256'] == '6450ba7904aa8c6d80b3dc52b4de789c342bfd25c8f256cac4229145ba8788ad'
    assert before[1]['sha256'] == 'ef6ee7748118f6f54262f658a8f848671a88fae678bf549253ff2cccf716fc30'
    check('valid_quote_false_surrounding_claim_stays_unassessed', record_false_claim_limit)
    boundary_probes()
    check('real_logged_session_exact_save_and_terminal', lambda: session_case('successful-session'))
    check('nonthrowing_failure_verdict_no_candidate', lambda: session_case('mock-failure-session',
        dict(status='SOURCE_SPANS_MISMATCH')))
    check('wrong_candidate_success_verdict_no_candidate', lambda: session_case('mock-wrong-hash-session',
        dict(assess(), candidate_sha256='0' * 64)))
    for field in (None, 'manifest', 'candidate_sha256', 'evidence_contract_sha256', 'response_contract_sha256'):
        check('receipt_binding_' + str(field), lambda field=field: receipt_probe(field), field is not None)
    conditional_probes()
    after = snapshot()
    save('source-after.json', dict(files=after))
    assert before == after, 'reviewed source changed during probes'
    save('results.json', dict(schema='transport/independent-evidence-probes/1', results=RESULTS,
        source_unchanged=True, semantics='NOT_ASSESSED', execution_authority='NONE'))
    assert all(item['passed'] for item in RESULTS), 'one or more probes failed'
    print(json.dumps(dict(status='TESTED_SCOPED', cases=len(RESULTS), source_unchanged=True)))


if __name__ == '__main__':
    main()
