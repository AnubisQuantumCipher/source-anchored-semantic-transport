"""Read-only receipt/source verification; append-only resolution evidence."""
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/sicarii/Work/semantic-transport-evidence-links-20261028')
BASE = Path('/home/sicarii/Projects/source-anchored-semantic-transport/evidence/checked-evidence-v1')
OUT = BASE / 'review-01'
sys.path.insert(0, str(ROOT / 'install'))
from transport_install_support import canonical, sha

EXPECTED = {'integration-04': 'd39e4aa4034aa55aaf714d62da0f197e31d798d4ad25a558855b15e2f24a466a',
            'integration-original-03': '27690473c042615b9f6a027e26a24f9407e9e9ce1931e4b187dcd27813c6cb81'}
OLD_RECEIPT_SHA = '35439593c22c27f78f4943622225e8a6aef85e48c9665d922536722c25f51b6c'
TEST_SHA = '3f0e6b5228a2960c82c78c4a63c42be722bcdcee49c549d90ea750b98035cfe8'


def verify_file(path, record):
    assert path.is_file() and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    assert len(raw) == record['bytes'] and sha(raw) == record['sha256'], str(path)
    return raw


def verify_sources(files):
    assert len(files) == 15
    names = {Path(item['path']).name for item in files}
    assert 'transport_handoff_prepare_inputs.py' in names
    assert str(Path(sys.executable).resolve()) in {item['path'] for item in files}
    for item in files:
        verify_file(Path(item['path']), item)
    tests = [item for item in files if Path(item['path']).name == 'test_evidence_finish.py']
    assert len(tests) == 1 and tests[0]['sha256'] == TEST_SHA


def verify_outputs(root, inventory):
    entries = inventory['files']
    assert len(entries) <= 2048
    total, names = 0, set()
    for item in entries:
        name = Path(item['path'])
        assert not name.is_absolute() and '..' not in name.parts and name.as_posix() not in names
        path = root / name
        assert path.resolve().is_relative_to(root.resolve())
        verify_file(path, item)
        names.add(name.as_posix())
        total += item['bytes']
        assert total <= 20971520
    assert total == inventory['bytes']
    return dict(files_checked=len(entries), bytes_checked=total)


def verify_trial(name, expected):
    root = BASE / name
    raw = (root / 'receipt.json').read_bytes()
    assert sha(raw) == expected
    receipt = json.loads(raw)
    frozen_raw = (root / 'input-freeze.json').read_bytes()
    assert sha(frozen_raw) == receipt['input_freeze_sha256']
    frozen = json.loads(frozen_raw)
    verify_sources(frozen['files'])
    assert receipt['status'] == 'TESTED_SCOPED' and not receipt['errors'] and not receipt['failures']
    assert receipt['semantics'] == 'NOT_ASSESSED' and receipt['formal_proof'] == 'UNPERFORMED'
    assert receipt['models'] == 'UNRUN'
    outputs = verify_outputs(root, receipt['outputs'])
    bundle = frozen['bundle']
    if bundle is not None:
        from test_portable_handoff import bundle_snapshot
        assert bundle_snapshot(Path(bundle['path'])) == bundle
    verify_sources(frozen['files'])
    return dict(name=name, receipt_sha256=expected, freeze_sha256=sha(frozen_raw),
        status=receipt['status'], tests_run=receipt['tests_run'], processes=receipt['processes'],
        arms=receipt['arms'], source_files=frozen['files'], outputs=outputs,
        bundle_identity_checked=bundle is not None)


def main():
    assert sha((OUT / 'receipt.json').read_bytes()) == OLD_RECEIPT_SHA
    records = [verify_trial(name, expected) for name, expected in EXPECTED.items()]
    assert records[0]['source_files'] == records[1]['source_files']
    assert sha((OUT / 'receipt.json').read_bytes()) == OLD_RECEIPT_SHA
    result = dict(schema='transport/review-closure-resolution/1', status='CLOSURE_FINDING_RESOLVED',
        prior_receipt_sha256=OLD_RECEIPT_SHA, previous_evidence_unchanged=True,
        trials=records, source_unchanged_during_verification=True,
        scope='RETAINED_RECEIPT_AND_ARTIFACT_IDENTITY_VERIFICATION_NO_TEST_RERUN',
        semantics='NOT_ASSESSED', formal_proof='UNPERFORMED', execution_authority='NONE')
    with (OUT / 'resolution-verification.json').open('xb') as stream:
        stream.write(canonical(result) + b'\n')
    print(json.dumps(dict(status=result['status'], prior_receipt_unchanged=True)))


if __name__ == '__main__':
    main()
