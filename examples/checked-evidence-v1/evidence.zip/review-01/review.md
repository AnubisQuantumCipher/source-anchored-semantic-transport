# Independent same-family engineering review

Scope: source-byte citation contract, reader action, checked submission wrapper,
session finality, fixed helper closure, and deterministic controls in
`[HOST]/Work/semantic-transport-evidence-links-20261028` based on
`360c3c450483d21bb6bc94fcc68a73eeeb18a7c8`. Configured reviewer model:
`gpt-6.1-sol`; backend identity is not independently attested. This review is
separate from the implementers, within the same model family. It is not external
validation, formal proof, whole-product acceptance, or a new model trial.

No product blocking defect was found in the reviewed final source snapshot.
`refreeze-02/source-before.json` and `source-after.json` bind the exact reviewed
files and Python executable. Both deterministic probe scripts verify their
source identities before and after execution. The core module was
`6450ba7904aa8c6d80b3dc52b4de789c342bfd25c8f256cac4229145ba8788ad`;
the final wrapper was
`cfaadbab9798dd42fe4ea87973a908b7e3f5631a862f8564c6851834897a29a0`.

The selected citation records are embedded in candidate bytes; exact field and
wildcard selectors must all resolve and cannot match an empty list. Each selected
object has a closed shape and must name a held source revision and a nonempty
half-open byte span whose exact UTF-8 encoding equals the supplied quotation.
The validator checks all source hashes, including unreferenced sources. Counts,
JSON size/depth/value counts, selector work, source bytes and quotation size are
explicitly bounded. The source collection already recovered by the existing
reader is reused; no new decoder or source-file authority is introduced.

The wrapper structurally validates the exact candidate and binds the evidence
contract to that structural-contract digest before dispatch. Its final receipt
also checks the reader manifest identity and exact candidate/evidence-contract
identities. The reader explicitly checks the validator success postcondition
before returning saveable candidate bytes. A raised or nonthrowing failure cannot
reach candidate save. Successful `finish_evidence` terminates the session just as
legacy `finish` does. Partial writes and post-save integrity failures retain the
existing custody uncertainty instead of claiming rollback. Direct reader use
states that structural validation is not assessed by the reader; combined claims
require the pinned wrapper. The opt-in profile cannot silently select legacy
behavior when just one evidence option is present. Omitting both options remains
the explicit legacy workflow, with unchanged structure-only output fields.

Executed evidence: `refreeze-02/results.json` records the independent targeted
probes; `refreeze-02/supplemental-results.json` records additional capture-extent,
whole-digest and selected-count controls. They cover fabricated quotes, unknown
sources, wrong revisions and held hashes, byte-offset/type errors, UTF-8 and line
ending normalization, missing or unused selectors, adjacent candidate and
selected-count limits, receipt identity substitutions, incomplete opt-in flags,
successful exact-byte custody, session finality, and mocked validator failures
that return without raising. Both mocked failure sessions refused with no saved
candidate. Captured prefixes remain explicitly incomplete and are not promoted
to complete reader receipts. All recorded assertions passed.

A valid revocation quotation paired with an `APPROVED` surrounding claim passes
source linkage while retaining `semantics: NOT_ASSESSED`,
`context_adequacy: UNPROVEN`, and `execution_authority: NONE`. This is the intended
consequence ceiling. Selectors do not prove that all possible claims are cited,
that a claim follows from its quote, that the source is true/authenticated, or
that context is adequate. There is no inference of approval, execution authority,
completeness or natural-language entailment.

An earlier probe snapshot passed its own exact source checks. A supplemental
attempt then correctly refused before dispatch after the wrapper changed to
preserve the legacy verdict shape. `supplemental-refusal.json` retains that drift
and the earlier evidence is not relabeled as final-source evidence. The final
refreeze probes were rerun against the new wrapper.

One test-provenance finding was reported: the integration test's `closure()` at
the inspected test revision omitted imported owned module
`transport_handoff_prepare_inputs.py`. It should be included before final
integration receipts are treated as an unchanged imported-code closure. A prior
message inaccurately attributed a direct `binding_value` call to that dependency;
that explanation was corrected. The module is imported by the preparation module;
the tested `binding_value` path itself does not call its functions. This is a test
closure issue, not a demonstrated product bypass. Final integration reruns and
documentation/CI review remain the root owner's separate acceptance work.

Original repeated-handoff failures, initial checked-continuation submission
failures and their fixture-specific acceptance criteria remain unchanged. No
repository files were edited by this reviewer. No native rebuild, heavy native
tests, model trials or publication were performed by this review. The smallest
remaining sound step is to close the imported test-dependency roster and retain
the final integration receipts against the exact shipped source; semantic
acceptance still requires a separate source-grounded assessment.
