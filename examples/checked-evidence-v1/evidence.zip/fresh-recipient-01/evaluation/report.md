# First fresh-recipient trial: frozen granularity failure retained

The first submitted candidate FAILED the complete frozen trial because C3
required distinct correct source spans for the repeated passages. The candidate
has one citation covering the entire source, `[0,224)`. Its explanation labels
the two occurrences separately, but it provides no separate locations for them.
The exact `Same quotation.` occurrences occupy `[138,153)` and `[154,169)`;
those are example precise occurrence spans, not a newly imposed output format.
No candidate, criterion or submission was repaired or retried.

| Frozen criterion | Result | Source comparison |
| --- | --- | --- |
| C1 | PASS | Mira, the obligation, every sample, 100 ms and the maintenance exception remain together. |
| C2 | PASS | Noah, recording obligation, 225Q events and base 87T remain; Q/T are not defined. |
| C3 | **FAIL** | Narrative distinguishes both repeats, but the sole citation is the whole source; distinct occurrence locations are absent. |
| C4 | PASS | λ😀 and approved-yesterday/revoked-today sequence remain without invented subject or calendar dates. |
| C5 | PASS | Approval is REVOKED, decoder authority NONE, and documentary history grants no live permission. |
| C6 | PASS | Unknown Q/T meanings, approval subject and relative-date calendar anchors remain explicit. |
| C7 | PASS | The selected whole-source quotation, digest and location exactly match original bytes. |
| C8 | PASS | No additional source-content omission, contradiction, unsupported expansion, causal invention or semantic-proof claim was found. This does not waive the separate C3 location failure. |

The mechanical status `DRAFT_SAVED_SOURCE_LINKED` is correct for its declared
scope: the response shape matched, the selected source span matched, and the
exact candidate was saved. Those checks do not enforce the separately frozen
occurrence-granularity criterion. This trial demonstrates that distinction;
it is not complete behavioral acceptance.

The saved candidate SHA-256 is
`178469792360f8262dd9bd2a25d263c43cc22747ee962a0aa09e6d64869e678b`.
Its exact bytes match the single observed candidate-creation patch, the receiver
provided candidate and the saved session candidate. All frozen preparation,
helper, contract and package file pins still match. The original source digest,
complete returned page, source citation, session hash chain and captured finish
response were independently checked. `evidence-check.json` records these
mechanical checks; it does not replace the eight-criterion source assessment.

The observed protocol is consistent with the live task: one read of the
designated interface/contracts/submission files, fixed describe/catalog/page
calls, one candidate write and one exact checked submission. The process returned
exit 0; stdout and empty stderr were retained. The final chat contains only
output paths and status. No outside-directory source access, network action,
delegation, candidate revision, retry or alternative submission appears in the
sanitized tool inventory. Preparation's validation session predates receiving
and is not a second receiving candidate or submission.

Initial prompt plaintext equality is UNKNOWN: the sanitized capture lacks an
observable initial user plaintext record suitable for comparison. The held
launch declaration is not substituted for that missing observation. The
receiver's observed model metadata reports `gpt-6.1-sol`, high reasoning, and the
captured lineage matches the designated child. Backend identity, hidden-access
exclusion and operating-system isolation are not independently established.

This is one small synthetic usability and faithfulness trial, independently
assessed within the same model family. There is no matched baseline, broader
superiority claim, external validation or formal semantic proof. Source linkage
is necessary but insufficient for the full task. The smallest sound next step
is to preserve this failed first result and require explicit distinct-occurrence
evidence in any separately frozen future trial; this result must not be repaired
into a pass.
