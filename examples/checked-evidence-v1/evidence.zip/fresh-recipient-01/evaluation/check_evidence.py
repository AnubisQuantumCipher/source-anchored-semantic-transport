"""Verify immutable trial evidence without executing recipient/source programs."""
import base64
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/sicarii/Projects/source-anchored-semantic-transport/evidence/checked-evidence-v1/fresh-recipient-01')
OUT = ROOT / 'evaluation'
sys.path.insert(0, '/home/sicarii/Work/semantic-transport-evidence-links-20261028/install')
from transport_install_support import canonical, sha


def record(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def pinned(path, pin):
    assert path.is_file() and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    assert record(raw) == {key: pin[key] for key in ('bytes', 'sha256')}, str(path)
    return raw


def closure():
    launch = json.loads((ROOT / 'launch.json').read_bytes())
    frozen_raw = pinned(ROOT / 'freeze.json', launch['freeze'])
    frozen = json.loads(frozen_raw)
    assert len(frozen['files']) <= 128
    total = 0
    for item in frozen['files']:
        name = Path(item['path'])
        assert not name.is_absolute() and '..' not in name.parts
        total += len(pinned(ROOT / name, item))
    assert total == frozen['bytes']
    sources = json.loads((ROOT / 'source-freeze.json').read_bytes())
    assert len(sources['files']) <= 32
    for item in sources['files']:
        pinned(Path(item['path']), item)
    from test_portable_handoff import bundle_snapshot
    assert bundle_snapshot(Path(sources['native']['path'])) == sources['native']
    return dict(launch_sha256=sha((ROOT / 'launch.json').read_bytes()),
        freeze_sha256=sha(frozen_raw), frozen_files=len(frozen['files']),
        source_files=len(sources['files']), frozen_bytes=total, native_bundle_unchanged=True)


def retained_trace():
    trace = ROOT / 'trace'
    report = json.loads((trace / 'report.json').read_bytes())
    assert report['source']['thread_id'] == '01a184f6-402f-7a62-baee-7c64d2f9b353'
    assert report['source']['agent_path'] == '/root/linked_source_receiver'
    assert report['source']['file_before'] == report['source']['file_after']
    assert len(report['events']) <= 32
    for event in report['events']:
        pinned(trace / event['path'], event)
        if 'source' in event:
            pinned(trace / event['source']['path'], event['source'])
    assert report['final_capture_state'] == 'SINGLE_COMPLETE_PLAINTEXT_FINAL'
    assert len(report['final_responses']) == 1
    pinned(trace / report['final_responses'][0]['text_file']['path'], report['final_responses'][0]['text_file'])
    assert report['inputs']['launch'] == record((ROOT / 'launch.json').read_bytes())
    assert report['inputs']['candidate'] == record((ROOT / 'receiver/candidate.json').read_bytes())
    observed = [item['fields'] for item in report['metadata'] if item['kind'] == 'TURN_MODEL_METADATA']
    assert observed == [dict(model='gpt-6.1-sol', effort='high')]
    return report


def traces_and_custody(report):
    calls = [item for item in report['events'] if item['kind'] == 'custom_tool_call']
    assert len(calls) == 6 and all(item['name'] == 'exec' for item in calls)
    sources = [(ROOT / 'trace' / item['source']['path']).read_text() for item in calls]
    assert sources[0].startswith('text(await tools.exec_command({cmd:"cat interface.txt response-contract.json evidence-contract.json submission.txt"')
    patch_text = json.loads(sources[4].split('tools.apply_patch(', 1)[1].rsplit('));', 1)[0])
    lines = patch_text.splitlines()
    assert lines[0] == '*** Begin Patch' and lines[-1] == '*** End Patch'
    assert lines[1] == '*** Add File: ' + str(ROOT / 'receiver/candidate.json')
    assert all(line.startswith('+') for line in lines[2:-1])
    created = ('\n'.join(line[1:] for line in lines[2:-1]) + '\n').encode()
    provided = (ROOT / 'receiver/candidate.json').read_bytes()
    saved = (ROOT / 'receiver/sessions/recipient/candidate.json').read_bytes()
    assert created == provided == saved
    result = json.loads((ROOT / 'receiver/submit.stdout').read_bytes())
    assert (ROOT / 'receiver/submit.stderr').read_bytes() == b''
    assert result['status'] == 'DRAFT_SAVED_SOURCE_LINKED' and result['draft_state'] == 'SAVED_EXACT_BYTES'
    assert result['candidate'] == record(saved)
    assert result['structural_verdict']['status'] == 'STRUCTURALLY_CONFORMANT'
    assert result['source_evidence_verdict']['status'] == 'SOURCE_SPANS_MATCH'
    assert result['source_evidence_verdict']['semantics'] == 'NOT_ASSESSED'
    assert len(result['calls']) == 1 and result['calls'][0]['action'] == 'finish_evidence'
    capture = result['calls'][0]['stdout']
    raw = base64.b64decode(capture['base64'], validate=True)
    assert capture['capture_complete'] and capture['extent'] == 'COMPLETE'
    assert record(raw) == {key: capture[key] for key in ('bytes', 'sha256')}
    assert raw == (ROOT / 'receiver/sessions/recipient/response-04.json').read_bytes()
    assert json.loads(raw) == result['client_response']
    return saved, result


def ledger(report, candidate):
    session = ROOT / 'receiver/sessions/recipient'
    expected = ['describe', 'catalog', 'page', 'finish_evidence']
    previous = sha((session / 'identity.json').read_bytes())
    manifest = sha((ROOT / 'receiver/manifest.json').read_bytes())
    observed_outputs = {}
    for event in report['events']:
        if event['kind'] != 'custom_tool_call_output':
            continue
        for block in event['value']:
            text = block.get('text', '')
            if text.startswith('{'):
                value = json.loads(text)
                if value.get('output', '').startswith('{'):
                    raw = value['output'].encode()
                    observed_outputs[json.loads(raw)['action']] = raw
                if event['line'] == 47:
                    assert value['exit_code'] == 0 and value['output'] == ''
    for index, action in enumerate(expected, 1):
        item_raw = (session / ('call-%02d.json' % index)).read_bytes()
        item = json.loads(item_raw)
        assert item['previous'] == previous and item['index'] == index
        assert item['action'] == action and item['status'] == 'OK'
        assert item['manifest_sha256'] == manifest and item['request_complete'] is True
        request_raw = pinned(session / ('request-%02d.json' % index), item['request'])
        response_raw = pinned(session / ('response-%02d.json' % index), item['response'])
        request, response = json.loads(request_raw), json.loads(response_raw)
        assert request['action'] == response['action'] == action and response['call'] == index
        if action == 'finish_evidence':
            assert base64.b64decode(request['candidate_base64'], validate=True) == candidate
            assert item['candidate'] == record(candidate)
        else:
            assert response_raw == observed_outputs[action] and item['candidate'] is None
        previous = sha(item_raw)
    assert not (session / 'call-05.json').exists()
    page = json.loads(observed_outputs['page'])['result']
    return page


def spans(candidate_raw, page):
    criteria_raw = (ROOT / 'proposed-criteria.json').read_bytes()
    criteria = json.loads(criteria_raw)
    source = pinned(Path(criteria['source']['path']), criteria['source'])
    assert criteria['source_utf8'].encode() == source
    assert base64.b64decode(page['base64'], validate=True) == source
    assert page['span'] == [0, len(source)] and page['end'] is True
    candidate = json.loads(candidate_raw)
    links = []
    for item in candidate['citations']:
        assert item['source_id'] == 'SOURCE' and item['source_sha256'] == sha(source)
        assert type(item['start']) is int and type(item['end']) is int
        assert item['quote'].encode('utf-8') == source[item['start']:item['end']]
        links.append([item['start'], item['end']])
    repeated = b'Same quotation.'
    first = source.index(repeated)
    second = source.index(repeated, first + 1)
    expected = [[first, first + len(repeated)], [second, second + len(repeated)]]
    assert links == [[0, 224]] and all(span not in links for span in expected)
    return dict(criteria_sha256=sha(criteria_raw), source=record(source), candidate=record(candidate_raw),
        citation_spans=links, repeated_occurrence_spans=expected,
        distinct_occurrence_citations_present=False)


def main():
    before = closure()
    report = retained_trace()
    candidate, submission = traces_and_custody(report)
    page = ledger(report, candidate)
    comparisons = spans(candidate, page)
    after = closure()
    assert before == after
    result = dict(schema='transport/fresh-recipient-evidence-check/1', status='DETERMINISTIC_EVIDENCE_CHECKS_PASSED',
        closure_before=before, closure_after=after, inputs_unchanged=True, comparisons=comparisons,
        submission_status=submission['status'], structural_status=submission['structural_verdict']['status'],
        citation_status=submission['source_evidence_verdict']['status'],
        citation_granularity='C3_REQUIRED_DISTINCT_OCCURRENCE_SPANS_ABSENT',
        launch_plaintext_dispatch='UNKNOWN_IN_SANITIZED_CAPTURE',
        scope='IDENTITY_CUSTODY_LEDGER_AND_EXACT_SOURCE_BYTES_ONLY', semantic_grade='SEPARATE_REVIEW')
    with (OUT / 'evidence-check.json').open('xb') as stream:
        stream.write(canonical(result) + b'\n')
    print(json.dumps(dict(status=result['status'], citation_granularity=result['citation_granularity'])))


if __name__ == '__main__':
    main()
