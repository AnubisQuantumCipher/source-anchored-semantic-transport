# Same-case task-contract repair replication

The first submitted candidate in trial 2 PASSED all unchanged frozen criteria
C1–C8 and the explicit per-line citation obligation. The source, package and
criteria are the same as trial 1. The changed caller task and response contract
require exactly five citations and explicitly request separate nonempty-line
intervals. This is a postfailure repair replication, not a new held-out case or
a matched-baseline comparison. Trial 1 remains FAILED on C3.

| Criterion | Trial 1 | Trial 2 | Trial 2 observation |
| --- | --- | --- | --- |
| C1 | PASS | PASS | Mira, obligation, every sample, 100 ms and maintenance exception remain together. |
| C2 | PASS | PASS | Noah, recording obligation, exact 225Q/87T literals remain without expansion. |
| C3 | FAIL | PASS | Both repeated passages have separate narrative identity and correct distinct source intervals. |
| C4 | PASS | PASS | λ😀 and relative approval/revocation sequence remain without invented subject or dates. |
| C5 | PASS | PASS | REVOKED is documentary status; decoder authority is NONE and there is no live permission. |
| C6 | PASS | PASS | Q/T meanings, λ😀 identity/grammatical role and calendar-date anchors remain unresolved. |
| C7 | PASS | PASS | Every quotation, source digest and location matches exact original bytes. |
| C8 | PASS | PASS | No additional source-content omission, contradiction, unsupported expansion, causal invention or semantic-proof claim was found. |

The independent source-byte comparison finds exactly these line intervals,
excluding newlines: `[0,78)`, `[79,137)`, `[138,153)`, `[154,169)` and `[170,223)`.
The identical repeated quotations therefore have distinct locations. The ordinary
shape checker enforces the citation count and the evidence checker enforces each
selected source-span match. Distinctness and complete line coverage were checked
independently; they are not newly claimed automatic properties of the contract
language.

The saved first candidate SHA-256 is
`3129980732e4dbe87f5b655ad94986ab0e412a8790a366ecaf1719b87774ac10`.
Provided and saved candidate bytes are identical. The observed writer helper's
literal source and prose fields, combined with independently derived source-line
records, reconstruct those exact serialized bytes. The reviewer parsed literal
data and did not run the recipient's helper, source text or candidate program.
Frozen file/source pins, native bundle identity, the complete source page,
session hash chain and checked-finish capture all match after evaluation.

The observed protocol satisfies the declared requirements: designated file
reads, fixed describe/catalog/page calls, one candidate write and one exact
checked submission. Its exit status was 0; stdout and empty stderr were retained.
No candidate revision, retry, alternate submission, delegation, network action or
outside-source access appears in the sanitized tool inventory. The final chat
identifies only output paths and status. Initial prompt plaintext equality remains
UNKNOWN because the sanitized capture has no suitable initial user plaintext
record. Observed model metadata reports `gpt-6.1-sol`, high reasoning, with the
designated child lineage; backend identity and hidden-access exclusion remain
unproved.

The old first-trial candidate's predeclared rejection control is preserved:
it fails the tightened shape contract with no client dispatch or session creation.
No first-trial candidate or assessment was changed. This result supports this
small synthetic continuation after a clearer task contract. It does not establish
causal superiority, broader task reliability, semantic completeness, external
validation, formal proof or whole-product acceptance. The root owner should carry
both first-trial failure and repair-replication success into any public receipt.
