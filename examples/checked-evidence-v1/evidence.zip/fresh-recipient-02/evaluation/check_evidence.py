"""Verify trial 2 with frozen identity, exact custody and line-level comparison."""
import ast
import base64
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/sicarii/Projects/source-anchored-semantic-transport/evidence/checked-evidence-v1/fresh-recipient-02')
OUT = ROOT / 'evaluation'
sys.path.insert(0, '/home/sicarii/Work/semantic-transport-evidence-links-20261028/install')
from transport_install_support import canonical, sha


def record(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def pinned(path, expected):
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    assert record(raw) == {key: expected[key] for key in ('bytes', 'sha256')}, str(path)
    return raw


def closure():
    launch = json.loads((ROOT / 'launch.json').read_bytes())
    raw = pinned(ROOT / 'freeze.json', launch['freeze'])
    frozen = json.loads(raw)
    assert len(frozen['files']) <= 128
    total = 0
    for item in frozen['files']:
        path = Path(item['path'])
        assert not path.is_absolute() and '..' not in path.parts
        total += len(pinned(ROOT / path, item))
    assert total == frozen['bytes']
    sources = json.loads((ROOT / 'source-freeze.json').read_bytes())
    assert len(sources['files']) <= 32
    for item in sources['files']:
        pinned(Path(item['path']), item)
    from test_portable_handoff import bundle_snapshot
    assert bundle_snapshot(Path(sources['native']['path'])) == sources['native']
    return dict(launch=record((ROOT / 'launch.json').read_bytes()), freeze=record(raw),
        files=len(frozen['files']), source_files=len(sources['files']), native_unchanged=True)


def trace():
    folder = ROOT / 'trace'
    report = json.loads((folder / 'report.json').read_bytes())
    assert report['source']['thread_id'] == '01a184fc-2d47-79f3-8ecf-6625bfb350b1'
    assert report['source']['agent_path'] == '/root/linked_source_repaired_receiver'
    assert report['source']['file_before'] == report['source']['file_after']
    assert len(report['events']) <= 32
    for item in report['events']:
        pinned(folder / item['path'], item)
        if 'source' in item:
            pinned(folder / item['source']['path'], item['source'])
    assert report['final_capture_state'] == 'SINGLE_COMPLETE_PLAINTEXT_FINAL'
    assert len(report['final_responses']) == 1
    final = report['final_responses'][0]['text_file']
    pinned(folder / final['path'], final)
    assert report['inputs']['launch'] == record((ROOT / 'launch.json').read_bytes())
    assert report['inputs']['candidate'] == record((ROOT / 'receiver/candidate.json').read_bytes())
    models = [x['fields'] for x in report['metadata'] if x['kind'] == 'TURN_MODEL_METADATA']
    assert models == [dict(model='gpt-6.1-sol', effort='high')]
    calls = [x for x in report['events'] if x['kind'] == 'custom_tool_call']
    assert len(calls) == 6 and all(x['name'] == 'exec' for x in calls)
    return report, calls


def expected_lines(source):
    expected, offset = [], 0
    lines = source.splitlines(keepends=True)
    assert len(lines) == 5
    for raw in lines:
        assert raw.endswith(b'\n') and len(raw) > 1
        quote = raw[:-1]
        expected.append(dict(source_id='SOURCE', source_sha256=sha(source), start=offset,
            end=offset + len(quote), quote=quote.decode('utf-8')))
        offset += len(raw)
    assert offset == len(source)
    return expected


def candidate_creation(calls, saved, source, expected):
    raw = (ROOT / 'trace' / calls[4]['source']['path']).read_text()
    command, _ = json.JSONDecoder().raw_decode(raw.split('exec_command({cmd:', 1)[1])
    body = command.split("<<'PY'\n", 1)[1].rsplit('\nPY', 1)[0]
    tree = ast.parse(body)
    source_value, literal = None, None
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id == 'source':
                source_value = ast.literal_eval(node.value)
            if node.targets[0].id == 'candidate':
                literal = node.value
    assert source_value.encode('utf-8') == source and isinstance(literal, ast.Dict)
    rebuilt = {}
    for key, value in zip(literal.keys, literal.values, strict=True):
        name = ast.literal_eval(key)
        rebuilt[name] = expected if name == 'citations' else ast.literal_eval(value)
    reconstructed = (json.dumps(rebuilt, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    assert reconstructed == saved
    return dict(status='EXACT_BYTES_RECONSTRUCTED_FROM_LITERAL_DATA_AND_INDEPENDENT_LINE_SPANS',
                source_or_candidate_program_executed=False)


def custody():
    provided = (ROOT / 'receiver/candidate.json').read_bytes()
    saved = (ROOT / 'receiver/sessions/recipient/candidate.json').read_bytes()
    assert provided == saved
    stdout = (ROOT / 'receiver/submit.stdout').read_bytes()
    result = json.loads(stdout)
    assert (ROOT / 'receiver/submit.stderr').read_bytes() == b''
    assert result['status'] == 'DRAFT_SAVED_SOURCE_LINKED' and result['draft_state'] == 'SAVED_EXACT_BYTES'
    assert result['candidate'] == record(saved)
    assert result['structural_verdict']['status'] == 'STRUCTURALLY_CONFORMANT'
    assert result['source_evidence_verdict']['status'] == 'SOURCE_SPANS_MATCH'
    assert result['source_evidence_verdict']['semantics'] == 'NOT_ASSESSED'
    assert result['source_evidence_verdict']['selected_records'] == 5
    assert len(result['calls']) == 1 and result['calls'][0]['action'] == 'finish_evidence'
    capture = result['calls'][0]['stdout']
    raw = base64.b64decode(capture['base64'], validate=True)
    assert capture['capture_complete'] and capture['extent'] == 'COMPLETE'
    assert record(raw) == {key: capture[key] for key in ('bytes', 'sha256')}
    assert raw == (ROOT / 'receiver/sessions/recipient/response-04.json').read_bytes()
    assert json.loads(raw) == result['client_response']
    return saved


def ledger(report, saved, source):
    observed = {}
    for event in report['events']:
        if event['kind'] != 'custom_tool_call_output':
            continue
        for item in event['value']:
            text = item.get('text', '')
            if text.startswith('{'):
                value = json.loads(text)
                if value.get('output', '').startswith('{'):
                    observed[json.loads(value['output'])['action']] = value['output'].encode()
                if event['line'] == 41:
                    assert value['exit_code'] == 0 and value['output'] == ''
    session = ROOT / 'receiver/sessions/recipient'
    manifest = sha((ROOT / 'receiver/manifest.json').read_bytes())
    previous = sha((session / 'identity.json').read_bytes())
    for index, action in enumerate(['describe', 'catalog', 'page', 'finish_evidence'], 1):
        raw = (session / ('call-%02d.json' % index)).read_bytes()
        item = json.loads(raw)
        assert item['previous'] == previous and item['index'] == index
        assert item['action'] == action and item['status'] == 'OK' and item['request_complete'] is True
        assert item['manifest_sha256'] == manifest
        request = json.loads(pinned(session / ('request-%02d.json' % index), item['request']))
        response = pinned(session / ('response-%02d.json' % index), item['response'])
        assert request['action'] == json.loads(response)['action'] == action
        if action == 'finish_evidence':
            assert base64.b64decode(request['candidate_base64'], validate=True) == saved
            assert item['candidate'] == record(saved)
        else:
            assert response == observed[action] and item['candidate'] is None
        previous = sha(raw)
    assert not (session / 'call-05.json').exists()
    page = json.loads(observed['page'])['result']
    assert base64.b64decode(page['base64'], validate=True) == source
    assert page['span'] == [0, len(source)] and page['end'] is True


def main():
    before = closure()
    report, calls = trace()
    saved = custody()
    criteria_raw = (ROOT / 'proposed-criteria.json').read_bytes()
    criteria = json.loads(criteria_raw)
    source = pinned(Path(criteria['source']['path']), criteria['source'])
    expected = expected_lines(source)
    assert json.loads(saved)['citations'] == expected
    assert len({(x['start'], x['end']) for x in expected}) == 5
    creation = candidate_creation(calls, saved, source, expected)
    ledger(report, saved, source)
    after = closure()
    assert before == after
    result = dict(schema='transport/fresh-recipient-evidence-check/1', status='DETERMINISTIC_EVIDENCE_CHECKS_PASSED',
        closure_before=before, closure_after=after, inputs_unchanged=True, candidate=record(saved),
        source=record(source), criteria_sha256=sha(criteria_raw), source_line_citations=expected,
        per_line_exact_coverage=True, distinct_intervals=True, citation_count=5, creation=creation,
        launch_plaintext_dispatch='UNKNOWN_IN_SANITIZED_CAPTURE',
        scope='IDENTITY_CUSTODY_LEDGER_AND_EXACT_SOURCE_LINE_BYTES_ONLY', semantic_grade='SEPARATE_REVIEW')
    with (OUT / 'evidence-check.json').open('xb') as stream:
        stream.write(canonical(result) + b'\n')
    print(json.dumps(dict(status=result['status'], per_line_exact_coverage=True, distinct_intervals=True)))


if __name__ == '__main__':
    main()
