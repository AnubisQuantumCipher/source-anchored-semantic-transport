# Source-Anchored Semantic Transport lexicon.md

All metadata below are unverified declarations.
Original bytes are retained. Binary media are retained, not understood.
Anchors prove references to selected bytes only; they do not prove a reading.

<pre>
SOURCES
id: SOURCE
label: Synthetic requirement and history
media_type: text/plain; charset=utf-8
provenance: Synthetic test data; not an authenticated statement.

INTERPRETATIONS
anchors: &#91;{&quot;sha256&quot;:&quot;d861b135e7933adc207311da8ac3665dc96def595bb6c4c705923616b556a9a8&quot;,&quot;source&quot;:&quot;SOURCE&quot;,&quot;span&quot;:&#91;0,224&#93;}&#93;
id: I&#95;SOURCE
label: SOURCE
provenance: Integration fixture.
status: proposed
text: Unverified synthetic source record.

UNCERTAINTIES
RELATIONS
</pre>

Interpretation supplied: YES
Coverage is a byte-reference report; no semantic completeness is claimed.

## Fixed definitions

- Σ: Documentary source group only; not an arithmetic sum, universal quantifier or completeness claim.
- I: Ordered declared interpretation IDs and statuses; none means no interpretation was supplied.
- U: Ordered uncertainty IDs; none means no uncertainty record was supplied, not absence of uncertainty.
- R: Ordered declared relations, written first kind second; no causality, execution or authority is implied.
- anchor: Half-open offsets [begin,end) in exact original bytes with SHA-256 of the selected bytes; a reference only, not entailment.
- M: Typed meaning units with indexed operator trees, fixed dictionary identities and declared context dependencies; interpretation and adequacy remain unproved.
- supports: Declared support from the first record to the second; no entailment or truth is verified.
- contradicts: Declared conflict between the first record and the second; no inconsistency is proved.
- qualifies: The first record declares a qualification on the second; no scope or adequacy is verified.
- derived_from: The first record is declared derived from the second; no derivation is checked.
- supersedes: The first record is declared to replace the second in this reading; no authority is granted.

## Typed meaning units

Types and source occurrences are checked. Interpretation, completeness and context adequacy remain UNPROVEN.
Historical approvals are evidence only. No unit grants current execution authority.

### U_SOURCE / source_claim

Source: SOURCE; interpretation: I_SOURCE
Declared context units: 

| Symbol | Exact source literal |
|---|---|
| BLOCK | Keeper Mira shall log every sample within 100 ms unless maintenance is active.\u000aObserver Noah shall record 225Q events from a base of 87T.\u000aSame quotation.\u000aSame quotation.\u000aλ😀 approved yesterday; approval is revoked today.\u000a |

| Operator | Argument types | Result | Exact definition |
|---|---|---|---|
| all | var, term, prop | prop | Bind the first variable universally over the declared domain in the body. |
| and | prop, prop | prop | Both propositions hold in the declared reading. |
| attribution | term, prop | prop | First operand is the source of the claim; no narrator endorsement. |
| belief | term, prop | prop | First operand believes the proposition; not asserted as fact. |
| cause | prop, prop | prop | Declared causal claim from first operand to second; not verified causality. |
| if | prop, prop | prop | First operand is a sufficient condition for the second in the declared reading. |
| may | prop | prop | Declared permission; no obligation to perform it. |
| must | prop | prop | Declared obligation; no satisfaction or authority verdict. |
| not | prop | prop | Negate the enclosed proposition. |
| only&#95;after | prop, prop | prop | First operand may occur only after the second is complete; no occurrence is promised or authorized. |
| parallel | prop, prop | prop | Tracks proceed in parallel; no interaction or completion rule implied. |
| pred | text, term-or-var... | prop | Source predicate applied to ordered explicit terms or bound variables; interpretation is declared. |
| quantity | text, text | term | Exact amount spelling and unit spelling; no evaluation or conversion. |
| requires | prop, prop | prop | Second operand is necessary for the first; does not authorize execution. |
| sequence | prop, prop | prop | First operand precedes the second; no causation implied. |
| should | prop | prop | Declared recommendation, distinct from an obligation. |
| some | var, term, prop | prop | Bind the first variable existentially over the declared domain in the body. |
| uncertain | text, prop | prop | Retain the exact uncertainty qualification on this proposition. |
| unless | prop, prop | prop | Second operand is an exception to the first; no converse obligation implied. |
| within | prop, term | prop | Declared inclusive deadline quantity for this proposition; origin must be explicit or ambiguous. |

<pre>
n0 = atom&#40;BLOCK&#41;\u000aroot n0
</pre>

<pre>{&quot;context&quot;:&#91;&#93;,&quot;dictionaries&quot;:&#91;{&quot;content&quot;:{&quot;entries&quot;:{&quot;all&quot;:{&quot;args&quot;:&#91;&quot;var&quot;,&quot;term&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Bind the first variable universally over the declared domain in the body.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;and&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Both propositions hold in the declared reading.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;attribution&quot;:{&quot;args&quot;:&#91;&quot;term&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;First operand is the source of the claim; no narrator endorsement.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;belief&quot;:{&quot;args&quot;:&#91;&quot;term&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;First operand believes the proposition; not asserted as fact.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;cause&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Declared causal claim from first operand to second; not verified causality.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;if&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;First operand is a sufficient condition for the second in the declared reading.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;may&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Declared permission; no obligation to perform it.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;must&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Declared obligation; no satisfaction or authority verdict.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;not&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Negate the enclosed proposition.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;only&#95;after&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;First operand may occur only after the second is complete; no occurrence is promised or authorized.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;parallel&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Tracks proceed in parallel; no interaction or completion rule implied.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;pred&quot;:{&quot;args&quot;:&#91;&quot;text&quot;,&quot;term-or-var...&quot;&#93;,&quot;definition&quot;:&quot;Source predicate applied to ordered explicit terms or bound variables; interpretation is declared.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;quantity&quot;:{&quot;args&quot;:&#91;&quot;text&quot;,&quot;text&quot;&#93;,&quot;definition&quot;:&quot;Exact amount spelling and unit spelling; no evaluation or conversion.&quot;,&quot;result&quot;:&quot;term&quot;},&quot;requires&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Second operand is necessary for the first; does not authorize execution.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;sequence&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;First operand precedes the second; no causation implied.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;should&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Declared recommendation, distinct from an obligation.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;some&quot;:{&quot;args&quot;:&#91;&quot;var&quot;,&quot;term&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Bind the first variable existentially over the declared domain in the body.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;uncertain&quot;:{&quot;args&quot;:&#91;&quot;text&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Retain the exact uncertainty qualification on this proposition.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;unless&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;prop&quot;&#93;,&quot;definition&quot;:&quot;Second operand is an exception to the first; no converse obligation implied.&quot;,&quot;result&quot;:&quot;prop&quot;},&quot;within&quot;:{&quot;args&quot;:&#91;&quot;prop&quot;,&quot;term&quot;&#93;,&quot;definition&quot;:&quot;Declared inclusive deadline quantity for this proposition; origin must be explicit or ambiguous.&quot;,&quot;result&quot;:&quot;prop&quot;}},&quot;id&quot;:&quot;transport-operators&quot;,&quot;role&quot;:&quot;operators&quot;,&quot;schema&quot;:&quot;transport/dictionary/1&quot;,&quot;version&quot;:&quot;1&quot;},&quot;id&quot;:&quot;transport-operators&quot;,&quot;role&quot;:&quot;operators&quot;,&quot;sha256&quot;:&quot;021441fbc5ec70acca1818b44cbf4af91500743aa5523bc406700f7241eefa07&quot;,&quot;version&quot;:&quot;1&quot;},{&quot;content&quot;:{&quot;entries&quot;:{&quot;BLOCK&quot;:&quot;Keeper Mira shall log every sample within 100 ms unless maintenance is active.\nObserver Noah shall record 225Q events from a base of 87T.\nSame quotation.\nSame quotation.\nλ😀 approved yesterday; approval is revoked today.\n&quot;},&quot;id&quot;:&quot;document-symbols&quot;,&quot;role&quot;:&quot;symbols&quot;,&quot;schema&quot;:&quot;transport/dictionary/1&quot;,&quot;version&quot;:&quot;1&quot;},&quot;id&quot;:&quot;document-symbols&quot;,&quot;role&quot;:&quot;symbols&quot;,&quot;sha256&quot;:&quot;dc000d07801daeaf1afbebeceb29e765c58139746a54952ed9d91f1ddd779a40&quot;,&quot;version&quot;:&quot;1&quot;}&#93;,&quot;grammar&quot;:&quot;transport/meaning/1&quot;,&quot;id&quot;:&quot;U&#95;SOURCE&quot;,&quot;interpretation&quot;:&quot;I&#95;SOURCE&quot;,&quot;kind&quot;:&quot;source&#95;claim&quot;,&quot;meaning&quot;:{&quot;ambiguities&quot;:&#91;&#93;,&quot;nodes&quot;:&#91;{&quot;op&quot;:&quot;atom&quot;,&quot;span&quot;:&#91;0,224&#93;,&quot;symbol&quot;:&quot;BLOCK&quot;}&#93;,&quot;root&quot;:0,&quot;schema&quot;:&quot;transport/meaning/1&quot;},&quot;source&quot;:&quot;SOURCE&quot;}</pre>


## Decoder and boundary

Use the separately supplied Transport decoder and matching runtime; never execute archive content.
This ZIP has exactly manifest.json, codec.json, index.json, formula.txt, README.md.
README.md is this lexicon.md document; the separately returned lexicon bytes are identical.
STS1 binds bytes and declarations, not author identity, truth, confidentiality or authority.
No reference is fetched. Missing or incompatible external dependencies refuse before reconstruction.
External trusted runtime; hash-then-use does not isolate hostile concurrent same-user mutation.
