#!/usr/bin/env python3
"""Bounded case-02 whitelist retention; no instructions/reasoning/account export."""
import ast
import base64
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).absolute().parent
E = OUT.parent
EVAL = E / 'evaluation-02'
CASE = E / 'case-02'
WORK = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
LOGDIR = Path('/home/sicarii/.codex/sessions/2026/10/28')
ROOTLOG = Path('/home/sicarii/.codex/sessions/2026/10/25/rollout-2026-10-25T20-34-20-01a175a1-2f57-7d91-a157-7e4375dcf7b0.jsonl')
PRIOR = E / 'trace-01/extract_trace.py'
RESERVE, BUDGET = 10000000000, 4194304
LOGS = {'original':'rollout-2026-10-28T23-49-44-01a185c7-27cd-7251-800e-f56e173b57f7.jsonl',
        'transport':'rollout-2026-10-28T23-49-51-01a185c7-45a7-7fb1-81c4-0d75f5126bc6.jsonl'}
EXPECTED = {'original':'ca518cfc5b29a8beec8bc4b7e5b46f990d433f8be9366a9312dcfc75b84999f6',
            'transport':'3dbd9bcfc0aa63ec7e5bf004cec4be7b73793faaeccd48d18ba9746034a9dad4'}
sys.path.insert(0, str(WORK/'install'))
from transport_install_support import canonical, read_regular, require, sha


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


old = module('first_trial_trace_helpers', PRIOR)
old.CASE = CASE
checker = module('heldout_case_checker', WORK/'examples/heldout-release-v1/check_response.py')


def usage():
    files = []
    for directory in (OUT, EVAL):
        if directory.exists():
            files.extend(directory.iterdir())
    require(len(files) <= 256 and all(p.is_file() and not p.is_symlink() for p in files),
            'bounded regular export files required')
    return sum(p.stat().st_size for p in files)


def save(directory, name, raw):
    require(directory in (OUT, EVAL) and '/' not in name and len(raw) <= 1048576,
            'export location/single-file bound')
    require(not any(word in raw for word in old.FORBIDDEN), 'private field forbidden in export')
    require(usage() + len(raw) <= BUDGET, 'combined new-output budget exceeded')
    require(shutil.disk_usage(E).free >= RESERVE + len(raw), '10GB reserve must survive export')
    with (directory/name).open('xb') as stream:
        require(stream.write(raw) == len(raw), 'short evidence write')
    return old.pin(directory/name, raw)


def record(directory, name, value):
    return save(directory, name, canonical(value)+b'\n')


def bootstrap(rows):
    records = []
    for location, obj in rows:
        payload = obj.get('payload', {})
        if obj['type'] != 'response_item' or payload.get('type') != 'agent_message':
            continue
        content = payload.get('content', [])
        require(type(content) is list and len(content) <= 16, 'bootstrap block count')
        plain, omitted = [], []
        for item in content:
            if item['type'] == 'input_text':
                plain.append(item['text'])
            else:
                value = item.get('encrypted_content')
                require(type(value) is str, 'unrecognized omitted bootstrap block')
                omitted.append(dict(bytes=len(value.encode()), sha256=sha(value.encode())))
        records.append(dict(source=location, timestamp=obj.get('timestamp'),
            plaintext_segments=plain, omitted_payload_pins=omitted,
            body_status='ENCRYPTED_IN_LOG_NOT_EXPORTED_NOT_RECONSTRUCTED'))
    require(len(records) == 1, 'one bootstrap envelope expected')
    return records


def exported_run(arm):
    path = LOGDIR/LOGS[arm]
    raw, rows = old.log_rows(path)
    meta = old.metadata(rows)
    session_meta = next(obj['payload'] for _,obj in rows if obj['type'] == 'session_meta')
    meta['session']['value']['model_provider'] = session_meta['model_provider']
    selected, calls, output_sizes, final = [], [], [], []
    for location,obj in rows:
        payload = obj.get('payload', {})
        kind = payload.get('type')
        if obj['type'] != 'response_item':
            continue
        if kind in ('custom_tool_call','custom_tool_call_output','function_call','function_call_output'):
            value = old.tool_value(payload)
            selected.append(dict(source=location,timestamp=obj.get('timestamp'),payload=value))
            if kind.endswith('_output'):
                output_sizes.append(dict(call_id=value['call_id'],
                    text_blocks=[dict(bytes=len(item['text'].encode()),sha256=sha(item['text'].encode()),
                                      host_truncation_warning='Warning: truncated output' in item['text'])
                                 for item in value['output']]))
            else:
                text = value.get('input',value.get('arguments',''))
                first = text.split('\n',1)[0]
                directive = json.loads(first[len('// @exec:'):]) if first.startswith('// @exec:') else None
                rest = text.split('\n',1)[1] if directive is not None else text
                calls.append(dict(call_id=value['call_id'],name=value['name'],outer_exec_directive=directive,
                    nested_output_maxes_lexically_observed=re.findall(r'max_output_tokens\s*:\s*([0-9]+)',rest)))
        elif kind == 'message' and payload.get('role') == 'assistant' and payload.get('phase') == 'final_answer':
            require(all(item['type']=='output_text' for item in payload['content']), 'plain final text required')
            final.append(dict(source=location,text='\n'.join(item['text'] for item in payload['content'])))
    tools = save(OUT,arm+'-selected-tools.jsonl',b''.join(canonical(item)+b'\n' for item in selected))
    value = dict(schema='transport/selected-case02-session/1',source_snapshot=old.pin(path,raw),
        selected_tools=tools,tool_calls=calls,actual_host_tool_calls=len(calls),tool_output_sizes=output_sizes,
        bootstrap=bootstrap(rows),final_messages=final,**meta,
        usage_boundary='Host reported cumulative/turn usage includes instructions, tools and repeated context. Not attributable document tokens or billing.',
        latency_boundary='Recorded host lifecycle duration_ms/time_to_first_token_ms only; no independently derived or causal latency comparison.',
        billed_cost='UNKNOWN_NOT_REPORTED',reasoning_and_global_instructions='OMITTED')
    record(OUT,arm+'-metadata.json',value)
    require(read_regular(path,4194304)==raw,'session changed during export')
    return value


def check_reader(arm,sources):
    root,manifest_raw,helpers = old.receiver_files(arm,sources)
    directory = root/'sessions/recipient'
    files = old.session.members(directory)
    digest = sha(manifest_raw)
    require(files['identity.json']==canonical(old.session.identity(root/'manifest.json',digest)),
            'session identity mismatch')
    previous,allowed,finished,calls = sha(files['identity.json']),{'identity.json','lock'},False,[]
    for number in range(1,33):
        name='call-%02d.json'%number
        if name not in files:
            break
        require(not finished,'call after first saved submission')
        item=old.session.checked_log(files[name],number,previous,digest)
        for kind in ('request','response'):
            key='%s-%02d.json'%(kind,number)
            require(old.inputs.record(files[key])==item[kind],'reader stream identity differs')
            allowed.add(key)
        response=json.loads(files['response-%02d.json'%number])
        require(response['call']==number and response['action']==item['action']
                and response['status']==item['status'],'response metadata mismatch')
        finished=item['action'] in ('finish','finish_evidence') and item['status']=='OK'
        require((item['candidate'] is not None)==finished,'candidate state mismatch')
        if finished:
            require(old.inputs.record(files['candidate.json'])==item['candidate'],'candidate pin mismatch')
            request=json.loads(files['request-%02d.json'%number])
            require(base64.b64decode(request['candidate_base64'],validate=True)==files['candidate.json'],
                    'submitted bytes differ from saved bytes')
            allowed.add('candidate.json')
        allowed.add(name)
        calls.append(item)
        previous=sha(files[name])
    require(set(files)==allowed and finished and calls[-1]['action']=='finish','closed finished reader chain required')
    require(sha(files['candidate.json'])==EXPECTED[arm],'first candidate differs from supplied pin')
    exports=[save(EVAL,arm+'-'+name,raw) for name,raw in sorted(files.items())]
    return dict(status='EXACT_FIRST_SUBMISSION_AND_CHAIN_MATCH',calls=calls,actual_reader_calls=len(calls),
        terminal_hash=previous,candidate=old.pin(directory/'candidate.json'),retained_streams=exports,
        manifest=old.pin(root/'manifest.json'),prepared_helpers=helpers)


def dispatches():
    size=ROOTLOG.stat().st_size
    start=max(0,size-4194304)
    with ROOTLOG.open('rb') as stream:
        stream.seek(start)
        raw=stream.read(4194304)
    if start:
        cut=raw.index(b'\n')+1
        start,raw=start+cut,raw[cut:]
    chunks=raw.splitlines(keepends=True)
    require(len(chunks)<=4096,'root tail line bound')
    found,offset=[],start
    for line in chunks:
        require(len(line)<=2097152,'root tail line byte bound')
        obj=json.loads(line)
        payload=obj.get('payload',{})
        if obj.get('type')=='response_item' and payload.get('name')=='spawn_agent':
            args=json.loads(payload['arguments'])
            if args.get('task_name') in ('museum_retest_original','museum_retest_transport'):
                message=args['message'].encode()
                found.append(dict(timestamp=obj.get('timestamp'),byte_start=offset,
                    raw_line_sha256=sha(line),settings={key:args.get(key) for key in
                        ('task_name','fork_turns','model','reasoning_effort')},
                    omitted_message=dict(bytes=len(message),sha256=sha(message)),
                    prompt_status='ENCRYPTED_IN_ROOT_LOG_PLAINTEXT_NOT_AVAILABLE'))
        offset+=len(line)
    require(len(found)==2,'both selected dispatch records required')
    return dict(root_tail=dict(path=str(ROOTLOG),byte_start=start,bytes=len(raw),sha256=sha(raw)),selected=found)


def prior_evaluator():
    path=LOGDIR/'rollout-2026-10-28T23-41-06-01a185bf-408f-7da3-8ac8-1ac8a951ecb7.jsonl'
    raw,rows=old.log_rows(path)
    value=old.metadata(rows)
    meta=next(obj['payload'] for _,obj in rows if obj['type']=='session_meta')
    value['session']['value']['model_provider']=meta['model_provider']
    return dict(source_snapshot=old.pin(path,raw),**value,
                scope='Actual model/effort/provider/CLI and host lifecycle/usage metadata only; no verdict re-review.')


def freeze_evaluation():
    snapshot=json.loads(read_regular(E/'evaluation-freeze-02.json'))
    require(len(snapshot['files'])<=32,'evaluation freeze file count')
    for item in snapshot['files']:
        old.verify_pin(item)
    retained=[]
    for name in ('fixture.json','criteria.json','task.txt','plan.json','input-freeze.json','preparation.json'):
        raw=read_regular(CASE/name,131072)
        retained.append(save(EVAL,name,raw))
    retained.append(save(EVAL,'pre-dispatch-evaluation-freeze.json',read_regular(E/'evaluation-freeze-02.json')))
    return dict(pre_dispatch=old.pin(E/'evaluation-freeze-02.json'),retained_inputs=retained,
                checker_source=old.pin(WORK/'examples/heldout-release-v1/check_response.py'))


def deterministic(arm):
    result=json.loads(read_regular(EVAL/(arm+'.stdout'),131072))
    require(result['inputs']['candidate']['sha256']==EXPECTED[arm], 'owner assessment candidate differs')
    return dict(status='EXISTING_OWNER_ASSESSMENT_FROZEN_NOT_RERUN',
        output=old.pin(EVAL/(arm+'.stdout')),process=old.pin(EVAL/(arm+'-process.json')),
        stderr=old.pin(EVAL/(arm+'.stderr')),observed_status=result['status'],
        boundary='Finite author-table check only; source fidelity remains a separate reviewer assessment.')


def receipts(free_before):
    evaluation_files=sorted(EVAL.iterdir())
    er=record(EVAL,'receipt.json',dict(schema='transport/case02-output-freeze/1',status='EXACT_OUTPUTS_RETAINED',
        files=[old.pin(path) for path in evaluation_files],first_submission_only=True,
        interpretation_entailment='UNPROVEN',narrative_fidelity='PENDING_SEPARATE_REVIEW'))
    trace_files=sorted(OUT.iterdir())
    tr=record(OUT,'receipt.json',dict(schema='transport/case02-selected-trace/1',status='EXPORTED_SCOPED',
        files=[old.pin(path) for path in trace_files],evaluation_receipt=er,
        storage=dict(free_bytes_before=free_before,free_bytes_before_receipt=shutil.disk_usage(E).free,
                     reserve_bytes=RESERVE,combined_new_output_cap=BUDGET),
        privacy='Whitelisted model/lifecycle/usage, tool payloads and bootstrap envelope only. Global instructions, reasoning, account data and encrypted prompt bodies omitted.',
        limitations='No hidden-access/sandbox proof, model-text tokenizer mapping or billed cost; no statistical/causal comparison.'))
    require(shutil.disk_usage(E).free>=RESERVE,'reserve fell below 10GB after writes')
    return er,tr


def main():
    free=shutil.disk_usage(E).free
    require(free>=RESERVE+BUDGET,'reserve plus full export allowance required')
    require(OUT.name=='trace-02' and {path.name for path in OUT.iterdir()}==
            {'extract_trace.py','admission-refusal.json'},'new trace or retained admission refusal required')
    require(EVAL.is_dir() and not EVAL.is_symlink(),'owner evaluation directory required')
    initial_files=list(EVAL.iterdir())
    require(len(initial_files)<=16,'initial owner output file count')
    initial={str(path):read_regular(path,131072) for path in initial_files}
    for node in ast.walk(ast.parse(read_regular(Path(__file__)))):
        if isinstance(node,ast.FunctionDef):
            require(node.end_lineno-node.lineno+1<=60,'extractor function size bound')
    freeze,sources=old.freeze_chain()
    record(OUT,'freeze-verification.json',freeze)
    frozen=freeze_evaluation()
    record(EVAL,'evaluation-input-pins.json',frozen)
    runs={arm:exported_run(arm) for arm in LOGS}
    readers={arm:check_reader(arm,sources) for arm in LOGS}
    record(OUT,'reader-chains.json',readers)
    assessments={}
    for arm in LOGS:
        save(EVAL,arm+'-interface.txt',read_regular(CASE/('receiver-'+arm)/'interface.txt'))
        assessments[arm]=deterministic(arm)
    record(OUT,'owner-assessment-pins.json',assessments)
    record(OUT,'bootstrap-dispatch-metadata.json',dispatches())
    record(OUT,'prior-source-evaluator-settings.json',prior_evaluator())
    record(OUT,'measurement-boundary.json',dict(tokenizer=old.tokenizer_status(),
        source_bytes={name:len(raw) for name,raw in sources.items()},task_bytes=len(read_regular(CASE/'task.txt')),
        tool_calls={arm:run['actual_host_tool_calls'] for arm,run in runs.items()},
        reader_calls={arm:run['actual_reader_calls'] for arm,run in readers.items()},
        byte_totals_scope='File and UTF-8 text lengths observed separately; host token usage is not document usage or billed cost.',
        timing='Reported lifecycle fields only; no derived elapsed times or ratios.',prior_extractor=old.pin(PRIOR)))
    require(all(read_regular(Path(path),131072)==raw for path,raw in initial.items()),
            'pre-existing owner evaluation output changed')
    er,tr=receipts(free)
    print(json.dumps(dict(status='EXPORTED_SCOPED',evaluation_receipt=er,trace_receipt=tr,
                         observed_new_bytes=usage(),free_bytes_after=shutil.disk_usage(E).free)))


if __name__=='__main__':
    main()
