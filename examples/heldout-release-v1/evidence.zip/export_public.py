import hashlib
import io
import json
from pathlib import Path
import stat
import zipfile

E = Path('/home/sicarii/Projects/source-anchored-semantic-transport/evidence/heldout-release-v1')
W = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
D = W / 'examples/heldout-release-v1'
MAX_ENTRY, MAX_TOTAL, MAX_ZIP = 262144, 4194304, 2097152


def read(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_ENTRY:
        raise ValueError('entry bound/type: ' + str(path))
    data = path.read_bytes()
    if len(data) != info.st_size:
        raise ValueError('entry changed')
    return data


def record(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def selection():
    groups = ('package-01', 'checks-01', 'regression-01', 'reuse-01',
              'evaluation-01', 'evaluation-02', 'trace-01', 'trace-02',
              'bound-case-01', 'bound-case-02', 'budget-200', 'paging-01')
    entries = {}
    for group in groups:
        paths = sorted((E / group).iterdir())
        if len(paths) > 160:
            raise ValueError('group entry bound')
        for path in paths:
            if path.is_file():
                entries[str(path.relative_to(E))] = read(path)
    extra = ('criteria-before-review.json', 'pre-dispatch-source-review.json',
             'runtime-reuse-review.json', 'final-preparation-review.json',
             'archive-preflight-before-table.json', 'evaluation-freeze.json',
             'evaluation-freeze-02.json', 'paging-launch-refusal.json',
             'byte-measurements.json', 'final-release-review.json',
             'source-review-model-02.json', 'retest-trace-assessment.json',
             'tmpfs-preservation.json')
    for name in extra:
        entries[name] = read(E / name)
    for name in ('arm-equality.json', 'exact-recovery.json', 'focus-check.json',
                 'preparation.json', 'input-freeze.json'):
        entries['case-02/' + name] = read(E / 'case-02' / name)
    for base in (E / 'checks-02', *(E / 'checks-02' / n for n in ('attempt-02', 'attempt-03', 'attempt-04'))):
        for path in sorted(base.iterdir()):
            if path.is_file():
                entries[str(path.relative_to(E))] = read(path)
    for path in sorted((E / 'case-02/commands').iterdir()):
        if path.is_file():
            entries[str(path.relative_to(E))] = read(path)
    entries['export_public.py'] = read(Path(__file__))
    if len(entries) > 512 or sum(map(len, entries.values())) > MAX_TOTAL:
        raise ValueError('selection bound')
    return entries


def archive(entries):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, raw in sorted(entries.items()):
            path = Path(name)
            if path.is_absolute() or '..' in path.parts or '\\' in name:
                raise ValueError('unsafe selected path')
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o600) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(info, raw, compresslevel=9)
    result = stream.getvalue()
    if len(result) > MAX_ZIP:
        raise ValueError('archive bound')
    return result


def publish(entries, raw):
    if archive(entries) != raw:
        raise ValueError('nondeterministic archive')
    with zipfile.ZipFile(io.BytesIO(raw)) as stored:
        if stored.namelist() != sorted(entries):
            raise ValueError('membership mismatch')
        for name, expected in entries.items():
            if stored.read(name) != expected:
                raise ValueError('readback mismatch')
    with (D / 'evidence.zip').open('xb') as output:
        output.write(raw)
    for name in ('share.txt', 'meaning.zip', 'lexicon.md'):
        data = read(E / 'case-02/encoded' / name)
        with (D / name).open('xb') as output:
            output.write(data)
        if read(D / name) != data:
            raise ValueError('pair readback mismatch')
    if read(D / 'evidence.zip') != raw:
        raise ValueError('archive disk readback mismatch')


def main():
    entries = selection()
    raw = archive(entries)
    publish(entries, raw)
    reuse = json.loads(entries['reuse-01/receipt.json'])
    evaluations = {}
    for arm in ('original', 'transport'):
        result = json.loads(entries['evaluation-02/' + arm + '.stdout'])
        bound = json.loads(entries['bound-case-02/retest-' + arm + '.stdout'])
        evaluations[arm] = dict(deterministic_status=result['status'],
                                behavior=result['behavior'],
                                native_outcome=bound['evaluation']['outcome'],
                                candidate=record(entries['evaluation-02/' + arm + '-candidate.json']))
    receipt = dict(schema='transport/heldout-public-evidence/1', status='EXPORTED_CHECKED',
                   archive=record(raw), entries={k: record(v) for k, v in sorted(entries.items())},
                   expanded_bytes=sum(map(len, entries.values())), entry_count=len(entries),
                   all_entry_readbacks_equal=True, deterministic_construction_checked=True,
                   pair={n: record(read(D / n)) for n in ('share.txt', 'meaning.zip', 'lexicon.md')},
                   source_sha256=reuse['new_source_sha256'], runtime_sha256=reuse['new_runtime_sha256'],
                   install_sha256=reuse['new_install_sha256'], decoder_native_sha256=reuse['native_sha256'],
                   evaluations=evaluations, native_build='UNPERFORMED', new_formal_proof='NOT_RUN',
                   source_authentication='NOT_PROVIDED', semantic_completeness='UNPROVEN',
                   superiority='NOT_DEMONSTRATED', decoder_bundle_included=False,
                   privacy='Selected fictional task data and whitelisted traces; no global instructions, reasoning, credentials or account data. Captured local paths retained inside evidence for hash fidelity.',
                   scope='Bounded exact-byte selection; hashes detect changes, not authenticity. Full local campaign retained separately.')
    target = W / 'receipts/heldout-release-1.json'
    with target.open('xb') as output:
        output.write(json.dumps(receipt, sort_keys=True, separators=(',', ':')).encode() + b'\n')
    print(json.dumps(dict(archive=record(raw), entry_count=len(entries), receipt=record(read(target)))))


if __name__ == '__main__':
    main()
