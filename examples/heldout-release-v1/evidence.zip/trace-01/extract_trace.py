#!/usr/bin/env python3
"""Bounded, selected first-trial export; never export instructions or reasoning."""
import ast
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).absolute().parent
CASE = OUT.parent / 'case-01'
WORK = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
SESSIONS = Path('/home/sicarii/.codex/sessions/2026/10/28')
sys.path.insert(0, str(WORK / 'install'))
import transport_handoff_inputs as inputs
import transport_handoff_session as session
from test_portable_handoff import bundle_snapshot
from transport_install_support import canonical, read_regular, require, sha

LOGS = {
    'original': 'rollout-2026-10-28T23-37-21-01a185bb-d381-7af0-85e5-08690ee9b374.jsonl',
    'transport': 'rollout-2026-10-28T23-37-27-01a185bb-e93a-7f10-ba5e-7a2d3787a6dc.jsonl'}
FORBIDDEN = (b'encrypted_content', b'base_instructions', b'user_instructions',
             b'creator_account_id', b'creator_user_id', b'internal_chat_message_metadata')
TOKEN_KEYS = ('input_tokens', 'cached_input_tokens', 'cache_write_input_tokens',
              'output_tokens', 'reasoning_output_tokens', 'total_tokens')


def pin(path, raw=None):
    data = read_regular(path, 4194304) if raw is None else raw
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save(name, raw):
    require('/' not in name and len(raw) <= 262144, 'single export name/byte bound')
    require(not any(word in raw for word in FORBIDDEN), 'forbidden private field in export')
    existing = list(OUT.iterdir())
    require(len(existing) <= 64 and all(item.is_file() and not item.is_symlink()
                                       for item in existing), 'trace tree bound/type')
    if (OUT / name).exists():
        require('--resume-verified-partial' in sys.argv
                and read_regular(OUT / name, 262144) == raw, 'partial export bytes differ')
        return pin(OUT / name, raw)
    require(sum(item.stat().st_size for item in existing) + len(raw) <= 1048576,
            'trace aggregate byte cap')
    with (OUT / name).open('xb') as stream:
        require(stream.write(raw) == len(raw), 'short export write')
    return pin(OUT / name, raw)


def record(name, value):
    return save(name, canonical(value) + b'\n')


def tokens(value):
    require(type(value) is dict and set(value) <= set(TOKEN_KEYS), 'token field whitelist')
    require(all(type(item) is int and item >= 0 for item in value.values()), 'token count types')
    return dict(value)


def log_rows(path):
    raw = read_regular(path, 4194304)
    chunks = raw.splitlines(keepends=True)
    require(len(chunks) <= 512, 'session record count bound')
    rows, offset = [], 0
    for number, line in enumerate(chunks, 1):
        require(len(line) <= 2097152 and line.endswith(b'\n'), 'bounded complete session line')
        location = dict(line_number=number, byte_start=offset, byte_end=offset + len(line),
                        raw_line_sha256=sha(line))
        rows.append((location, json.loads(line)))
        offset += len(line)
    return raw, rows


def tool_value(payload):
    kind = payload['type']
    names = ('type', 'call_id', 'name', 'input', 'arguments', 'status')
    if kind.endswith('_output'):
        value = payload['output']
        require(type(value) is list and len(value) <= 32, 'tool output text-block bound')
        require(all(type(item) is dict and set(item) == {'type', 'text'}
                    and item['type'] == 'input_text' and type(item['text']) is str
                    for item in value), 'plain tool result blocks required')
        return {key: payload[key] for key in ('type', 'call_id', 'output')}
    return {key: payload[key] for key in names if key in payload}


def metadata(rows):
    meta, contexts, lifecycle, usage = [], [], [], []
    for location, obj in rows:
        kind, payload = obj['type'], obj.get('payload', {})
        item = dict(timestamp=obj.get('timestamp'), source=location)
        if kind == 'session_meta':
            item['value'] = {key: payload[key] for key in ('id', 'session_id', 'timestamp', 'cli_version')}
            meta.append(item)
        elif kind == 'turn_context':
            item['value'] = {key: payload[key] for key in ('model', 'effort')}
            contexts.append(item)
        elif kind == 'event_msg' and payload.get('type') in ('task_started', 'task_complete'):
            keys = ('type', 'started_at', 'completed_at', 'duration_ms', 'time_to_first_token_ms')
            item['value'] = {key: payload[key] for key in keys if key in payload}
            lifecycle.append(item)
        elif kind == 'token_usage_record':
            item['value'] = {key: tokens(payload[key])
                             for key in ('usage', 'thread_token_usage', 'turn_token_usage')}
            usage.append(item)
        elif kind == 'event_msg' and payload.get('type') == 'token_count' and payload.get('info'):
            info = payload['info']
            item['value'] = {key: tokens(info[key]) for key in ('total_token_usage', 'last_token_usage')}
            item['value']['model_context_window'] = info.get('model_context_window')
            usage.append(item)
    require(len(meta) == 1 and contexts and lifecycle[-1]['value']['type'] == 'task_complete',
            'terminal session metadata required')
    return dict(session=meta[0], turn_contexts=contexts, lifecycle=lifecycle, host_usage=usage)


def export_log(arm, filename):
    path = SESSIONS / filename
    raw, rows = log_rows(path)
    exports, sizes, requests, finals = [], [], [], []
    for location, obj in rows:
        payload = obj.get('payload', {})
        if obj['type'] != 'response_item':
            continue
        kind = payload.get('type')
        if kind in ('custom_tool_call', 'custom_tool_call_output', 'function_call', 'function_call_output'):
            value = tool_value(payload)
            exports.append(dict(timestamp=obj.get('timestamp'), source=location, payload=value))
            if kind.endswith('_output'):
                sizes.append(dict(call_id=value['call_id'], raw_record_bytes=location['byte_end'] - location['byte_start'],
                    text_blocks=[dict(bytes=len(item['text'].encode()), sha256=sha(item['text'].encode()))
                                 for item in value['output']]))
            else:
                text = value.get('input', value.get('arguments', ''))
                requests.append(dict(call_id=value['call_id'], name=value['name'],
                    nested_max_output_tokens=[int(item) for item in re.findall(r'max_output_tokens\s*:\s*(\d+)', text)],
                    explicit_exec_directive=text.lstrip().startswith('// @exec:')))
        elif kind == 'message' and payload.get('role') == 'assistant' and payload.get('phase') == 'final_answer':
            content = payload['content']
            require(len(content) <= 8 and all(item['type'] == 'output_text' for item in content), 'plain final text')
            finals.append(dict(timestamp=obj.get('timestamp'), source=location,
                               text='\n'.join(item['text'] for item in content)))
    export = save(arm + '-selected-tools.jsonl', b''.join(canonical(item) + b'\n' for item in exports))
    value = dict(schema='transport/selected-first-trial-session/1', source_snapshot=pin(path, raw),
        selected_tool_records=export, tool_requests=requests, tool_output_sizes=sizes,
        final_messages=finals, **metadata(rows),
        usage_scope='Host cumulative/turn usage as reported; includes instructions and repeated context. Not document tokens or billed cost.',
        billed_cost=dict(status='UNKNOWN_NOT_REPORTED', value=None),
        omissions='All instructions, reasoning, world state, account/rate-limit metadata and private message metadata omitted.')
    record(arm + '-metadata.json', value)
    require(read_regular(path, 4194304) == raw, 'session snapshot changed')
    return value, exports


def verify_pin(item):
    actual = pin(Path(item['path']))
    require(actual == item, 'held file pin differs: ' + item['path'])
    return actual


def freeze_chain():
    freeze = json.loads(read_regular(CASE / 'input-freeze.json'))
    checked = []
    for name in ('fixture', 'criteria', 'plan', 'task'):
        checked.append(verify_pin(freeze[name]))
    require(len(freeze['sources']) == 6 and len(freeze['preparation_sources']) == 5, 'freeze record counts')
    for item in (*freeze['sources'].values(), *freeze['preparation_sources'].values()):
        checked.append(verify_pin(item))
    require(bundle_snapshot(Path(freeze['bundle']['path'])) == freeze['bundle'], 'sender bundle differs')
    fixture = json.loads(read_regular(CASE / 'fixture.json'))
    sources = {item['id']: item['text'].encode() for item in fixture['sources']}
    require(sources == {name: read_regular(Path(item['path']))
                        for name, item in freeze['sources'].items()}, 'frozen source bytes differ')
    require(read_regular(CASE / 'task.txt') == fixture['task'].encode(), 'frozen task differs')
    return dict(status='EXACT_FROZEN_INPUT_AND_BUNDLE_PINS_MATCH', receipt=pin(CASE / 'input-freeze.json'),
                checked_files=checked, bundle_snapshot_sha256=sha(canonical(freeze['bundle']))), sources


def receiver_files(arm, sources):
    root = CASE / ('receiver-' + arm)
    prepared = json.loads(read_regular(CASE / 'preparation.json'))['receivers'][arm]
    for name in ('manifest', 'binding', 'interface', 'task'):
        verify_pin(prepared[name])
    manifest_raw = read_regular(root / 'manifest.json')
    manifest = json.loads(manifest_raw)
    inputs.source_metadata(manifest)
    helpers = manifest['helpers']
    require(len(helpers) <= 8, 'reader helper count bound')
    require({Path(item['path']).name for item in helpers} == set(inputs.BOOTSTRAP) |
            ({'test_portable_handoff.py'} if arm == 'transport' else set()), 'helper closure differs')
    for item in helpers:
        require(Path(item['path']).parent == root / 'helpers', 'helper path outside receiver')
        verify_pin(item)
    binding = json.loads(read_regular(root / 'client-binding.json'))
    for name in ('manifest', 'reader', 'client', 'python'):
        verify_pin(binding[name])
    require(binding['manifest'] == prepared['manifest'] and binding['python'] == manifest['python'],
            'binding manifest/Python mismatch')
    inputs.checked_file(Path(manifest['python']['path']), manifest['python'])
    _, data = inputs.frozen_content(manifest)
    require(read_regular(root / 'task.txt') == read_regular(CASE / 'task.txt'), 'receiver task differs')
    if arm == 'original':
        require(inputs.original_sources(manifest, data) == sources, 'original content differs')
    else:
        require(data == {'share.txt': read_regular(CASE / 'encoded/share.txt'),
                         'meaning.zip': read_regular(CASE / 'encoded/meaning.zip')}, 'transport content differs')
        snapshot = bundle_snapshot(Path(manifest['bundle']['path']))
        require(sha(canonical(snapshot)) == manifest['bundle']['snapshot_sha256'], 'copied bundle differs')
    return root, manifest_raw, helpers


def reader_chain(arm, sources):
    root, manifest_raw, helpers = receiver_files(arm, sources)
    directory = root / 'sessions/recipient'
    files = session.members(directory)
    expected = sha(manifest_raw)
    require(files['identity.json'] == canonical(session.identity(root / 'manifest.json', expected)),
            'reader session identity differs')
    allowed, previous, calls, finished = {'identity.json', 'lock'}, sha(files['identity.json']), [], False
    for number in range(1, 33):
        name = 'call-%02d.json' % number
        if name not in files:
            break
        require(not finished, 'call after finished candidate')
        item = session.checked_log(files[name], number, previous, expected)
        for kind in ('request', 'response'):
            key = '%s-%02d.json' % (kind, number)
            require(inputs.record(files[key]) == item[kind], 'reader stream pin differs')
            allowed.add(key)
        response = json.loads(files['response-%02d.json' % number])
        require(response['call'] == number and response['action'] == item['action']
                and response['status'] == item['status'], 'reader call metadata differs')
        finished = item['action'] in ('finish', 'finish_evidence') and item['status'] == 'OK'
        require((item['candidate'] is not None) == finished, 'reader candidate state differs')
        if finished:
            require(inputs.record(files['candidate.json']) == item['candidate'], 'saved candidate pin differs')
            request = json.loads(files['request-%02d.json' % number])
            require(base64.b64decode(request['candidate_base64'], validate=True) == files['candidate.json'],
                    'submitted and saved candidate bytes differ')
            allowed.add('candidate.json')
        calls.append(item)
        allowed.add(name)
        previous = sha(files[name])
    require(set(files) == allowed and len(calls) == 9, 'reader file closure/call count differs')
    require(finished == (arm == 'original'), 'first-trial terminal result differs')
    require(calls[-1]['action'] == ('finish' if arm == 'original' else 'focus'), 'terminal action differs')
    candidate = pin(directory / 'candidate.json') if finished else None
    return dict(status='EXACT_HASH_LINKED_READER_CHAIN_CHECKED', calls=calls, terminal_hash=previous,
                candidate=candidate, finished=finished, helpers=helpers,
                session_identity=pin(directory / 'identity.json'), manifest=pin(root / 'manifest.json'))


def truncation(exports):
    selected = [item for item in exports if item['payload'].get('call_id') ==
                'call_a1bf7b213c5d4f33ae6e4cd2c79d43a3']
    require(len(selected) == 2, 'focus host call/output pairing differs')
    call, output = selected[0]['payload'], selected[1]['payload']
    text = output['output'][1]['text']
    complete = read_regular(CASE / 'receiver-transport/sessions/recipient/response-09.json', 131072)
    value = json.loads(complete)
    require(value['status'] == 'OK' and value['call'] == 9 and value['action'] == 'focus', 'focus reader response')
    artifact = save('transport-complete-focus-response-09.json', complete)
    warnings = [list(item) for item in re.findall(
        r'original token count: (\d+)|([0-9]+) tokens truncated', text)]
    return dict(status='LOSING_TRIAL_RETAINED_NO_CANDIDATE', complete_reader_response=artifact,
        reader_response_bytes=len(complete), host_focus_output_text_bytes=len(text.encode()),
        nested_command_max_output_tokens=re.findall(r'max_output_tokens\s*:\s*(\d+)', call['input']),
        outer_exec_explicit_directive=call['input'].lstrip().startswith('// @exec:'),
        wrapper_reported_token_markers=warnings, observed_host_truncation='Warning: truncated output' in text,
        documented_outer_exec_default_max_output_tokens=10000,
        diagnosis='Complete reader result survived; the receiving host tool presentation is truncated. The enclosing exec has no explicit output directive while nested exec_command requests 30000 tokens. Outer default-cap truncation is the supported explanation; exact internal effective enforcement is not independently logged.',
        boundary='Reader status OK does not mean the model received all bytes. No retry/resume or synthesized transport candidate.')


def tokenizer_status():
    available = {name: importlib.util.find_spec(name) is not None
                 for name in ('tiktoken', 'tokenizers', 'transformers')}
    return dict(installed_libraries=available, model='gpt-6.1-sol',
        model_text_tokens='UNKNOWN_NO_LOCAL_MODEL_TOKENIZER_MAPPING',
        mapping='No installed tiktoken; no tokenizer.json discovered in local Hugging Face hub. Installed generic tokenizer libraries do not establish a GPT-6.1 model encoding.',
        network='NONE', installations='NONE', billed_tokens='UNKNOWN')


def main():
    resume = sys.argv[1:] == ['--resume-verified-partial']
    require(OUT.name == 'trace-01' and (len(list(OUT.iterdir())) == 1 or
            (resume and not (OUT / 'receipt.json').exists())), 'new or verified partial export required')
    for node in ast.walk(ast.parse(read_regular(Path(__file__)))):
        if isinstance(node, ast.FunctionDef):
            require(node.end_lineno - node.lineno + 1 <= 60, 'extractor function size bound')
    freeze, sources = freeze_chain()
    runs, exports = {}, {}
    for arm, filename in LOGS.items():
        runs[arm], exports[arm] = export_log(arm, filename)
    readers = {arm: reader_chain(arm, sources) for arm in LOGS}
    require(readers['original']['candidate']['sha256'] ==
            '90bb09253e1d6a83433c125ca148e19bdfc792cf93cb433f3afcca55cebaa130', 'original candidate differs')
    original = read_regular(CASE / 'receiver-original/sessions/recipient/candidate.json', 32768)
    save('original-exact-first-candidate.json', original)
    record('reader-and-freeze-verification.json', dict(freeze=freeze, readers=readers,
        helper_trust='Read-only local helper checks; no native/decoder reexecution. Host and imported helpers assumed.',
        historical_authentication='NOT_ESTABLISHED', source_fidelity='PENDING_SEPARATE_REVIEW'))
    record('truncation-diagnosis.json', truncation(exports['transport']))
    record('token-measurement-boundary.json', dict(tokenizer=tokenizer_status(),
        document_bytes={name:len(raw) for name,raw in sources.items()}, task_bytes=len(read_regular(CASE/'task.txt')),
        usage='Raw reported host cumulative/turn counts are in per-arm metadata, not attributed document tokens. Billed cost UNKNOWN.',
        ratios='NOT_DERIVED', timing='Host reported timestamps/durations retained; no elapsed-time arithmetic.'))
    members = list(OUT.iterdir())
    receipt = record('receipt.json', dict(schema='transport/selected-heldout-first-trial-export/1',
        status='EXPORTED_SCOPED_LOSING_RESULT_RETAINED', inventory=[pin(path) for path in sorted(members)],
        bound_bytes=1048576, omitted='Instructions, reasoning and all account/rate-limit metadata.',
        no_resume=True, no_product_edits=True, no_model_dispatch=True,
        limitation='Local integrity and observed task/tool trace only; no hidden-access proof or comparative statistical conclusion.'))
    print(json.dumps(dict(status='EXPORTED_SCOPED', output=str(OUT), receipt=receipt)))


if __name__ == '__main__':
    main()
