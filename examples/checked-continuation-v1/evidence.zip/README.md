# Checked continuation evidence

This is one synthetic demonstration case, followed by a postrepair replication of the same case. The first frozen campaign failed the checked-finish custody gate in both arms and remains failed. The repaired campaign saved each first candidate byte-exactly; the deterministic evaluator reported all 480 declared states passing for each arm. Separate GPT-6.1 source reviews retained PASS for the eight reviewed obligations. These are separate protocol, finite-behavior, and source-review observations, not whole-system proof, broad superiority, independent backend attestation, or a new held-out case.

Start with MANIFEST.json, case/fixture.json, the two campaign freezes, both protocol closure receipts, assessment-01 and assessment-02, and source-review-01 and source-review-02. Candidates are in protocol-01 and protocol-02; they are retained unchanged. The first trial's refusals, failed package preparations, helper-repair evidence, negative controls, and retrospective assessments remain distinguishable.

## Recover or regenerate the matched package

The recipient supplies the exact compatible installed decoder. Its tested INSTALL.json pin is 75e1311f9e66c4aafd133d8b00e6e2029f5ae724e3750d13a4d8fb338e34da96; its RUNTIME.json pin is 2dad376ffe96800b4c2ee80971bd95ea30d43d5eacd088d83a21ffa0fdf8af90. Full file and external dependency identities are in package-01/pins-before.json and pins-after.json. The decoder binaries are deliberately not included. Independent rebuild compatibility is not claimed.

After extracting, set DECODER to that installed bundle's bin/semantic-transport. From this archive root:

```sh
"$DECODER" check
"$DECODER" validate package-01/encoded/share.txt --archive package-01/encoded/meaning.zip
"$DECODER" recover package-01/encoded/share.txt recovered-code.txt --archive package-01/encoded/meaning.zip --source CODE
cmp package-01/sources/decision.py recovered-code.txt
"$DECODER" encode package-01/authoring.json regenerated-package --budget 16384 --reference attached:meaning.zip --source CODE=package-01/sources/decision.py --source RULE=package-01/sources/RULE.txt --source BOUNDARY=package-01/sources/BOUNDARY.txt --source HISTORY=package-01/sources/HISTORY.txt --source CHECKS=package-01/sources/CHECKS.txt --source ACTIONS=package-01/sources/ACTIONS.txt
cmp package-01/encoded/share.txt regenerated-package/share.txt
cmp package-01/encoded/meaning.zip regenerated-package/meaning.zip
```

Recover the other sources using their IDs and compare against package-01/sources. Output paths must be new. Archive content and candidate Python are data; do not execute them. The coupled correction has interface and original-code context. Opaque propositions and semantic incompleteness remain explicit. The private preparation script is included for inspection and reproduction; it is not decoder authority.

## Recheck a candidate against the public repository

From the public repository root, with EVIDENCE set to the absolute extracted archive path, use the repository checker (not an imported candidate):

```sh
CANDIDATE="$EVIDENCE/protocol-02/original-candidate.json"
python -B -Werror examples/checked-continuation-v1/check_response.py --fixture "$EVIDENCE/case/fixture.json" --fixture-sha256 "$(sha256sum "$EVIDENCE/case/fixture.json" | cut -d ' ' -f1)" --contract "$EVIDENCE/case/response-contract.json" --contract-sha256 "$(sha256sum "$EVIDENCE/case/response-contract.json" | cut -d ' ' -f1)" --candidate "$CANDIDATE" --candidate-sha256 "$(sha256sum "$CANDIDATE" | cut -d ' ' -f1)"
```

Use the other candidate paths to inspect their deterministic results. The first-trial reports and custody refusals are retained even where a retrospective candidate assessment passes. Finite evaluation is not formal proof or a test of the model's general capabilities.

## Export scope and redaction

All exact sources, candidate files, matched package bytes, authoring inputs, and response contract are unchanged. In metadata and tool records only, the literal host home prefix is replaced with [HOST]/. MANIFEST.json records original and exported hashes, bytes, replacement counts, and byte offsets for concatenated JSONL members. The manifest lists all entries except itself, avoiding a circular digest. Its hash and the ZIP hash are in the repository receipt.

The four selected-tools.jsonl files contain every already-whitelisted custom exec call and output file from the bounded protocol capture folders. Each input record is independently typed and hashed; no reasoning, raw turn_context, unrelated chat, or raw source transcript was read or included. Duplicate .source.txt extracts and duplicate report.json projections are omitted deliberately because the tool records and protocol receipts already retain their selected content. Final user-facing messages are retained separately and excluded from scoring. Original authoritative trace pins remain in the local capture receipts. This is a scoped public selection, not a complete conversation or hidden-access audit.

Frozen expected prompts, task text, configs, exact observed tool records, configured/observed model metadata, and last cumulative usage observations are included. The persisted trace does not expose the initial dispatched task as plaintext: exact dispatch equality remains UNKNOWN. Usage counters are observations and are never summed across cumulative records. Same-family independent reviewers and model labels are not backend authentication. Private oracle content and decoder executables are not exported, although their reviewed identities can occur in receipts.
