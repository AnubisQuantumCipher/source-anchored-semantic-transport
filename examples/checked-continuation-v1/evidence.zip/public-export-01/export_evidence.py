#!/usr/bin/python3.14 -IS
"""Deterministic bounded public evidence export from an explicit local allowlist."""

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import resource
import sys
import zipfile

MAX_ENTRY = 1048576
MAX_EXPANDED = 4194304
MAX_ZIP = 1048576
MAX_ENTRIES = 128
HOST = b'/home/' + b'sicarii/'
REDACTED = b'[HOST]/'
CONTROL_NAMES = ('reference', 'reference-multiline', 'NEG-OVERBROAD-EXCEPTION',
    'NEG-OFF-BY-ONE', 'NEG-SWAPPED-ACTOR', 'false-approval', 'false-current-check',
    'erased-conflict', 'missing-evidence', 'missing-actions', 'altered-base',
    'unsafe-call', 'wrong-target', 'fabricated-quote', 'wrong-structure')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode() + b'\n'


def read(path):
    require(path.is_file() and not path.is_symlink(), 'regular file required: ' + path.name)
    with path.open('rb') as stream:
        raw = stream.read(MAX_ENTRY + 1)
    require(len(raw) <= MAX_ENTRY, 'input exceeds per-entry bound: ' + path.name)
    return raw


def safe_name(name):
    path = PurePosixPath(name)
    require(not path.is_absolute() and 1 <= len(path.parts) <= 8,
            'archive name depth or absolute path')
    require(all(part not in ('', '.', '..') for part in path.parts), 'unsafe archive name')
    require('\\' not in name and '\x00' not in name, 'unsafe archive name encoding')


def put(entries, mappings, name, raw, origins, policy='EXACT_BYTES'):
    safe_name(name)
    require(name not in entries and len(entries) < MAX_ENTRIES - 1, 'entry membership bound')
    require(len(raw) <= MAX_ENTRY, 'export entry exceeds bound: ' + name)
    entries[name] = raw
    mappings.append({'entry': name, 'export_bytes': len(raw), 'export_sha256': sha(raw),
                     'policy': policy, 'origins': origins})


def add_file(entries, mappings, root, relative, name=None, exact=False, root_label='evidence'):
    raw = read(root / relative)
    exported = raw if exact else raw.replace(HOST, REDACTED)
    origin = {'root': root_label, 'path': relative, 'original_bytes': len(raw),
              'original_sha256': sha(raw), 'exported_payload_bytes': len(exported),
              'exported_payload_sha256': sha(exported),
              'host_path_replacements': 0 if exact else raw.count(HOST)}
    put(entries, mappings, name or relative, exported, [origin],
        'EXACT_BYTES' if exact else 'LITERAL_HOST_PREFIX_REDACTION_ONLY')


def add_many(entries, mappings, root, names, exact=False):
    require(len(names) <= 80, 'selection-list bound')
    for name in names:
        add_file(entries, mappings, root, name, exact=exact)


def aggregate(entries, mappings, root, relatives, name, raw_events=False):
    require(1 <= len(relatives) <= 80, 'aggregate source bound')
    pieces, origins, offset = [], [], 0
    for relative in relatives:
        raw = read(root / relative)
        parsed = json.loads(raw)
        if raw_events:
            payload = parsed.get('payload', {})
            require(parsed.get('type') == 'response_item', 'non-tool raw record refused')
            require(payload.get('type') in ('custom_tool_call', 'custom_tool_call_output'),
                    'reasoning, turn context, message or unknown raw record refused')
            require(payload.get('channel') in (None, 'commentary'), 'raw reasoning channel refused')
            require(payload.get('type') != 'custom_tool_call' or payload.get('name') == 'exec',
                    'unexpected raw tool name')
        exported = raw.replace(HOST, REDACTED)
        require(len(exported.splitlines()) == 1, 'JSONL aggregation requires one-line input')
        origins.append({'root': 'evidence', 'path': relative, 'original_bytes': len(raw),
            'original_sha256': sha(raw), 'exported_payload_offset': offset,
            'exported_payload_bytes': len(exported), 'exported_payload_sha256': sha(exported),
            'host_path_replacements': raw.count(HOST)})
        pieces.append(exported if exported.endswith(b'\n') else exported + b'\n')
        offset += len(pieces[-1])
        require(offset <= MAX_ENTRY, 'aggregate exceeds per-entry byte bound')
    put(entries, mappings, name, b''.join(pieces), origins,
        'JSONL_CONCATENATION_WITH_LITERAL_HOST_PREFIX_REDACTION_ONLY')


def package_files(entries, mappings, evidence, repo):
    for name in ('fixture.json', 'response-contract.json'):
        add_file(entries, mappings, repo, 'examples/checked-continuation-v1/' + name,
                 'case/' + name, exact=True, root_label='repository')
    add_many(entries, mappings, evidence, ['package-01/' + name for name in (
        'authoring.json', 'encoded/share.txt', 'encoded/meaning.zip', 'encoded/lexicon.md',
        'encoded/plan.json', 'encoded/review.json', 'formula.txt')], exact=True)
    for name in ('decision.py', 'RULE.txt', 'BOUNDARY.txt', 'HISTORY.txt', 'CHECKS.txt', 'ACTIONS.txt'):
        add_file(entries, mappings, evidence, 'package-01/sources/' + name, exact=True)
    add_many(entries, mappings, evidence, ['package-01/' + name for name in (
        'pins-before.json', 'pins-after.json', 'receipt.json', 'preparation-note.md')])
    add_file(entries, mappings, evidence, 'fixture-author-01/prepare_package.py', exact=True)


def campaigns(entries, mappings, evidence):
    for generation in ('01', '02'):
        prefix = 'campaign-' + generation + '/'
        add_many(entries, mappings, evidence, [prefix + name for name in (
            'freeze.json', 'prepared.json', 'original-config.json', 'transport-config.json',
            'original-prompt.txt', 'transport-prompt.txt', 'task.txt')])
        for arm in ('original', 'transport'):
            protocol = 'protocol-' + generation + '/' + arm
            candidate = protocol + '-candidate.json'
            require(read(evidence / candidate) == read(evidence / (prefix + arm + '/candidate.json')),
                    'candidate capture differs from campaign candidate')
            add_file(entries, mappings, evidence, candidate, exact=True)
            add_many(entries, mappings, evidence, [protocol + suffix for suffix in (
                '-submit.stdout', '-submit.stderr', '-protocol-receipt.json',
                '-raw-receipt.json', '-launch.json', '-elapsed-jackal.json')])
            add_file(entries, mappings, evidence, 'assessment-' + generation + '/' + arm + '.json')
        add_file(entries, mappings, evidence, 'protocol-' + generation + '/closure-receipt.json')
    add_many(entries, mappings, evidence, ['protocol-01/command-grammar-receipt.json',
                                         'protocol-02/trial-relation.json'])


def raw_captures(entries, mappings, evidence):
    for generation in ('01', '02'):
        for arm in ('original', 'transport'):
            prefix = 'protocol-' + generation + '/' + arm
            receipt = json.loads(read(evidence / (prefix + '-raw-receipt.json')))
            require(receipt['no_reasoning_or_raw_turn_context_copied'] is True,
                    'raw capture no-reasoning attestation missing')
            children = list((evidence / (prefix + '-raw')).iterdir())
            require(len(children) <= 80, 'capture directory entry bound')
            selected = sorted(item.name for item in children
                              if re.fullmatch(r'line-[0-9]{6}\.jsonl', item.name))
            paths = [prefix + '-raw/' + name for name in selected]
            aggregate(entries, mappings, evidence, paths, prefix + '-selected-tools.jsonl', True)
            add_file(entries, mappings, evidence, prefix + '-raw/final-01.txt')


def reviews_controls_failures(entries, mappings, evidence):
    for generation in ('01', '02'):
        add_many(entries, mappings, evidence, ['source-review-' + generation + '/' + name
                                             for name in ('review.json', 'review.txt')])
    add_many(entries, mappings, evidence, ['preflight-review-01/final-receipt.json',
        'preflight-review-01/final-review.txt', 'expression-review-01/receipt.json',
        'submission-review-01/receipt.json', 'mechanical-replay-01/receipt.json',
        'mechanical-replay-01/original.stdout', 'mechanical-replay-01/transport.stdout',
        'submission-repair-01/receipt.json', 'submission-repair-01/inputs.json',
        'submission-repair-01/client.stderr', 'submission-repair-01/contract.stderr',
        'submission-repair-01/finish.stderr', 'patch-evaluator-01/initial-receipt.json',
        'patch-evaluator-01/receipt.json', 'patch-evaluator-01/initial.stderr'])
    for name in CONTROL_NAMES:
        add_file(entries, mappings, evidence, 'controls-03/' + name + '-candidate.json', exact=True)
    aggregate(entries, mappings, evidence,
              ['controls-03/' + name + '-assessment.json' for name in CONTROL_NAMES],
              'controls-03/assessments.jsonl')
    add_file(entries, mappings, evidence, 'controls-01/FAILURE.txt')
    add_file(entries, mappings, evidence, 'controls-01/reference-candidate.json', exact=True)
    for generation in ('02', '03'):
        add_file(entries, mappings, evidence, 'controls-' + generation + '/receipt.json')
    for generation in ('01', '02'):
        prefix = 'package-01-refused-' + generation + '/'
        add_file(entries, mappings, evidence, prefix + 'authoring.json', exact=True)
        add_many(entries, mappings, evidence, [prefix + name for name in (
            'logs/01-encode.stderr', 'pins-before.json', 'pins-after.json')])


def gate_summary(evidence):
    result = {'classification': 'ONE_SYNTHETIC_CASE_WITH_POSTREPAIR_REPLICATION', 'campaigns': {}}
    for generation in ('01', '02'):
        closure = json.loads(read(evidence / ('protocol-' + generation + '/closure-receipt.json')))
        review = json.loads(read(evidence / ('source-review-' + generation + '/review.json')))
        require(all(all(item['status'] == 'PASS' for item in candidate['obligations'])
                    for candidate in review['candidates']), 'source review gate mismatch')
        arms = {}
        for arm in ('original', 'transport'):
            assessment = json.loads(read(evidence / ('assessment-' + generation + '/' + arm + '.json')))
            protocol = json.loads(read(evidence / ('protocol-' + generation + '/' + arm + '-protocol-receipt.json')))
            arms[arm] = {'candidate_sha256': assessment['candidate_sha256'],
                'submission_status': assessment['submission_status'],
                'deterministic_status': assessment['status'], 'behavior': assessment.get('behavior'),
                'protocol_status': protocol['status'], 'observed_model_settings': protocol['observed_model_settings'],
                'usage': protocol['usage']}
        result['campaigns'][generation] = {'freeze_sha256': closure['frozen_campaign_sha256'],
            'protocol_closure_status': closure['status'], 'arms': arms,
            'source_review': [{'label': c['candidate'], 'candidate_sha256': c['input_sha256'] if generation == '01' else c['sha256'],
                 'obligations': [{'id': o['id'], 'status': o['status']} for o in c['obligations']]} for c in review['candidates']]}
    require(result['campaigns']['01']['protocol_closure_status'] ==
            'FIRST_FROZEN_RUN_RETAINED_FAILED_FINISH_CUSTODY_GATE', 'first failed trial must remain failed')
    require(result['campaigns']['02']['protocol_closure_status'] ==
            'OBSERVED_PROTOCOL_CONFORMANT_BOTH_FIRST_DRAFTS_SAVED', 'repaired custody gate mismatch')
    return result


def setup_accounting(evidence):
    prepared = json.loads(read(evidence / 'campaign-02/prepared.json'))
    snapshot = prepared['snapshot']['files']
    require(1 <= len(snapshot) <= 128, 'setup snapshot bound')
    result = {'scope': 'Declared prepared snapshot file bytes; not download cost, memory use, or latency',
        'shared_decoder_file_count': len(snapshot),
        'shared_decoder_file_bytes': sum(item['bytes'] for item in snapshot.values()),
        'shared_decoder_snapshot_sha256': prepared['source_bundle_snapshot_sha256'],
        'decoder_archive_included': False, 'arms': {}}
    for arm in prepared['arms']:
        require(len(arm['extra']) <= 64, 'helper manifest bound')
        result['arms'][arm['arm']] = {'declared_extra_file_bytes': sum(x['bytes'] for x in arm['extra']),
            'declared_extra_file_count': len(arm['extra']),
            'note': 'Per-arm helper copies; do not sum these as independent shared dependencies'}
    return result


def readme():
    return b'''# Checked continuation evidence

This is one synthetic demonstration case, followed by a postrepair replication of the same case. The first frozen campaign failed the checked-finish custody gate in both arms and remains failed. The repaired campaign saved each first candidate byte-exactly; the deterministic evaluator reported all 480 declared states passing for each arm. Separate GPT-6.1 source reviews retained PASS for the eight reviewed obligations. These are separate protocol, finite-behavior, and source-review observations, not whole-system proof, broad superiority, independent backend attestation, or a new held-out case.

Start with MANIFEST.json, case/fixture.json, the two campaign freezes, both protocol closure receipts, assessment-01 and assessment-02, and source-review-01 and source-review-02. Candidates are in protocol-01 and protocol-02; they are retained unchanged. The first trial's refusals, failed package preparations, helper-repair evidence, negative controls, and retrospective assessments remain distinguishable.

## Recover or regenerate the matched package

The recipient supplies the exact compatible installed decoder. Its tested INSTALL.json pin is 75e1311f9e66c4aafd133d8b00e6e2029f5ae724e3750d13a4d8fb338e34da96; its RUNTIME.json pin is 2dad376ffe96800b4c2ee80971bd95ea30d43d5eacd088d83a21ffa0fdf8af90. Full file and external dependency identities are in package-01/pins-before.json and pins-after.json. The decoder binaries are deliberately not included. Independent rebuild compatibility is not claimed.

After extracting, set DECODER to that installed bundle's bin/semantic-transport. From this archive root:

```sh
"$DECODER" check
"$DECODER" validate package-01/encoded/share.txt --archive package-01/encoded/meaning.zip
"$DECODER" recover package-01/encoded/share.txt recovered-code.txt --archive package-01/encoded/meaning.zip --source CODE
cmp package-01/sources/decision.py recovered-code.txt
"$DECODER" encode package-01/authoring.json regenerated-package --budget 16384 --reference attached:meaning.zip --source CODE=package-01/sources/decision.py --source RULE=package-01/sources/RULE.txt --source BOUNDARY=package-01/sources/BOUNDARY.txt --source HISTORY=package-01/sources/HISTORY.txt --source CHECKS=package-01/sources/CHECKS.txt --source ACTIONS=package-01/sources/ACTIONS.txt
cmp package-01/encoded/share.txt regenerated-package/share.txt
cmp package-01/encoded/meaning.zip regenerated-package/meaning.zip
```

Recover the other sources using their IDs and compare against package-01/sources. Output paths must be new. Archive content and candidate Python are data; do not execute them. The coupled correction has interface and original-code context. Opaque propositions and semantic incompleteness remain explicit. The private preparation script is included for inspection and reproduction; it is not decoder authority.

## Recheck a candidate against the public repository

From the public repository root, with EVIDENCE set to the absolute extracted archive path, use the repository checker (not an imported candidate):

```sh
CANDIDATE="$EVIDENCE/protocol-02/original-candidate.json"
python -B -Werror examples/checked-continuation-v1/check_response.py --fixture "$EVIDENCE/case/fixture.json" --fixture-sha256 "$(sha256sum "$EVIDENCE/case/fixture.json" | cut -d ' ' -f1)" --contract "$EVIDENCE/case/response-contract.json" --contract-sha256 "$(sha256sum "$EVIDENCE/case/response-contract.json" | cut -d ' ' -f1)" --candidate "$CANDIDATE" --candidate-sha256 "$(sha256sum "$CANDIDATE" | cut -d ' ' -f1)"
```

Use the other candidate paths to inspect their deterministic results. The first-trial reports and custody refusals are retained even where a retrospective candidate assessment passes. Finite evaluation is not formal proof or a test of the model's general capabilities.

## Export scope and redaction

All exact sources, candidate files, matched package bytes, authoring inputs, and response contract are unchanged. In metadata and tool records only, the literal host home prefix is replaced with [HOST]/. MANIFEST.json records original and exported hashes, bytes, replacement counts, and byte offsets for concatenated JSONL members. The manifest lists all entries except itself, avoiding a circular digest. Its hash and the ZIP hash are in the repository receipt.

The four selected-tools.jsonl files contain every already-whitelisted custom exec call and output file from the bounded protocol capture folders. Each input record is independently typed and hashed; no reasoning, raw turn_context, unrelated chat, or raw source transcript was read or included. Duplicate .source.txt extracts and duplicate report.json projections are omitted deliberately because the tool records and protocol receipts already retain their selected content. Final user-facing messages are retained separately and excluded from scoring. Original authoritative trace pins remain in the local capture receipts. This is a scoped public selection, not a complete conversation or hidden-access audit.

Frozen expected prompts, task text, configs, exact observed tool records, configured/observed model metadata, and last cumulative usage observations are included. The persisted trace does not expose the initial dispatched task as plaintext: exact dispatch equality remains UNKNOWN. Usage counters are observations and are never summed across cumulative records. Same-family independent reviewers and model labels are not backend authentication. Private oracle content and decoder executables are not exported, although their reviewed identities can occur in receipts.
'''


def make_zip(entries):
    require(len(entries) <= MAX_ENTRIES, 'archive entry count exceeded')
    require(sum(map(len, entries.values())) <= MAX_EXPANDED, 'expanded archive byte bound exceeded')
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(entries):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, entries[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    data = stream.getvalue()
    require(len(data) <= MAX_ZIP, 'ZIP output byte bound exceeded')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        require(archive.namelist() == sorted(entries), 'archive member readback mismatch')
        for name in sorted(entries):
            require(archive.read(name) == entries[name], 'archive payload readback mismatch')
    return data


def write_new(path, raw):
    require(len(raw) <= MAX_ENTRY, 'publication file bound exceeded')
    with path.open('xb') as stream:
        require(stream.write(raw) == len(raw), 'short publication write')
    require(read(path) == raw, 'publication readback mismatch')


def build(args):
    entries, mappings = {}, []
    package_files(entries, mappings, args.evidence, args.repo)
    campaigns(entries, mappings, args.evidence)
    raw_captures(entries, mappings, args.evidence)
    reviews_controls_failures(entries, mappings, args.evidence)
    put(entries, mappings, 'README.md', readme(), [], 'GENERATED_EXPORT_GUIDE')
    add_file(entries, mappings, args.evidence, 'public-export-01/export_evidence.py', exact=True)
    gates, setup = gate_summary(args.evidence), setup_accounting(args.evidence)
    manifest = {'schema': 'transport/checked-continuation-public-export/1',
        'entries_exclude_manifest': True, 'entries': sorted(mappings, key=lambda x: x['entry']),
        'gates': gates, 'setup_byte_accounting': setup,
        'redaction': {'scope': 'METADATA_AND_SELECTED_TOOL_RECORDS_ONLY',
            'replacement': '[HOST]/', 'protected': 'Source/candidate/package/authoring/contract bytes unchanged'},
        'capture_scope': 'Existing whitelisted tool calls and outputs only; no reasoning or raw turn context',
        'semantic_completeness': 'UNPROVEN', 'execution_authority': 'NONE'}
    entries['MANIFEST.json'] = encode(manifest)
    require(len(entries['MANIFEST.json']) <= MAX_ENTRY, 'manifest bound exceeded')
    data = make_zip(entries)
    require(data == make_zip(entries), 'deterministic second construction differs')
    receipt = {'schema': 'transport/checked-continuation-public-receipt/1',
        'status': 'LOCAL_PUBLIC_EXPORT_VERIFIED', 'artifact': 'examples/checked-continuation-v1/evidence.zip',
        'archive_sha256': sha(data), 'archive_bytes': len(data),
        'manifest_sha256': sha(entries['MANIFEST.json']), 'entry_count': len(entries),
        'expanded_bytes': sum(map(len, entries.values())), 'largest_entry_bytes': max(map(len, entries.values())),
        'bounds': {'entries': MAX_ENTRIES, 'entry_bytes': MAX_ENTRY, 'expanded_bytes': MAX_EXPANDED, 'archive_bytes': MAX_ZIP},
        'deterministic_construction_checked': True, 'all_entry_readbacks_equal': True,
        'gates': gates, 'setup_byte_accounting': setup,
        'package_sizes': json.loads(read(args.evidence / 'package-01/receipt.json'))['sizes'],
        'redaction_scope': manifest['redaction'], 'source_candidate_package_bytes_changed': False,
        'proof': 'NOT_CLAIMED', 'semantic_completeness': 'UNPROVEN', 'decoder_execution_authority': 'NONE',
        'limitations': ['One synthetic case; repaired replication is not a new held-out case.',
            'Initial plaintext dispatch equality UNKNOWN; model backend identity not attested.',
            'Selected public captures are not a complete conversation or hidden-access audit.',
            'Decoder dependency supplied by recipient; independent rebuild compatibility not claimed.',
            'No whole-system proof, broad superiority, confidential-data guarantee, or production acceptance.']}
    write_new(args.archive, data)
    write_new(args.receipt, encode(receipt))
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('evidence', 'repo', 'archive', 'receipt'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    require(all(getattr(args, name).is_absolute() for name in ('evidence', 'repo', 'archive', 'receipt')),
            'absolute local input/output arguments required')
    receipt = build(args)
    print(json.dumps({key: receipt[key] for key in ('status', 'archive_sha256', 'archive_bytes',
                                                  'entry_count', 'expanded_bytes', 'largest_entry_bytes')}))
    return 0


if __name__ == '__main__':
    resource.setrlimit(resource.RLIMIT_AS, (268435456, 268435456))
    resource.setrlimit(resource.RLIMIT_CPU, (30, 30))
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_ENTRY, MAX_ENTRY))
    resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, TypeError, MemoryError, UnicodeError,
            zipfile.BadZipFile) as error:
        print('REFUSED: ' + str(error)[:256], file=sys.stderr)
        sys.exit(1)
