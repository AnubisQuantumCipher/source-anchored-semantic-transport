#!/usr/bin/python3.14 -IS
"""Prepare one bounded synthetic package from public sources; no candidate execution."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
FIXTURE_SHA = 'bfd363b13b659b21b0c642c67e97af4eee43821ca30b75169e4e64195b4852af'
INSTALL_SHA = '75e1311f9e66c4aafd133d8b00e6e2029f5ae724e3750d13a4d8fb338e34da96'
RUNTIME_SHA = '2dad376ffe96800b4c2ee80971bd95ea30d43d5eacd088d83a21ffa0fdf8af90'
SOURCE_IDS = ('CODE', 'RULE', 'BOUNDARY', 'HISTORY', 'CHECKS', 'ACTIONS')
MAX_FILE = 131072
MAX_TOTAL = 2097152


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path, cap=MAX_FILE):
    require(not path.is_symlink() and path.is_file(), 'regular non-symlink file required')
    with path.open('rb') as stream:
        data = stream.read(cap + 1)
    require(len(data) <= cap, 'input file bound exceeded')
    return data


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(path, data):
    require(type(data) is bytes and len(data) <= MAX_FILE, 'output file bound exceeded')
    with path.open('xb') as stream:
        require(stream.write(data) == len(data), 'short output write')
    require(read(path) == data, 'output readback mismatch')


def json_write(path, value):
    data = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode() + b'\n'
    write(path, data)


def snapshot(bundle):
    raw = read(bundle / 'INSTALL.json')
    require(digest(raw) == INSTALL_SHA, 'pinned install manifest mismatch')
    manifest = json.loads(raw)
    require(1 <= len(manifest['files']) <= 128, 'manifest member bound exceeded')
    require(len(manifest['external']) == 3, 'external pin count mismatch')
    result = {'install_sha256': digest(raw), 'files': [], 'external': []}
    for item in manifest['files']:
        path = bundle / item['path']
        require(path.is_relative_to(bundle), 'member outside bundle')
        data = read(path, 4194304)
        observed = {'path': item['path'], 'bytes': len(data), 'sha256': digest(data)}
        require(observed == item, 'pinned member changed: ' + item['path'])
        result['files'].append(observed)
    for item in manifest['external']:
        data = read(Path(item['path']), 33554432)
        observed = {'path': item['path'], 'bytes': len(data), 'sha256': digest(data)}
        require(observed['bytes'] == item['bytes'] and observed['sha256'] == item['sha256'],
                'external pinned content changed')
        result['external'].append(observed)
    result['command_sha256'] = digest(read(bundle / 'bin/semantic-transport'))
    result['runtime_sha256'] = digest(read(bundle / 'RUNTIME.json'))
    require(result['runtime_sha256'] == RUNTIME_SHA, 'runtime pin mismatch')
    return result


def load_fixture(path):
    raw = read(path)
    require(digest(raw) == FIXTURE_SHA, 'reviewed public fixture bytes changed')
    fixture = json.loads(raw)
    require(fixture['schema'] == 'transport/coding-continuation-fixture/1', 'fixture schema')
    sources = fixture['sources']
    require(tuple(item['id'] for item in sources) == SOURCE_IDS, 'source order or IDs changed')
    require(sum(len(item['text'].encode()) for item in sources) < 12000, 'source byte bound')
    return sources


def selection(text, quote):
    require(type(quote) is str and quote, 'empty quote')
    index = text.find(quote)
    require(index >= 0, 'quote not found in public source: ' + quote[:64])
    return {'quote': quote, 'at': len(text[:index].encode())}


def new_graph():
    return {'schema': 'transport/encoding-plan/1', 'symbols': {},
            'meaning': {'schema': 'transport/meaning/1', 'nodes': [],
                        'root': 0, 'ambiguities': []}}


def leaf(graph, source, quote, kind='atom'):
    symbols, nodes = graph['symbols'], graph['meaning']['nodes']
    require(len(symbols) < 64 and len(nodes) < 256, 'meaning graph bound')
    name = 'S' + str(len(symbols))
    symbols[name] = quote
    nodes.append({'op': kind, 'symbol': name, 'span': selection(source, quote)})
    return len(nodes) - 1


def operator(graph, source, name, operands, cue=None):
    nodes = graph['meaning']['nodes']
    require(len(nodes) < 256 and 1 <= len(operands) <= 7, 'operator bound')
    require(all(type(index) is int and 0 <= index < len(nodes) for index in operands),
            'operator references must precede use')
    nodes.append({'op': name, 'args': operands,
                  'cue': None if cue is None else selection(source, cue)})
    return len(nodes) - 1


def conjunction(graph, source, nodes):
    require(1 <= len(nodes) <= 8, 'conjunction input bound')
    root = nodes[0]
    for node in nodes[1:]:
        root = operator(graph, source, 'and', [root, node])
    return root


def literals(source, quotes, attribution=None):
    graph = new_graph()
    require(1 <= len(quotes) <= 8, 'literal clause bound')
    nodes = [leaf(graph, source, quote) for quote in quotes]
    root = conjunction(graph, source, nodes)
    if attribution is not None:
        speaker = leaf(graph, source, attribution, 'term')
        root = operator(graph, source, 'attribution', [speaker, root])
    graph['meaning']['root'] = root
    return graph


def correction(source):
    graph = new_graph()
    subject = leaf(graph, source, 'allow_demo_route', 'term')
    predicate = leaf(graph, source, 'return True', 'text')
    outcome = operator(graph, source, 'pred', [predicate, subject])
    requester = leaf(graph, source, 'requester_is_keeper is True')
    age = leaf(graph, source, 'age_hours is between 0 and 12 inclusive')
    alternate = leaf(graph, source,
                     'either seal_ok is True or both repair_mode and ticket_ok are True')
    conditions = conjunction(graph, source, [requester, age, alternate])
    sufficient = operator(graph, source, 'if', [conditions, outcome], 'exactly when')
    necessary = operator(graph, source, 'requires', [outcome, conditions], 'exactly when')
    equivalence = operator(graph, source, 'and', [sufficient, necessary])
    obligation = operator(graph, source, 'must', [equivalence], 'must')
    scope = leaf(graph, source, 'The repair exception waives only seal_ok')
    retained = leaf(graph, source, 'it never waives the requester role or either age bound.')
    irrelevant = leaf(graph, source, 'recipient_is_keeper has no effect on the decision.')
    graph['meaning']['root'] = conjunction(graph, source,
                                           [obligation, scope, retained, irrelevant])
    graph['meaning']['ambiguities'] = [{
        'span': selection(source, 'either seal_ok is True or both repair_mode and ticket_ok are True'),
        'note': 'The existing operator dictionary has no disjunction operator. This full alternative, including the conjunctive exception, is retained as an exact opaque proposition; no equivalent invented operator or completeness claim is supplied.'}, {
        'span': selection(source, 'age_hours is between 0 and 12 inclusive'),
        'note': 'The inclusive integer range is retained verbatim. This documentary grammar does not evaluate numeric comparisons or execute the decision function.'}]
    return graph


def add_unit(document, sources, name, source_id, kind, quotes, context, graph):
    require(len(document['meaning_units']) < 16, 'meaning unit bound')
    text = sources[source_id]['text']
    anchors = [{'source': source_id, 'selection': selection(text, quote)} for quote in quotes]
    interpretation = 'I_' + name
    document['interpretations'].append({
        'id': interpretation, 'label': name,
        'text': 'Proposed documentary reading of the exact public source; not proof, current evidence, or live authority.',
        'status': 'proposed', 'provenance': 'Prepared solely from the public synthetic fixture; semantic interpretation remains UNPROVEN.',
        'anchors': anchors})
    document['meaning_units'].append({'id': 'MU_' + name, 'source': source_id,
        'interpretation': interpretation, 'kind': kind, 'context': context, 'plan': graph})


def add_history(document, sources):
    text = sources['HISTORY']['text']
    blocks = text.split('\n\n')
    require(len(blocks) == 4, 'historical source paragraph count changed')
    approval = 'Publication of the demonstration package is approved after the draft-r1 fix.'
    revoked = 'HAPP-01 is revoked because the reported checks conflict. Do not rely on that approval for publication.'
    graph = literals(text, [approval], '2026-10-20, HAPP-01, fictional Demo Desk')
    add_unit(document, sources, 'APPROVAL', 'HISTORY', 'historical_approval',
             [blocks[0], blocks[1]], ['MU_CODE'], graph)
    graph = literals(text, [revoked], '2026-10-21, HREV-01, fictional Demo Desk')
    add_unit(document, sources, 'REVOCATION', 'HISTORY', 'revocation',
             [blocks[0], blocks[2]], ['MU_APPROVAL'], graph)
    graph = literals(text, [blocks[3]])
    add_unit(document, sources, 'AUTHORITY', 'HISTORY', 'source_claim',
             [blocks[3]], ['MU_REVOCATION'], graph)


def add_reports(document, sources):
    text = sources['CHECKS']['text']
    blocks = text.split('\n\n')
    require(len(blocks) == 4, 'reports source paragraph count changed')
    for name, block, speaker in [('REPORT_A', blocks[1], 'TR-A, dated 2026-10-20'),
                                 ('REPORT_B', blocks[2], 'TR-B, dated 2026-10-21')]:
        quote = block.split('"')[1]
        graph = literals(text, [quote], speaker)
        add_unit(document, sources, name, 'CHECKS', 'source_claim',
                 [blocks[0], block], ['MU_CODE', 'MU_INTERFACE'], graph)
    graph = literals(text, [blocks[3]])
    add_unit(document, sources, 'EVIDENCE', 'CHECKS', 'source_claim',
             [blocks[3]], ['MU_REPORT_A', 'MU_REPORT_B', 'MU_CORRECTION'], graph)


def add_actions(document, sources):
    text = sources['ACTIONS']['text']
    lines = text.splitlines()
    completed = [line for line in lines if line.startswith(('ACT-01 ', 'ACT-02 '))]
    pending = [line for line in lines if line.startswith(('ACT-03 ', 'ACT-04 ', 'ACT-05 '))]
    require(len(completed) == 2 and len(pending) == 3, 'action source IDs changed')
    prefix = text.split('\n\n')[0]
    graph = literals(text, completed, 'This ledger')
    add_unit(document, sources, 'COMPLETED', 'ACTIONS', 'source_claim',
             [prefix, *completed], ['MU_CODE', 'MU_CORRECTION', 'MU_REVOCATION'], graph)
    graph = literals(text, pending, 'This ledger')
    add_unit(document, sources, 'PENDING', 'ACTIONS', 'pending_action',
             [prefix, *pending, text.split('\n\n')[-1]],
             ['MU_COMPLETED', 'MU_CORRECTION', 'MU_EVIDENCE', 'MU_AUTHORITY'], graph)


def add_qualifications(document, sources):
    checks = sources['CHECKS']['text']
    history = sources['HISTORY']['text']
    selected = [{'source': 'CHECKS', 'selection': selection(checks, checks.split('\n\n')[-1])}]
    document['uncertainties'].append({'id': 'U_HISTORICAL_REPORTS',
        'text': 'Historical test reports conflict and lack provenance receipts; current replacement verification is UNKNOWN. No source interpretation here resolves that gap.',
        'anchors': selected, 'affects': ['I_REPORT_A', 'I_REPORT_B', 'I_EVIDENCE', 'MU_EVIDENCE']})
    document['relations'].extend([
        {'kind': 'supersedes', 'from': 'I_REVOCATION', 'to': 'I_APPROVAL',
         'note': 'HREV-01 withdraws HAPP-01 within the synthetic history; this is not an authorization mechanism.',
         'anchors': [{'source': 'HISTORY', 'selection': selection(history, history.split('\n\n')[2])}]},
        {'kind': 'contradicts', 'from': 'I_REPORT_B', 'to': 'I_REPORT_A',
         'note': 'The source declares incompatible claims for the same draft-r1 threshold case; neither is current corrected-code evidence.', 'anchors': selected},
        {'kind': 'qualifies', 'from': 'I_EVIDENCE', 'to': 'I_CORRECTION',
         'note': 'Current evaluation and independent review of a proposed replacement are missing.', 'anchors': selected},
        {'kind': 'supersedes', 'from': 'I_CORRECTION', 'to': 'I_CODE',
         'note': 'The source correction supersedes draft behavior without executing or accepting a replacement.',
         'anchors': [{'source': 'RULE', 'selection': selection(sources['RULE']['text'], sources['RULE']['text'].split('\n\n')[0])}]}])


def compact_units(document, sources):
    """Retain all distinct declarations; type only the coupled coding context."""
    document['meaning_units'] = document['meaning_units'][:3]
    history = sources['HISTORY']['text']
    document['uncertainties'][0]['affects'].pop()
    document['relations'].append({
        'kind': 'qualifies', 'from': 'I_AUTHORITY', 'to': 'I_APPROVAL',
        'note': 'Historical approval is revoked; no current publication authorization is supplied and decoder execution authority remains NONE.',
        'anchors': [{'source': 'HISTORY', 'selection': selection(history, history.split('\n\n')[-1])}]})


def authoring(records):
    sources = {item['id']: item for item in records}
    document = {'schema': 'transport/authoring/1', 'sources': [],
                'interpretations': [], 'uncertainties': [], 'relations': [], 'meaning_units': []}
    for item in records:
        document['sources'].append({key: item[key] for key in ('id', 'label', 'media_type', 'provenance')}
                                  | {'sha256': digest(item['text'].encode())})
    interface = sources['BOUNDARY']['text']
    add_unit(document, sources, 'INTERFACE', 'BOUNDARY', 'source_claim', [interface], [],
             literals(interface, interface.split('\n\n')))
    code = sources['CODE']['text']
    add_unit(document, sources, 'CODE', 'CODE', 'source_claim', [code], ['MU_INTERFACE'],
             literals(code, [code]))
    rule = sources['RULE']['text']
    add_unit(document, sources, 'CORRECTION', 'RULE', 'instruction', [rule],
             ['MU_INTERFACE', 'MU_CODE'], correction(rule))
    add_history(document, sources)
    add_reports(document, sources)
    add_actions(document, sources)
    add_qualifications(document, sources)
    compact_units(document, sources)
    return document


def run_cli(command, args, output, label):
    argv = [str(command), *args]
    stdout = output / 'logs' / (label + '.stdout')
    stderr = output / 'logs' / (label + '.stderr')
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                timeout=60, check=False, env={'PATH': '/usr/bin:/bin',
                                'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8'})
    receipt = {'argv': argv, 'exit_code': result.returncode,
               'stdout_sha256': digest(read(stdout)), 'stderr_sha256': digest(read(stderr))}
    json_write(output / 'logs' / (label + '.json'), receipt)
    require(result.returncode == 0, 'CLI refused; retained logs: ' + label)


def materialize(output, records):
    for name in ('sources', 'recovered', 'logs'):
        (output / name).mkdir(mode=0o700)
    paths = {}
    for item in records:
        filename = 'decision.py' if item['id'] == 'CODE' else item['id'] + '.txt'
        path = output / 'sources' / filename
        write(path, item['text'].encode())
        paths[item['id']] = path
    json_write(output / 'authoring.json', authoring(records))
    json_write(output / 'discovery-error.json', {
        'status': 'RETAINED_DISCOVERY_ERROR', 'command': 'semantic-transport --help',
        'exit_code': 127, 'stderr': '/bin/bash: line 3: semantic-transport: command not found',
        'resolution': 'Use the explicit existing pinned bundle command; no bundle mutation or fallback implementation.'})
    return paths


def encode_and_recover(bundle, output, paths):
    command = bundle / 'bin/semantic-transport'
    run_cli(command, ['check'], output, '00-check')
    args = ['encode', str(output / 'authoring.json'), str(output / 'encoded'),
            '--budget', '16384', '--reference', 'attached:meaning.zip']
    for name in SOURCE_IDS:
        args.extend(['--source', name + '=' + str(paths[name])])
    run_cli(command, args, output, '01-encode')
    share, archive = output / 'encoded/share.txt', output / 'encoded/meaning.zip'
    for action in ('validate', 'inspect'):
        run_cli(command, [action, str(share), '--archive', str(archive)], output, action)
    for name in SOURCE_IDS:
        destination = output / 'recovered' / paths[name].name
        run_cli(command, ['recover', str(share), str(destination), '--archive', str(archive),
                         '--source', name], output, 'recover-' + name)
        require(read(paths[name]) == read(destination), 'exact source recovery mismatch: ' + name)
    run_cli(command, ['focus', str(share), '--archive', str(archive), '--unit', 'MU_CORRECTION'],
            output, 'focus-correction')


def results(output, records, before, after):
    require(before == after, 'pinned bundle or external content changed')
    encoded = output / 'encoded'
    with zipfile.ZipFile(encoded / 'meaning.zip') as archive:
        entries = archive.infolist()
        require(len(entries) <= 64, 'archive entry count bound')
        require(sum(item.file_size for item in entries) <= MAX_TOTAL, 'archive expanded bound')
        formula = archive.read('formula.txt')
    write(output / 'formula.txt', formula)
    sizes = {'source_utf8_bytes': sum(len(item['text'].encode()) for item in records),
             'readable_formula_utf8_bytes': len(formula),
             'share_utf8_bytes': len(read(encoded / 'share.txt')),
             'share_unicode_codepoints': len(read(encoded / 'share.txt').decode()),
             'lexicon_utf8_bytes': len(read(encoded / 'lexicon.md')),
             'zip_bytes': len(read(encoded / 'meaning.zip'))}
    return {'status': 'MATCHED_PACKAGE_VALIDATED_AND_EXACT_SOURCES_RECOVERED',
            'fixture_sha256': FIXTURE_SHA, 'pins_unchanged': True, 'sizes': sizes,
            'source_comparisons': [{'id': item['id'], 'equal': True,
                 'sha256': digest(item['text'].encode())} for item in records],
            'decoder_path': 'Installed validate, inspect, recover, and focus CLI commands',
            'semantic_completeness': 'UNPROVEN', 'interpretation_entailment': 'UNPROVEN',
            'execution_authority': 'NONE', 'candidate_code_executed': False,
            'receiver_or_model_run': False, 'frozen': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('fixture', 'bundle', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    require(args.fixture.is_absolute() and args.bundle.is_absolute() and args.output.is_absolute(),
            'absolute paths required')
    args.output.mkdir(mode=0o700)
    before = snapshot(args.bundle)
    json_write(args.output / 'pins-before.json', before)
    records = load_fixture(args.fixture)
    paths = materialize(args.output, records)
    try:
        encode_and_recover(args.bundle, args.output, paths)
    finally:
        json_write(args.output / 'pins-after.json', snapshot(args.bundle))
    after = json.loads(read(args.output / 'pins-after.json'))
    receipt = results(args.output, records, before, after)
    require(digest(read(args.fixture)) == FIXTURE_SHA, 'public fixture changed during preparation')
    receipt['preparation_script_sha256'] = digest(read(Path(__file__).resolve()))
    json_write(args.output / 'receipt.json', receipt)
    print(json.dumps(receipt, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    resource.setrlimit(resource.RLIMIT_AS, (268435456, 268435456))
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_FILE, MAX_FILE))
    resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
    try:
        sys.exit(main())
    except (ValueError, OSError, KeyError, TypeError, UnicodeError, MemoryError,
            subprocess.TimeoutExpired, zipfile.BadZipFile) as error:
        print('REFUSED: ' + str(error)[:256], file=sys.stderr)
        sys.exit(1)
