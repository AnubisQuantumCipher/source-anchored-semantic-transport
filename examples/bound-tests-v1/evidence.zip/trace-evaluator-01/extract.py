"""Bounded source-evaluator identity evidence, separate from the sealed recipient export."""
import ast
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).absolute().parent
LOG = Path('/home/sicarii/.codex/sessions/2026/10/28/rollout-2026-10-28T21-33-20-01a1854a-4822-7f42-aef2-7369207da2c6.jsonl')
ROOT_LOG = Path('/home/sicarii/.codex/sessions/2026/10/25/rollout-2026-10-25T20-34-20-01a175a1-2f57-7d91-a157-7e4375dcf7b0.jsonl')
EVALUATION = OUT.parent / 'evaluation-01/receipt.json'
HELD_EVALUATION = 'be5cb8175f6df65b9efd09608dfbab818230b6db7d5861b7a8d3d723c3d521f2'
TASK = 'finite_workflow_source_evaluator'
FORBIDDEN = (b'base_instructions', b'user_instructions', b'encrypted_content', b'creator_id', b'creatorId')


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()


def read(path, cap=4194304):
    require(path.is_file() and not path.is_symlink(), 'regular nonsymlink input required')
    with path.open('rb') as stream:
        raw = stream.read(cap + 1)
    require(len(raw) <= cap, 'input byte bound')
    return raw


def pin(path, raw=None):
    data = read(path) if raw is None else raw
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def write(name, raw):
    files = list(OUT.iterdir())
    require('/' not in name and len(files) < 12 and len(raw) <= 32768, 'export file bound')
    require(all(path.is_file() and not path.is_symlink() for path in files), 'export tree bound')
    require(sum(path.stat().st_size for path in files) + len(raw) <= 65536, 'export byte budget')
    require(not any(word in raw for word in FORBIDDEN), 'private field refused')
    with (OUT / name).open('xb') as stream:
        require(stream.write(raw) == len(raw), 'short export write')
    return pin(OUT / name)


def save(name, value):
    return write(name, canonical(value))


def records(raw, start=0):
    chunks, result, offset = raw.splitlines(keepends=True), [], start
    require(len(chunks) <= 4096, 'log line count bound')
    for index, line in enumerate(chunks, 1):
        require(line.endswith(b'\n') and len(line) <= 262144, 'complete bounded line required')
        location = dict(line=index, byte_start=offset, byte_end=offset + len(line), raw_line_sha256=digest(line))
        result.append((location, json.loads(line)))
        offset += len(line)
    return result


def session():
    raw = read(LOG)
    meta, contexts, events, usage, finals = [], [], [], [], []
    for location, value in records(raw):
        payload, kind = value.get('payload', {}), value.get('type')
        subtype = payload.get('type')
        item = dict(source=location, timestamp=value.get('timestamp'))
        if kind == 'session_meta':
            item['value'] = {key: payload.get(key) for key in ('id', 'agent_path', 'timestamp', 'cli_version', 'model_provider')}
            meta.append(item)
        elif kind == 'turn_context':
            contexts.append(dict(item, value={key: payload.get(key) for key in ('model', 'effort')}))
        elif kind == 'event_msg' and subtype in ('task_started', 'task_complete'):
            events.append(dict(item, type=subtype))
        elif kind == 'event_msg' and subtype == 'token_count' and payload.get('info') is not None:
            usage.append(dict(item, value={key: payload['info'].get(key)
                for key in ('total_token_usage', 'last_token_usage', 'model_context_window')}))
        if kind == 'response_item' and subtype == 'message' and payload.get('role') == 'assistant' and payload.get('phase') == 'final_answer':
            content = payload.get('content')
            require(type(content) is list and len(content) <= 32, 'final content bound')
            require(all(part.get('type') == 'output_text' and type(part.get('text')) is str for part in content), 'plain final only')
            text = '\n'.join(part['text'] for part in content).encode('utf-8')
            finals.append(dict(item, artifact=write('final-%04d.txt' % location['line'], text)))
    require(len(meta) == 1 and meta[0]['value']['agent_path'] == '/root/' + TASK, 'selected session differs')
    require(contexts and finals and usage and events[-1]['type'] == 'task_complete', 'complete evaluator evidence required')
    return dict(source_snapshot=pin(LOG, raw), session=meta[0], observed_turn_contexts=contexts,
                lifecycle_events=events, last_host_token_count=usage[-1], stripped_final_text=finals,
                usage_scope='Host cumulative usage includes global/repeated context; not document tokens or billed cost.',
                time_scope='Raw observed timestamps only; no elapsed-time arithmetic.')


def dispatch():
    size = ROOT_LOG.stat().st_size
    start = max(0, size - 4194304)
    with ROOT_LOG.open('rb') as stream:
        stream.seek(start)
        raw = stream.read(4194304)
    snapshot = dict(path=str(ROOT_LOG), observed_bytes=size, start=start, bytes=len(raw), sha256=digest(raw))
    if start:
        cut = raw.index(b'\n') + 1
        raw, start = raw[cut:], start + cut
    found = []
    for location, value in records(raw, start):
        payload = value.get('payload', {})
        if value.get('type') == 'response_item' and payload.get('name') == 'spawn_agent':
            text = payload.get('arguments')
            require(type(text) is str, 'dispatch arguments text required')
            arguments = json.loads(text)
            if arguments.get('task_name') == TASK:
                found.append(dict(source=location, timestamp=value.get('timestamp'),
                                  artifact=write('dispatch-arguments.json', text.encode('utf-8'))))
    require(len(found) == 1, 'exactly one selected dispatch required in bounded tail')
    return dict(root_tail=snapshot, dispatch=found[0], line_numbers='TAIL_COMPLETE_LINES_ONLY')


def main():
    require(len(list(OUT.iterdir())) == 1, 'fresh export directory required')
    for node in ast.walk(ast.parse(read(Path(__file__)))):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            require(node.end_lineno - node.lineno + 1 <= 60, 'function size bound')
    evaluation = read(EVALUATION, 32768)
    require(digest(evaluation) == HELD_EVALUATION, 'evaluation receipt differs from held identity')
    observed, dispatched = session(), dispatch()
    save('metadata.json', dict(schema='transport/evaluator-model-observation/1', evaluation_receipt=pin(EVALUATION, evaluation),
        observation=observed, dispatch=dispatched, source_receipt_binding='EXACT_RECEIPT_BYTES_NOT_MODEL_BACKEND_ATTESTATION',
        omitted='Global instructions, reasoning, private metadata, source-evaluator tool contents and account rate limits.'))
    require(read(EVALUATION, 32768) == evaluation, 'evaluation receipt changed')
    files = [pin(path) for path in sorted(OUT.iterdir())]
    save('receipt.json', dict(schema='transport/selective-evaluator-export/1', status='EXPORTED_SCOPED', files=files,
                             bytes_before_receipt=sum(item['bytes'] for item in files), model_identity='OBSERVED_SESSION_METADATA'))
    print(canonical(dict(status='EXPORTED_SCOPED', receipt=pin(OUT / 'receipt.json'), metadata=pin(OUT / 'metadata.json'))).decode())


if __name__ == '__main__':
    main()
