"""Independent bounded finite-receipt review controls; source code is evidence only."""
import copy
import json
from pathlib import Path
import sys
from unittest import mock
sys.dont_write_bytecode = True
REPO = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
sys.path.insert(0, str(REPO / 'install'))
import test_finite_check as fixture
import transport_bound_check as bridge
import transport_bound_lowering as lowering
import transport_finite_check as finite
from transport_install_support import canonical, read_regular, sha


def refused(action):
    try:
        action()
    except ValueError as error:
        return dict(status='REFUSED_AS_REQUIRED', reason=str(error))
    raise AssertionError('unsafe input accepted')


def main():
    results = {}
    base, spec, patch = fixture.tiny()
    receipt = fixture.run(base, spec, patch)
    same = fixture.run(base, spec, dict(patch, after='(open_now and available >= 1)'))
    assert same['actual_bits'] == receipt['actual_bits']
    assert same['replacement_sha256'] != receipt['replacement_sha256']
    raw = canonical(receipt)
    results['same_result_distinct_candidate_receipt'] = refused(
        lambda: finite.validate_receipt(raw, same, sha(raw)))
    for field, value in (('truth', 'KNOWN_FALSE'), ('binding_sha256', '0' * 64),
                         ('state_count', True), ('failures', False)):
        changed = canonical(dict(receipt, **{field: value}))
        results['receipt_' + field] = refused(
            lambda changed=changed: finite.validate_receipt(changed, receipt, sha(changed)))
    expected = spec['expected_bits'][:-1] + '0'
    last = fixture.run(base, dict(spec, expected_bits=expected), patch)
    assert last['truth'] == 'KNOWN_FALSE' and last['failures'] == 1
    assert last['first_mismatches'][0]['index'] == last['state_count'] - 1
    results['last_state_mismatch'] = dict(status='TESTED', receipt=last)
    domains = copy.deepcopy(spec['domains'])
    domains['available']['max'] = 255
    maximum = fixture.run(base, dict(spec, domains=domains, expected_bits='0' * 257 + '1' * 255), patch)
    assert maximum['state_count'] == finite.MAX_STATES and maximum['truth'] == 'KNOWN_TRUE'
    results['maximum_state_count'] = dict(status='TESTED', receipt=maximum)
    names = tuple('p' + str(i) for i in range(16))
    many_base = ('def fixed(' + ', '.join(names) + '):\n    return False\n').encode()
    many_spec = fixture.specification(many_base, 'fixed', names,
        {name: {'type': 'boolean'} for name in names}, '0')
    many_patch = fixture.replacement(many_base, 'False', 'True')
    with mock.patch.object(finite, 'evaluate', side_effect=AssertionError('enumeration began')):
        results['maximum_parameters_overflow_before_evaluation'] = refused(
            lambda: fixture.run(many_base, many_spec, many_patch))
    observed = bridge.observation(receipt, {'bindings': {2: {'sha256': fixture.BINDING},
                                                       4: {'sha256': '0' * 64}}})
    assert observed['masks'] == {2: lowering.REPORT_BITS['KNOWN_TRUE']}
    compiled = {'unit': {'meaning': {'nodes': [
        {'op': 'text'}, {'op': 'term'}, {'op': 'pred', 'args': [0, 1]},
        {'op': 'must', 'args': [2]}, {'op': 'pred', 'args': [0, 1]},
        {'op': 'must', 'args': [4]}, {'op': 'and', 'args': [3, 5]}], 'root': 6}}}
    lowered = lowering.lower(compiled, observed)
    assert [row['meaning_node'] for row in lowered['trace']] == [2, 3, 4, 5, 6]
    assert lowered['frame'][6 + 2 * 6 + 1] == 0
    results['other_predicate_mask_remains_unknown_full_obligation_retained'] = dict(
        status='TESTED', trace=lowered['trace'], frame_hex=lowered['frame'].hex())
    dependencies = {name: sha(read_regular(REPO / 'install' / name)) for name in (
        'transport_finite_check.py', 'transport_bound_check.py', 'transport_bound_lowering.py',
        'transport_fixture_expression.py', 'test_finite_check.py', 'test_bound_test_receipts.py')}
    print(json.dumps(dict(status='TESTED_SCOPED', controls=results, source_sha256=dependencies,
                         formal_proof='NOT_CLAIMED', execution_authority='NONE'), sort_keys=True))


if __name__ == '__main__':
    main()
