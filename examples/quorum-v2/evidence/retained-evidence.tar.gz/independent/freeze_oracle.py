"""Independent literal policy oracle preparation; imports no product implementation."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
OUT = Path('/dev/shm/semantic-transport-quorum-v2-20261029/independent/revision02')
CONTRACT_SHA = 'b18d82dedcfd9a90dfa4e6576ae453296c2f6f32baa222c5c83b27c0cbdd43ae'
CASES = []


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def counts(support=0, oppose=0, dispute=0, abstain=0):
    return dict(SUPPORT=support, OPPOSE=oppose, DISPUTE=dispute, ABSTAIN=abstain)


def baseline(number=3):
    need(1 <= number <= 10, 'fixture seat bound')
    contract = json.loads((ROOT / 'docs/quorum-v2-contract.json').read_bytes())
    docs = copy.deepcopy(contract['input_templates'])
    context = dict(claim_sha256='1'*64, task_sha256='2'*64, source_set_sha256='3'*64)
    docs['policy'].update(context=context, required_seats=[], minimum_support=2, minimum_families=2)
    docs['registry']['seats'] = []
    docs['admissions']['runs'] = []
    docs['ballot'].update(context=copy.deepcopy(context), readings=[])
    for index in range(number):
        label = chr(ord('A') + index)
        docs['policy']['required_seats'].append('seat'+label)
        docs['registry']['seats'].append(dict(seat_id='seat'+label, model_id='model'+label, family_id='family'+label))
        reading = dict(reading_id='reading'+label, seat_id='seat'+label, run_id='run'+label,
                       model_id='model'+label, family_id='family'+label, context=copy.deepcopy(context),
                       prompt_sha256='4'*64, settings_sha256='5'*64, response_text='yes',
                       raw_response_sha256=digest(b'yes'), stance='SUPPORT')
        docs['ballot']['readings'].append(reading)
    reseal_admissions(docs)
    return docs


def reseal_admissions(docs):
    docs['admissions']['runs'] = []
    for reading in docs['ballot']['readings']:
        row = {name:copy.deepcopy(reading[name]) for name in ('seat_id','run_id','model_id','family_id','context','prompt_sha256','settings_sha256','raw_response_sha256')}
        row.update(reading_sha256=digest(canonical(reading)), state='ACTIVE', origin='SYNTHETIC_FIXTURE')
        docs['admissions']['runs'].append(row)


def expected(**changes):
    value = dict(status='EVALUATED', verdict='RECORDED_SUPPORT_THRESHOLD_MET', reasons=[],
                 missing_seats=[], support_count=3, support_families=['familyA','familyB','familyC'],
                 eligible_count=3, provenance_class='SYNTHETIC_ONLY', actual_support_is_cross_family=True,
                 policy_requires_cross_family=True, cross_family_policy_satisfied=True,
                 raw_stance_counts=counts(3), eligible_stance_counts=counts(3),
                 eligible_reading_ids=['readingA','readingB','readingC'], ineligible_reasons={})
    value.update(changes)
    return value


def refused():
    return dict(status='REFUSED', code='NONEMPTY_FIXED_CODE', no_partial_threshold_result=True)


def add(name, docs, result, rationale, raw_changes=None, held_changes=None):
    need(len(CASES) < 128 and name not in {row['id'] for row in CASES}, 'case bound/identity')
    folder = OUT / 'cases' / name
    folder.mkdir(parents=True, mode=0o700)
    raw = {key:canonical(docs[key]) for key in ('policy','registry','admissions','ballot')}
    for key, value in (raw_changes or {}).items():
        raw[key] = value
    held = {key:digest(raw[key]) for key in ('policy','registry','admissions')}
    held.update(held_changes or {})
    files = {}
    for key, data in raw.items():
        need(len(data) <= 70000, 'literal file bound')
        (folder / (key+'.json')).write_bytes(data)
        files[key] = dict(path='cases/'+name+'/'+key+'.json', bytes=len(data), sha256=digest(data))
    CASES.append(dict(id=name, inputs=files, held_sha256=held, expected=result, rationale=rationale))


def stance_case(name, stances, result, rationale):
    docs = baseline()
    for reading, stance in zip(docs['ballot']['readings'], stances, strict=True):
        reading['stance'] = stance
    reseal_admissions(docs)
    add(name, docs, result, rationale)


def schema_case(name, mutate, rationale):
    docs = baseline()
    mutate(docs)
    add(name, docs, refused(), rationale)


def fixed_policy_cases():
    add('P01_THREE_FAMILIES', baseline(), expected(), 'All required seats eligible; three assigned supporting families.')
    stance_case('P02_ELIGIBLE_OPPOSE', ['SUPPORT','OPPOSE','SUPPORT'], expected(verdict='BLOCKED_DISSENT', reasons=['BLOCKED_DISSENT'], support_count=2, support_families=['familyA','familyC'], cross_family_policy_satisfied=False, raw_stance_counts=counts(2,1), eligible_stance_counts=counts(2,1)), 'Eligible opposition vetoes despite both thresholds being met.')
    stance_case('P03_ELIGIBLE_DISPUTE', ['SUPPORT','DISPUTE','SUPPORT'], expected(verdict='BLOCKED_DISSENT', reasons=['BLOCKED_DISSENT'], support_count=2, support_families=['familyA','familyC'], cross_family_policy_satisfied=False, raw_stance_counts=counts(2,0,1), eligible_stance_counts=counts(2,0,1)), 'Eligible dispute is decisive dissent.')
    stance_case('P04_ALL_ABSTAIN', ['ABSTAIN']*3, expected(verdict='INSUFFICIENT_SUPPORT', reasons=['INSUFFICIENT_SUPPORT','INSUFFICIENT_FAMILY_DIVERSITY'], support_count=0, support_families=[], actual_support_is_cross_family=False, cross_family_policy_satisfied=False, raw_stance_counts=counts(abstain=3), eligible_stance_counts=counts(abstain=3)), 'Attendance alone cannot create support or family diversity.')
    stance_case('P05_SUPPORT_ONE', ['SUPPORT','ABSTAIN','ABSTAIN'], expected(verdict='INSUFFICIENT_SUPPORT', reasons=['INSUFFICIENT_SUPPORT','INSUFFICIENT_FAMILY_DIVERSITY'], support_count=1, support_families=['familyA'], actual_support_is_cross_family=False, cross_family_policy_satisfied=False, raw_stance_counts=counts(1,abstain=2), eligible_stance_counts=counts(1,abstain=2)), 'One support is insufficient under both configured thresholds.')
    stance_case('P06_ABSTAIN_ATTENDANCE', ['SUPPORT','ABSTAIN','SUPPORT'], expected(support_count=2, support_families=['familyA','familyC'], raw_stance_counts=counts(2,abstain=1), eligible_stance_counts=counts(2,abstain=1)), 'Eligible abstention satisfies attendance and contributes no support.')
    docs = baseline()
    for row in docs['registry']['seats']:
        row['family_id'] = 'familyA'
    for row in docs['ballot']['readings']:
        row['family_id'] = 'familyA'
    reseal_admissions(docs)
    add('P07_ONE_FAMILY_ALIASES', docs, expected(verdict='INSUFFICIENT_FAMILY_DIVERSITY', reasons=['INSUFFICIENT_FAMILY_DIVERSITY'], support_families=['familyA'], actual_support_is_cross_family=False, cross_family_policy_satisfied=False), 'Several seats and models do not manufacture distinct assigned families.')
    docs['policy']['minimum_families'] = 1
    add('P08_ONE_FAMILY_POLICY', docs, expected(support_families=['familyA'], actual_support_is_cross_family=False, policy_requires_cross_family=False, cross_family_policy_satisfied=False), 'A valid one-family threshold is explicitly not a cross-family policy.')
    docs = baseline(); docs['policy']['minimum_families'] = 1
    add('P09_ACCIDENTAL_DIVERSITY', docs, expected(policy_requires_cross_family=False, cross_family_policy_satisfied=False), 'Actual diversity does not change what the policy requires.')


def attendance_cases():
    docs = baseline(); docs['ballot']['readings'].pop()
    add('A01_MISSING_SEAT', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS'], missing_seats=['seatC'], support_count=2, support_families=['familyA','familyB'], eligible_count=2, cross_family_policy_satisfied=False, raw_stance_counts=counts(2), eligible_stance_counts=counts(2), eligible_reading_ids=['readingA','readingB']), 'Numerical support thresholds cannot bypass required attendance.')
    docs = baseline(); docs['admissions']['runs'].pop()
    add('A02_MISSING_ADMISSION', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS'], missing_seats=['seatC'], support_count=2, support_families=['familyA','familyB'], eligible_count=2, cross_family_policy_satisfied=False, eligible_stance_counts=counts(2), eligible_reading_ids=['readingA','readingB'], ineligible_reasons={'readingC':['MISSING_ADMISSION']}), 'Unheld candidate run cannot self-admit.')
    docs = baseline(); docs['admissions']['runs'][2]['state'] = 'WITHDRAWN'
    add('A03_WITHDRAWN', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS'], missing_seats=['seatC'], support_count=2, support_families=['familyA','familyB'], eligible_count=2, cross_family_policy_satisfied=False, eligible_stance_counts=counts(2), eligible_reading_ids=['readingA','readingB'], ineligible_reasons={'readingC':['WITHDRAWN']}), 'Withdrawal excludes and retains the exact reading.')
    docs = baseline(); docs['ballot']['readings'] = []; docs['admissions']['runs'] = []
    add('A04_EMPTY_BALLOT', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS','INSUFFICIENT_SUPPORT','INSUFFICIENT_FAMILY_DIVERSITY'], missing_seats=['seatA','seatB','seatC'], support_count=0, support_families=[], eligible_count=0, provenance_class='NO_ELIGIBLE_READINGS', actual_support_is_cross_family=False, cross_family_policy_satisfied=False, raw_stance_counts=counts(), eligible_stance_counts=counts(), eligible_reading_ids=[]), 'No readings yields no threshold success and all failure reasons.')


def provenance_cases():
    docs = baseline()
    for row in docs['admissions']['runs']:
        row['origin'] = 'OBSERVED_BINDING'
    add('V01_OBSERVED_DECLARATIONS', docs, expected(provenance_class='OBSERVED_ONLY'), 'Origin class describes held declarations, not provider authentication.')
    docs['admissions']['runs'][0]['origin'] = 'SYNTHETIC_FIXTURE'
    add('V02_MIXED_ORIGINS', docs, expected(provenance_class='MIXED'), 'Synthetic origin is not erased by other observed-binding labels.')
    docs = baseline(); docs['admissions']['runs'][2]['origin'] = 'OBSERVED_BINDING'; docs['admissions']['runs'][2]['state'] = 'WITHDRAWN'
    add('V03_INELIGIBLE_ORIGIN', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS'], missing_seats=['seatC'], support_count=2, support_families=['familyA','familyB'], eligible_count=2, cross_family_policy_satisfied=False, eligible_stance_counts=counts(2), eligible_reading_ids=['readingA','readingB'], ineligible_reasons={'readingC':['WITHDRAWN']}), 'Only eligible readings determine eligible provenance class.')
    schema_case('V04_FAKE_AUTHENTICATED_ORIGIN', lambda d:d['admissions']['runs'][0].update(origin='AUTHENTICATED'), 'Unadmitted provenance classification refuses even under a held root.')


fixed_policy_cases()
attendance_cases()
provenance_cases()


def ineligible_third(**changes):
    return expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS'], missing_seats=['seatC'], support_count=2, support_families=['familyA','familyB'], eligible_count=2, cross_family_policy_satisfied=False, eligible_stance_counts=counts(2), eligible_reading_ids=['readingA','readingB'], **changes)


def binding_cases():
    for name, field, value in [('B01_FORGED_FAMILY','family_id','fakeFamily'), ('B02_FORGED_MODEL','model_id','fakeModel'), ('B03_FORGED_PROMPT','prompt_sha256','6'*64), ('B04_FORGED_SETTINGS','settings_sha256','6'*64)]:
        docs = baseline(); docs['ballot']['readings'][2][field] = value
        add(name, docs, ineligible_third(ineligible_reasons={'readingC':['BINDING_MISMATCH']}), 'Candidate cannot override a separately held exact reading binding: '+field)
    docs = baseline(); docs['ballot']['readings'][2]['context']['source_set_sha256'] = '6'*64
    add('B05_READING_CONTEXT', docs, ineligible_third(ineligible_reasons={'readingC':['BINDING_MISMATCH']}), 'Per-reading context mismatch excludes while retaining the reading.')
    docs = baseline(); docs['ballot']['readings'][2]['stance'] = 'OPPOSE'
    add('B06_UNHELD_DISSENT', docs, ineligible_third(raw_stance_counts=counts(2,1), ineligible_reasons={'readingC':['BINDING_MISMATCH']}), 'Ineligible opposition remains visible but has no veto under this exact policy.')
    docs = baseline(); docs['ballot']['readings'][2]['response_text'] = 'no'
    add('B07_TEXT_CHANGED_UNHELD', docs, ineligible_third(ineligible_reasons={'readingC':['BINDING_MISMATCH','RESPONSE_DIGEST_MISMATCH']}), 'Text alteration violates both held complete reading and actual UTF8 digest.')
    docs['ballot']['readings'][2]['raw_response_sha256'] = digest(b'no')
    add('B08_RESPONSE_REHASHED_UNHELD', docs, ineligible_third(ineligible_reasons={'readingC':['BINDING_MISMATCH']}), 'Candidate recomputation fixes text integrity but cannot create external admission.')
    docs = baseline(); docs['ballot']['readings'][2]['raw_response_sha256'] = '6'*64; reseal_admissions(docs)
    add('B09_HELD_WRONG_RESPONSE_DIGEST', docs, ineligible_third(ineligible_reasons={'readingC':['RESPONSE_DIGEST_MISMATCH']}), 'An externally pinned admission does not bypass response-byte validation.')
    docs = baseline(); docs['ballot']['readings'][2]['response_text'] = 'I oppose this claim.'; docs['ballot']['readings'][2]['raw_response_sha256'] = digest(b'I oppose this claim.'); reseal_admissions(docs)
    add('B10_NO_STANCE_EXTRACTION', docs, expected(), 'Bound SUPPORT stance is counted despite contrary text; interpretation is explicitly NOT_CHECKED, not claimed valid.')
    docs = baseline(); docs['admissions']['runs'][2]['reading_sha256'] = '6'*64
    add('B11_WRONG_HELD_READING_DIGEST', docs, ineligible_third(ineligible_reasons={'readingC':['BINDING_MISMATCH']}), 'Held expected digest chooses comparison; disagreement does not silently count.')
    docs = baseline(); docs['ballot']['context']['claim_sha256'] = '6'*64
    add('B12_WHOLE_BALLOT_CONTEXT', docs, refused(), 'Whole ballot scope differs from policy; independent pre-code clarification requires refusal.')


def duplicate_cases():
    docs = baseline(); clone = copy.deepcopy(docs['ballot']['readings'][2]); clone['reading_id'] = 'readingC2'; docs['ballot']['readings'].append(clone)
    add('D01_DUPLICATE_SEAT_AND_RUN', docs, ineligible_third(raw_stance_counts=counts(4), ineligible_reasons={'readingC':['DUPLICATE_SEAT','DUPLICATE_RUN'],'readingC2':['DUPLICATE_SEAT','DUPLICATE_RUN','BINDING_MISMATCH']}), 'Every candidate collision member excluded; do not select first or last.')
    docs = baseline(); clone = copy.deepcopy(docs['ballot']['readings'][2]); clone.update(reading_id='readingC2',run_id='runC2'); docs['ballot']['readings'].append(clone); reseal_admissions(docs)
    add('D02_TWO_ADMITTED_RUNS_ONE_SEAT', docs, ineligible_third(raw_stance_counts=counts(4), ineligible_reasons={'readingC':['DUPLICATE_SEAT'],'readingC2':['DUPLICATE_SEAT']}), 'Distinct valid admitted runs cannot give one required seat two ballots.')
    docs = baseline(); docs['ballot']['readings'][2]['run_id'] = 'runB'
    add('D03_ONE_RUN_TWO_SEATS', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS','INSUFFICIENT_SUPPORT','INSUFFICIENT_FAMILY_DIVERSITY'], missing_seats=['seatB','seatC'], support_count=1, support_families=['familyA'], eligible_count=1, actual_support_is_cross_family=False, cross_family_policy_satisfied=False, eligible_stance_counts=counts(1), eligible_reading_ids=['readingA'], ineligible_reasons={'readingB':['DUPLICATE_RUN'],'readingC':['DUPLICATE_RUN','BINDING_MISMATCH']}), 'A stable run key cannot be laundered through different seat IDs.')
    docs = baseline(); docs['admissions']['runs'].append(copy.deepcopy(docs['admissions']['runs'][0]))
    add('D04_DUPLICATE_ADMISSION_RUN', docs, refused(), 'Trusted-root document ambiguity refuses, rather than picking one record.')
    docs = baseline(); docs['ballot']['readings'][2]['reading_id'] = 'readingB'
    add('D05_DUPLICATE_READING_ID', docs, refused(), 'Candidate identity ambiguity refuses the entire result.')
    docs = baseline(); foreign = copy.deepcopy(docs['ballot']['readings'][0]); foreign.update(reading_id='readingD',seat_id='seatD',run_id='runD',stance='DISPUTE'); docs['ballot']['readings'].append(foreign)
    add('D06_FOREIGN_DISSENT', docs, expected(raw_stance_counts=counts(3,dispute=1), ineligible_reasons={'readingD':['NOT_REQUIRED_SEAT','MISSING_ADMISSION']}), 'Foreign unadmitted dissent is retained and does not acquire a blocking vote.')
    docs = baseline(); docs['ballot']['readings'][1]['stance'] = 'OPPOSE'; reseal_admissions(docs); docs['admissions']['runs'][2]['state'] = 'WITHDRAWN'
    add('D07_ALL_POLICY_FAILURES', docs, expected(verdict='MISSING_ELIGIBLE_SEATS', reasons=['MISSING_ELIGIBLE_SEATS','BLOCKED_DISSENT','INSUFFICIENT_SUPPORT','INSUFFICIENT_FAMILY_DIVERSITY'], missing_seats=['seatC'], support_count=1, support_families=['familyA'], eligible_count=2, actual_support_is_cross_family=False, cross_family_policy_satisfied=False, raw_stance_counts=counts(2,1), eligible_stance_counts=counts(1,1), eligible_reading_ids=['readingA','readingB'], ineligible_reasons={'readingC':['WITHDRAWN']}), 'Verdict priority cannot erase other failed conditions or eligible dissent.')


def trusted_root_cases():
    for name in ('policy','registry','admissions'):
        add('H01_WRONG_'+name.upper()+'_ROOT', baseline(), refused(), 'Exact raw root comparison is mandatory: '+name, held_changes={name:'0'*64})
        add('H02_MISSING_'+name.upper()+'_ROOT', baseline(), refused(), 'Missing external root never falls back to candidate bytes: '+name, held_changes={name:None})
    docs = baseline(); docs['ballot']['held_sha256'] = dict(policy='0'*64,registry='0'*64,admissions='0'*64)
    add('H03_CANDIDATE_ROOT_SMUGGLING', docs, refused(), 'Unknown root fields in ballot do not create trust.')
    docs = baseline(); docs['admissions']['runs'][2]['family_id'] = 'fakeFamily'; docs['ballot']['readings'].pop()
    add('H04_BAD_ADMISSION_UNUSED', docs, refused(), 'Every present admission is checked against registry even if candidate omits its run.')
    docs = baseline(); docs['admissions']['runs'][2]['seat_id'] = 'seatD'
    add('H05_UNKNOWN_ADMISSION_SEAT', docs, refused(), 'Trusted admission cannot invent a new seat outside exact registry.')
    docs = baseline(); docs['admissions']['runs'][2]['context']['task_sha256'] = '6'*64
    add('H06_BAD_ADMISSION_CONTEXT', docs, refused(), 'An externally pinned but inconsistent scope refuses.')
    docs = baseline(); docs['registry']['seats'].pop()
    add('H07_REGISTRY_INCOMPLETE', docs, refused(), 'Registry must exactly cover required seats.')
    docs = baseline(); docs['registry']['seats'].append(copy.deepcopy(docs['registry']['seats'][0]))
    add('H08_REGISTRY_DUPLICATE', docs, refused(), 'Duplicate registry IDs cannot be silently coalesced.')


binding_cases()
duplicate_cases()
trusted_root_cases()


def nine_expected():
    return expected(support_count=9, support_families=['family'+c for c in 'ABCDEFGHI'], eligible_count=9, raw_stance_counts=counts(9), eligible_stance_counts=counts(9), eligible_reading_ids=['reading'+c for c in 'ABCDEFGHI'])


def bound_cases():
    add('L01_NINE_STANDALONE_SEATS', baseline(9), nine_expected(), 'The new standalone companion admits nine; this does not widen V1 eight-seat admission.')
    add('L02_TEN_SEATS_REFUSED', baseline(10), refused(), 'New companion seat cap remains nine.')
    docs = baseline(); docs['ballot']['readings'][2]['response_text'] = 'a'*4096; docs['ballot']['readings'][2]['raw_response_sha256'] = digest(b'a'*4096); reseal_admissions(docs)
    add('L03_RESPONSE_4096_BYTES', docs, expected(), 'Exact UTF8 response boundary is admitted.')
    docs['ballot']['readings'][2]['response_text'] += 'a'; docs['ballot']['readings'][2]['raw_response_sha256'] = digest(b'a'*4097); reseal_admissions(docs)
    add('L04_RESPONSE_4097_BYTES', docs, refused(), 'First byte above response bound refuses, without truncation.')
    docs = baseline(); docs['ballot']['readings'][2]['response_text'] = '\u00e9'*2048; docs['ballot']['readings'][2]['raw_response_sha256'] = digest(('\u00e9'*2048).encode()); reseal_admissions(docs)
    add('L05_MULTIBYTE_4096_BYTES', docs, expected(), 'Response limit measures UTF8 bytes, not Python characters.')
    docs['ballot']['readings'][2]['response_text'] += '\u00e9'; docs['ballot']['readings'][2]['raw_response_sha256'] = digest(('\u00e9'*2049).encode()); reseal_admissions(docs)
    add('L06_MULTIBYTE_OVERFLOW', docs, refused(), 'A multibyte character cannot pass character-count validation.')
    docs = baseline(); docs['registry']['seats'][2]['family_id'] = 'z'*32; docs['ballot']['readings'][2]['family_id'] = 'z'*32; reseal_admissions(docs)
    add('L07_FAMILY_ID_32', docs, expected(support_families=['familyA','familyB','z'*32]), 'Ordinary identifier exact boundary.')
    docs['registry']['seats'][2]['family_id'] += 'z'; docs['ballot']['readings'][2]['family_id'] += 'z'; reseal_admissions(docs)
    add('L08_FAMILY_ID_33', docs, refused(), 'Ordinary identifier overflow cannot enter held registry.')
    for kind in ('model','run'):
        docs = baseline(); field = kind+'_id'; docs['ballot']['readings'][2][field] = 'z'*128
        if kind == 'model':
            docs['registry']['seats'][2][field] = 'z'*128
        reseal_admissions(docs)
        add('L09_'+kind.upper()+'_ID_128', docs, expected(), 'Explicit extended identifier boundary: '+kind)
        docs['ballot']['readings'][2][field] += 'z'
        if kind == 'model':
            docs['registry']['seats'][2][field] += 'z'
        reseal_admissions(docs)
        add('L10_'+kind.upper()+'_ID_129', docs, refused(), 'Extended identifier overflow: '+kind)
    docs = baseline(); base_size = sum(len(canonical(row)) for row in docs.values()); ballot = canonical(docs['ballot'])
    add('L11_AGGREGATE_65536', docs, expected(), 'JSON whitespace counts against aggregate input bound but is permitted.', raw_changes={'ballot':ballot+b' '*(65536-base_size)})
    add('L12_AGGREGATE_65537', docs, refused(), 'First aggregate byte above limit refuses.', raw_changes={'ballot':ballot+b' '*(65537-base_size)})
    docs = baseline()
    for index in range(29):
        row = copy.deepcopy(docs['admissions']['runs'][0]); row['run_id'] = 'unused'+str(index)
        latent = copy.deepcopy(docs['ballot']['readings'][0]); latent['run_id'] = row['run_id']
        row['reading_sha256'] = digest(canonical(latent)); docs['admissions']['runs'].append(row)
    add('L13_ADMISSIONS_32', docs, expected(), 'Every admission is validated; unused consistent admissions need no candidate.')
    row = copy.deepcopy(docs['admissions']['runs'][0]); row['run_id'] = 'overflow'; docs['admissions']['runs'].append(row)
    add('L14_ADMISSIONS_33', docs, refused(), 'Admission count overflow refuses before result construction.')
    docs = baseline(9)
    for reading in docs['ballot']['readings']:
        reading['response_text'] = 'a'*4096; reading['raw_response_sha256'] = digest(b'a'*4096)
    reseal_admissions(docs)
    add('L15_COMPLETE_OUTPUT_BOUND', docs, refused(), 'Retaining all nine large readings exceeds result cap; exact refusal replaces partial output.')


def parse_cases():
    for name, value in [('ZERO',0),('ABOVE_ROSTER',4),('BOOLEAN',True),('FLOAT',2.0),('STRING','2')]:
        schema_case('S01_SUPPORT_'+name, lambda d,v=value:d['policy'].update(minimum_support=v), 'Strict bounded integer support threshold: '+name)
    schema_case('S02_FAMILY_ZERO', lambda d:d['policy'].update(minimum_families=0), 'Family threshold is positive.')
    schema_case('S03_FAMILY_ABOVE_SUPPORT', lambda d:d['policy'].update(minimum_families=3), 'Family minimum cannot exceed support minimum.')
    schema_case('S04_REQUIRED_UNSORTED', lambda d:d['policy']['required_seats'].reverse(), 'Canonical roster order is mandatory.')
    schema_case('S05_REQUIRED_DUPLICATE', lambda d:d['policy']['required_seats'].append('seatC'), 'Required roster is a set, never silently deduplicated.')
    schema_case('S06_UNKNOWN_POLICY_FIELD', lambda d:d['policy'].update(authority='GRANTED'), 'Closed policy fields prevent authority smuggling.')
    schema_case('S07_RESERVED_V1_SCHEMA', lambda d:d['policy'].update(schema='quorum/threshold-policy/1'), 'New entry does not reinterpret version one.')
    schema_case('S08_UNKNOWN_STANCE', lambda d:d['ballot']['readings'][0].update(stance='TRUE'), 'Stance is a closed enumeration, not truth.')
    schema_case('S09_MISSING_READING_CONTEXT', lambda d:d['ballot']['readings'][0].pop('context'), 'Missing context refuses rather than borrowing global context.')
    schema_case('S10_UPPERCASE_DIGEST', lambda d:d['policy']['context'].update(claim_sha256='A'*64), 'Digest spelling is lowercase hexadecimal.')
    schema_case('S11_UNICODE_ID', lambda d:d['registry']['seats'][0].update(family_id='famil\u00e9'), 'Family labels remain bounded ASCII identifiers.')
    docs = baseline(); policy = canonical(docs['policy']); duplicate = policy.replace(b'"minimum_support":2',b'"minimum_support":2,"minimum_support":2')
    add('S12_DUPLICATE_JSON_KEY', docs, refused(), 'Even identical duplicate keys refuse; no last-key selection.', raw_changes={'policy':duplicate})
    add('S13_INVALID_UTF8', docs, refused(), 'Invalid raw UTF8 refuses without replacement.', raw_changes={'ballot':b'\xff'})
    ballot = canonical(docs['ballot']).replace(b'"response_text":"yes"',b'"response_text":"\\ud800"',1)
    add('S14_UNPAIRED_SURROGATE', docs, refused(), 'Escaped surrogate cannot become silently replaced response bytes.', raw_changes={'ballot':ballot})
    policy = canonical(docs['policy']).replace(b'"minimum_support":2',b'"minimum_support":NaN')
    add('S15_NONFINITE_JSON', docs, refused(), 'Nonfinite JSON constants are outside admitted number grammar.', raw_changes={'policy':policy})
    admission = canonical(docs['admissions'])+b'\n'
    add('S16_WHITESPACE_WITH_HELD_ROOT', docs, expected(), 'Whitespace is allowed when exact raw root is independently matched.', raw_changes={'admissions':admission})
    add('S17_WHITESPACE_STALE_ROOT', docs, refused(), 'Canonical-equivalent text cannot bypass exact raw held digest.', raw_changes={'admissions':admission}, held_changes={'admissions':digest(canonical(docs['admissions']))})
    add('S18_NONSTRING_HELD_ROOT', docs, refused(), 'A boolean cannot serve as a held digest argument.', held_changes={'policy':True})


def finish():
    contract = (ROOT / 'docs/quorum-v2-contract.json').read_bytes()
    need(digest(contract) == CONTRACT_SHA, 'contract changed during independent freeze')
    oracle = dict(schema='quorum/independent-policy-oracle/2', contract_sha256=CONTRACT_SHA,
                  status='FROZEN_EXPECTATIONS_BEFORE_IMPLEMENTATION', cases=CASES,
                  hashing='Held roots hash exact raw input bytes; reading hashes use canonical no-LF JSON.',
                  clarification='Top-level ballot context mismatch refuses; per-reading context mismatch is retained ineligible BINDING_MISMATCH, confirmed by contract author before implementation.',
                  projection_rules=['Require every listed expected field. Normalize dispositions into sorted eligible IDs and ineligible reasons; preserve complete original reading objects exactly.','REFUSED requires a nonempty fixed code and absence of partial threshold verdict/counts.','Scope must retain authority NONE, source_truth NOT_ASSESSED, interpretation NOT_CHECKED, provider_authentication/error_independence NOT_ESTABLISHED, family_identity HELD_REGISTRY_ASSIGNMENT_ONLY.'],
                  unproved=['No product code, model, native proof or provider call was used to choose expected outcomes.','Opaque prompt/settings/source digest references are not source replay; standalone threshold outcome is not truth.','Origin declarations and assigned family labels are not authenticated provider identity or demonstrated error independence.','Per-schema maxima do not guarantee simultaneous feasibility; output cap is independently binding.'])
    raw = (json.dumps(oracle, indent=2, sort_keys=True)+'\n').encode()
    (OUT / 'oracle.json').write_bytes(raw)
    total = 0; files = 0
    for path in OUT.rglob('*'):
        if path.is_file():
            total += path.stat().st_size; files += 1
    need(total <= 2097152, 'independent evidence cap')
    print(json.dumps(dict(oracle=str(OUT/'oracle.json'),sha256=digest(raw),cases=len(CASES),bytes=total,files=files)))


bound_cases()
parse_cases()
finish()
