"""Independent frozen-oracle execution; never derives expected truth from product."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import sys

os.umask(0o077)
ROOT = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
BASE = Path('/dev/shm/semantic-transport-quorum-v2-20261029/independent/revision02')
sys.path.insert(0, str(ROOT/'tools'))
import transport_quorum_v2_policy as product


def require(value, message):
    if not value:
        raise ValueError(message)


def pins():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'tools').glob('transport_quorum_v2*.py'))}


def compare(actual, expected, path):
    require(type(actual) is type(expected), 'type '+path)
    if type(expected) is dict:
        require(set(actual)==set(expected), 'keys '+path)
        for key in expected:
            compare(actual[key], expected[key], path+'.'+key)
    elif type(expected) is list:
        require(len(actual)==len(expected), 'length '+path)
        for index,(a,e) in enumerate(zip(actual,expected,strict=True)):
            compare(a,e,path+'.'+str(index))
    else:
        require(actual==expected,'value '+path)


def inspect_result(result, case, docs):
    expected=case['expected']
    compare(result['status'],expected['status'],'status')
    if expected['status']=='REFUSED':
        require(set(result)=={'schema','status','code','authority'},'partial refusal')
        require(result['schema']=='quorum/threshold-refusal/2' and result['authority']=='NONE','refusal scope')
        require(type(result['code']) is str and re.fullmatch('[A-Z0-9_]+',result['code']) is not None,'fixed refusal code')
        return
    normalized={key:result[key] for key in expected if key not in ('eligible_reading_ids','ineligible_reasons')}
    rows=result['dispositions']
    require(all(type(row['eligible']) is bool for row in rows),'eligibility type')
    normalized['eligible_reading_ids']=[row['reading_id'] for row in rows if row['eligible']]
    normalized['ineligible_reasons']={row['reading_id']:row['reasons'] for row in rows if not row['eligible']}
    compare(normalized,expected,'projection')
    retained=[row['reading'] for row in rows]
    compare(retained,sorted(docs['readings'],key=lambda r:r['reading_id']),'retention')
    require(result['schema']=='quorum/threshold-result/2','result schema')
    for key,value in {'authority':'NONE','source_truth':'NOT_ASSESSED','interpretation':'NOT_CHECKED','provider_authentication':'NOT_ESTABLISHED','error_independence':'NOT_ESTABLISHED','family_identity':'HELD_REGISTRY_ASSIGNMENT_ONLY','origin_class':'EXTERNALLY_HELD_DECLARATIONS_ONLY'}.items():
        compare(result['scope'][key],value,'scope.'+key)
    compare(result['input_pins'],{key:{'bytes':v['bytes'],'sha256':v['sha256']} for key,v in case['inputs'].items()},'input_pins')


def main():
    before=pins(); oracle_raw=(BASE/'oracle.json').read_bytes()
    require(hashlib.sha256(oracle_raw).hexdigest()=='20d24834b1890a6e09130ea58bdaa9e225ded525bdfcf96391f54d068ffde428','oracle pin')
    oracle=json.loads(oracle_raw); outcomes=[]
    for case in oracle['cases']:
        raws=[]
        for key in ('policy','registry','admissions','ballot'):
            item=case['inputs'][key]; raw=(BASE/item['path']).read_bytes()
            require(len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],'literal pin')
            raws.append(raw)
        result=product.evaluate(tuple(raws),case['held_sha256'])
        try:
            docs={} if result.get('status')=='REFUSED' else json.loads(raws[3])
            inspect_result(result,case,docs)
            status,error='PASS',''
        except (ValueError,KeyError,TypeError) as exception:
            status,error='FAILED',str(exception)
        outcomes.append(dict(id=case['id'],status=status,error=error,actual=result))
    require(before==pins(),'product changed during run')
    tag='optimized' if sys.flags.optimize else 'normal'
    report=dict(schema='quorum/independent-policy-observations/2',oracle_sha256=hashlib.sha256(oracle_raw).hexdigest(),source_pins=before,python_flags=dict(optimize=sys.flags.optimize,isolated=sys.flags.isolated,no_site=sys.flags.no_site),outcomes=outcomes)
    raw=(json.dumps(report,sort_keys=True)+'\n').encode()
    with gzip.open(BASE/('results-'+tag+'-03.json.gz'),'wb') as stream:
        stream.write(raw)
    failures=[dict(id=r['id'],error=r['error']) for r in outcomes if r['status']!='PASS']
    print(json.dumps(dict(cases=len(outcomes),failed=failures,source_pins=before)))
    return 1 if failures else 0


if __name__=='__main__':
    raise SystemExit(main())
