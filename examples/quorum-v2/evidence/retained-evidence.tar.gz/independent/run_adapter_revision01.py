"""Independent pre-frozen adapter controls; no model calls, original inputs read-only."""
import copy
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
from unittest.mock import patch

os.umask(0o077)
W=Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
D=Path('/dev/shm/semantic-transport-quorum-v2-20261029/independent')
E=W/'examples/quorum-v2/source-replay-example'
sys.path[:0]=[str(W/'tools'),str(W/'install')]
import transport_quorum_v2_replay as product
import transport_quorum_v2_policy as policy
from transport_quorum_v2_input import Refusal,canonical,pin,sha


def require(condition,message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_bytes())


def write(folder,name,value):
    path=folder/name; path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    path.write_bytes(value if type(value) is bytes else canonical(value))
    return str(path)


def fixture():
    options=load(D.parent/'adapter-options.json')
    raws=tuple((E/(name+'.json')).read_bytes() for name in policy.NAMES)
    return raws,load(E/'held-roots.json'),options


def product_pins():
    return {str(p.relative_to(W)):pin(p) if False else pin(p.read_bytes()) for p in sorted((W/'tools').glob('transport_quorum_v2*.py'))}


def options_with(folder, options, invocation=None, descriptor=None, request=None, bootstrap=None):
    options=copy.deepcopy(options); inv=load(options['invocation']) if invocation is None else copy.deepcopy(invocation)
    req=load(options['request']) if request is None else copy.deepcopy(request)
    if descriptor is not None:
        raw=canonical(descriptor); path=write(folder,'descriptor.json',raw)
        inv['checker_descriptor']={'path':path,'key':dict(logical_source_id='CHECKER_DESCRIPTOR',**pin(raw))}
        req['checker']['checker_descriptor']=inv['checker_descriptor']['key']
    raw=canonical(req); reqpath=write(folder,'request.json',raw)
    inv['request']=dict(path=reqpath,**pin(raw)); inv['held_request']=pin(raw)
    envelope=load(inv['envelope']['path']); envelope['request']=req
    envraw=canonical(envelope); envpath=write(folder,'envelope.json',envraw)
    inv['envelope']=dict(path=envpath,**pin(envraw))
    invraw=canonical(inv); invpath=write(folder,'invocation.json',invraw)
    options.update(invocation=invpath,invocation_sha256=sha(invraw),request=reqpath,request_sha256=sha(raw))
    if bootstrap is not None:
        options['bootstrap']=bootstrap
    return options


def relocated(folder, options):
    inv=load(options['invocation']); desc=load(inv['checker_descriptor']['path']); admitted=load(W/'docs/quorum-v2-replay-admitted.json')
    oldroots={'checker':Path(desc['checker_root']),'handoff':Path(desc['handoff_root'])}
    for item in admitted['files']:
        prefix,suffix=item['path'].split('/',1)
        write(folder/item['path'].split('/')[0],suffix,(oldroots[prefix]/suffix).read_bytes())
    desc.update(checker_root=str(folder/'checker'),handoff_root=str(folder/'handoff'))
    return options_with(folder,options,descriptor=desc,bootstrap=str(folder/'checker/install/transport_quorum_bootstrap.py'))


def require_refusal(result):
    require(type(result) is dict and result.get('status')=='REFUSED','expected refusal')
    require(type(result.get('code')) is str and result['code'],'missing refusal code')
    require('threshold' not in result and 'source_replay' not in result,'partial fallback')


def positive(result):
    require(result['status']=='EVALUATED_DIMENSIONS','live status')
    require(result['threshold']['verdict']=='RECORDED_SUPPORT_THRESHOLD_MET','threshold')
    require(result['threshold']['provenance_class']=='SYNTHETIC_ONLY','synthetic provenance lost')
    require(result['source_replay']['replay']=='RECOMPUTED_INFORMATIONAL','source replay')
    require(result['source_replay']['claims'][0]['change_impact']=='NEEDS_REVALIDATION','warning lost')
    require(result['execution_authority']=='NONE' and result['source_truth']=='NOT_ASSESSED','scope')


def live_mutation(case,raws,held,options,folder):
    name=case['id']; changed=copy.deepcopy(options)
    if name=='A02_FAKE_BOOTSTRAP_SELF_HASH':
        data=b'raise SystemExit("must never execute")\n'; changed.update(bootstrap=write(folder,'fake.py',data),bootstrap_sha256=sha(data))
    elif name=='A03_WRONG_CALLER_BOOTSTRAP_PIN':
        changed['bootstrap_sha256']='0'*64
    elif name=='A04_WRONG_INVOCATION_PIN':
        changed['invocation_sha256']='0'*64
    elif name=='A05_WRONG_REQUEST_PIN':
        changed['request_sha256']='0'*64
    elif name=='A09_MISSING_SELECTED_CLAIM':
        changed['claim_id']='MISSING'
    elif name in ('A06_WRONG_CLAIM_SCOPE','A07_WRONG_TASK_SCOPE','A08_WRONG_SOURCE_SCOPE'):
        docs=[json.loads(raw) for raw in raws]; field={'A06_WRONG_CLAIM_SCOPE':'claim_sha256','A07_WRONG_TASK_SCOPE':'task_sha256','A08_WRONG_SOURCE_SCOPE':'source_set_sha256'}[name]
        docs[0]['context'][field]='6'*64; docs[3]['context'][field]='6'*64
        for row in docs[2]['runs']:
            row['context'][field]='6'*64
        for row in docs[3]['readings']:
            row['context'][field]='6'*64
            run=next(r for r in docs[2]['runs'] if r['run_id']==row['run_id']); run['reading_sha256']=sha(canonical(row))
        raws=tuple(canonical(doc) for doc in docs); held={n:sha(raws[i]) for i,n in enumerate(policy.NAMES[:3])}
    return product.replay(raws,held,changed)


def closure_mutation(name,options,folder):
    inv=load(options['invocation']); desc=load(inv['checker_descriptor']['path'])
    if name=='C01_FAKE_REPLAY_MODULE_CLOSURE':
        desc['files'][0]['sha256']='0'*64
    elif name=='C02_ROSTER_MISSING_FILE':
        desc['files'].pop()
    elif name=='C03_ROSTER_EXTRA_FILE':
        desc['files'].append(dict(path='checker/tools/fake.py',bytes=1,sha256='0'*64))
    elif name=='C04_ROSTER_DUPLICATE_ENTRY':
        desc['files'].append(copy.deepcopy(desc['files'][0]))
    elif name=='C05_WRONG_RUNTIME_DESCRIPTOR':
        inv['runtime_descriptor']['sha256']='0'*64
    elif name=='C06_WRONG_INSTALL_DESCRIPTOR':
        inv['decoder_install_descriptor']['sha256']='0'*64
    elif name=='C07_WRONG_SOURCE_MANIFEST':
        desc['decoder_source_manifest_sha256']='0'*64
    elif name=='C08_WRONG_PYTHON_IDENTITY':
        desc['python']['sha256']='0'*64
    return options_with(folder,options,invocation=inv,descriptor=desc)


def captured_mutation(name,capture):
    current=copy.deepcopy(capture); result=json.loads(current['stdout']); receipt=json.loads(current['stderr'])
    if name=='P01_EXIT_NONZERO': current['exit_code']=1
    elif name=='P02_FALSE_SUCCESS_STATUS': current['status']='REFUSED_TIMEOUT'
    elif name=='P03_BOOL_ACCEPTED_RESULT': result['accepted_result']=1
    elif name=='P04_WRONG_RESULT_SCHEMA': result['schema']='quorum/replay-result/2'
    elif name=='P05_WRONG_REPLAY_LABEL': result['replay']='SELF_ASSERTED'
    elif name=='P07_WRONG_RECEIPT_STATUS': receipt['status']='SELF_ASSERTED'
    elif name=='P08_WRONG_RECEIPT_SCHEMA': receipt['schema']='quorum/bootstrap-qualified/2'
    elif name=='P14_WRONG_OUTPUT_REQUEST_PIN': result['request']['sha256']='0'*64
    elif name=='P15_DUPLICATE_SELECTED_CLAIM': result['claims'].append(copy.deepcopy(result['claims'][0]))
    elif name=='P16_REFUSAL_AS_SUCCESS': result=dict(schema='quorum/replay-refusal/1',accepted_result=False)
    current.update(stdout=canonical(result)+b'\n',stderr=canonical(receipt)+b'\n')
    if name=='P06_EMPTY_STDERR_RECEIPT': current['stderr']=b''
    elif name=='P09_STDOUT_EXTRA_LINE': current['stdout']+=b'{}\n'
    elif name=='P10_STDERR_EXTRA_LINE': current['stderr']+=b'{}\n'
    elif name=='P11_MISSING_STDOUT_LF': current['stdout']=current['stdout'][:-1]
    elif name=='P12_DOUBLE_STDOUT_LF': current['stdout']+=b'\n'
    elif name=='P13_NONCANONICAL_STDOUT': current['stdout']=b' '+current['stdout']
    elif name=='R04_CAPTURE_OVERFLOW': current['stdout']=b' '*131073
    elif name=='R05_COMPOSED_OUTPUT_OVERFLOW':
        room=131072-len(current['stdout'])-len(current['stderr'])-100
        result['exclusions'].append('x'*room); current['stdout']=canonical(result)+b'\n'
    return current


def compose_refusal(capture,setup,options,threshold):
    try:
        return product.compose(capture,setup,options,threshold)
    except (Refusal,OSError,KeyError,TypeError) as error:
        return dict(status='REFUSED',code=str(error))


def inherited_case(name,raws,held,options,folder):
    kind,cap={'R01_INHERITED_AS_LOWER':(resource.RLIMIT_AS,536870912),'R02_INHERITED_FSIZE_LOWER':(resource.RLIMIT_FSIZE,4194304),'R03_INHERITED_CPU_LOWER':(resource.RLIMIT_CPU,30)}[name]
    script="import json,resource,sys; from pathlib import Path; sys.path[:0]="+repr([str(W/'tools'),str(W/'install')])+"; import transport_quorum_v2_process as p; resource.setrlimit("+str(kind)+",("+str(cap)+","+str(cap)+")); before=resource.getrlimit("+str(kind)+"); r=p.run_bounded(['/usr/bin/python3','-c','raise RuntimeError(\"must not launch\")'],Path('/tmp'),{'PATH':'/usr/bin:/bin'}); print(json.dumps({'result':r,'before':before,'after':resource.getrlimit("+str(kind)+")},default=lambda o:o.decode()))"
    result=subprocess.run([sys.executable,'-I','-S','-B','-c',script],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
    require(result.returncode==0,'resource probe process')
    row=json.loads(result.stdout); require(row['before']==row['after'],'inherited limits changed')
    require(row['result']['status']=='REFUSED_INHERITED_LIMIT' and row['result']['exit_code'] is None,'resource child launched')
    write(folder,'observation.json',row)
    return dict(status='REFUSED',code='REFUSED_INHERITED_LIMIT')


def execute(case,raws,held,options,setup,capture,threshold,folder):
    name=case['id']; method=case['method']; calls=[]
    if name in ('A01_FRESH_LIVE_BINDING','A10_RETAIN_REVALIDATION'):
        return product.replay(raws,held,options)
    if name=='C09_RELOCATABLE_ADMITTED_PATHS':
        return product.replay(raws,held,relocated(folder,options))
    if name=='C10_POSTRUN_SOURCE_DRIFT':
        changed=relocated(folder,options); real=product.run_bounded
        def drift(*args,**kwargs):
            result=real(*args,**kwargs); path=folder/'checker/tools/transport_quorum_replay.py'; path.write_bytes(path.read_bytes()+b'\n# drift\n'); return result
        with patch.object(product,'run_bounded',drift):
            return product.replay(raws,held,changed)
    if method=='PRIVATE_CAPTURE_VALIDATOR' or name=='R05_COMPOSED_OUTPUT_OVERFLOW':
        return compose_refusal(captured_mutation(name,capture),setup,options,threshold)
    if method=='PUBLIC_RESOURCE_SUBPROCESS':
        return inherited_case(name,raws,held,options,folder)
    if name=='A11_NINE_SEATS_DO_NOT_WIDEN_V1':
        return dict(status='NOT_RUN',code='PUBLIC_NINE_SEAT_FIXTURE_PENDING')
    def blocked(*args,**kwargs):
        calls.append(True); return dict(status='REFUSED_TEST_LAUNCH',exit_code=None,stdout=b'',stderr=b'',elapsed_ns=0)
    if name.startswith('C'):
        with patch.object(product,'run_bounded',blocked): result=product.replay(raws,held,closure_mutation(name,options,folder))
    elif name=='R06_ADAPTER_METADATA_OVERFLOW':
        raw=Path(options['invocation']).read_bytes(); padded=raw+b' '*(65536-len(raw)); changed=copy.deepcopy(options); changed.update(invocation=write(folder,'padded.json',padded),invocation_sha256=sha(padded))
        with patch.object(product,'run_bounded',blocked): result=product.replay(raws,held,changed)
    elif case['child_launch']=='FORBIDDEN':
        with patch.object(product,'run_bounded',blocked): result=live_mutation(case,raws,held,options,folder)
    else:
        result=live_mutation(case,raws,held,options,folder)
    if case['child_launch']=='FORBIDDEN': require(not calls,'preflight launched')
    return result


def main():
    before=product_pins(); controls=load(D/'adapter-controls.json'); raws,held,options=fixture(); setup=product._setup(options,raws)
    argv=[str(Path(sys.executable).resolve()),'-I','-S',options['bootstrap'],options['invocation'],'--expect-invocation-sha256',options['invocation_sha256'],'--expect-bootstrap-sha256',product.BOOTSTRAP_SHA]
    capture=product.run_bounded(argv,W,{'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'}); threshold=policy.evaluate(raws,held)
    positive(product.compose(capture,setup,options,threshold)); tag='optimized' if sys.flags.optimize else 'normal'; folder=D/('adapter-'+tag+'-01'); folder.mkdir(mode=0o700)
    write(folder,'stdout',capture['stdout']); write(folder,'stderr',capture['stderr']); outcomes=[]
    for case in controls['cases']:
        try:
            target=folder/case['id']; target.mkdir(mode=0o700)
            result=execute(case,raws,held,options,setup,capture,threshold,target)
            if case['expected_status']=='EVALUATED_LIVE_COMPOSITION': positive(result)
            elif result.get('status')=='NOT_RUN': raise ValueError(result['code'])
            else: require_refusal(result)
            status,error='PASS',''
        except (ValueError,Refusal,OSError,KeyError,TypeError) as exception:
            status,error='FAILED',str(exception); result=None
        outcomes.append(dict(id=case['id'],status=status,error=error,result=result))
    require(before==product_pins(),'product source changed during controls')
    report=dict(schema='quorum/independent-adapter-observations/2',source_pins=before,controls_sha256=sha((D/'adapter-controls.json').read_bytes()),outcomes=outcomes)
    with gzip.open(folder/'results.json.gz','wb') as stream: stream.write(canonical(report)+b'\n')
    print(json.dumps(dict(path=str(folder/'results.json.gz'),failed=[dict(id=r['id'],error=r['error']) for r in outcomes if r['status']!='PASS'],cases=len(outcomes))))


if __name__=='__main__': main()
