"""Authentic original V1 replay plus nine synthetic external-policy seats."""
import json
import os
from pathlib import Path
import sys

os.umask(0o077)
D=Path('/dev/shm/semantic-transport-quorum-v2-20261029/independent')
sys.path.insert(0,str(D))
import run_adapter as review
from transport_quorum_v2_input import canonical,pin,sha


def main():
    before=review.product_pins(); raws,held,options=review.fixture()
    folder=D/('nine-companion-'+('optimized' if sys.flags.optimize else 'normal')+'-01'); folder.mkdir(mode=0o700)
    options=review.original_arm(folder/'original',options)
    oracle=review.load(D/'revision02/oracle.json'); case=next(c for c in oracle['cases'] if c['id']=='L01_NINE_STANDALONE_SEATS')
    docs={name:review.load(D/'revision02'/case['inputs'][name]['path']) for name in review.policy.NAMES}
    context=json.loads(raws[0])['context']; docs['policy'].update(context=context,minimum_support=9,minimum_families=9); docs['ballot']['context']=context
    for reading in docs['ballot']['readings']:
        reading['context']=context
    for admission in docs['admissions']['runs']:
        admission['context']=context; reading=next(r for r in docs['ballot']['readings'] if r['run_id']==admission['run_id']); admission['reading_sha256']=sha(canonical(reading))
    raws=tuple(canonical(docs[name]) for name in review.policy.NAMES); held={name:sha(raws[i]) for i,name in enumerate(review.policy.NAMES[:3])}
    expected=dict(status='EVALUATED_DIMENSIONS',eligible_count=9,support_count=9,support_families=['family'+c for c in 'ABCDEFGHI'],provenance_class='SYNTHETIC_ONLY',verdict='RECORDED_SUPPORT_THRESHOLD_MET',v1_expected_seats=['SEAT_A'],change_impact='NEEDS_REVALIDATION')
    review.write(folder,'expected-before-run.json',expected)
    for name,raw in zip(review.policy.NAMES,raws,strict=True): review.write(folder,name+'.json',raw)
    review.write(folder,'held-roots.json',held); review.write(folder,'options.json',options)
    result=review.product.replay(raws,held,options); review.positive(result)
    threshold=result['threshold']; source=result['source_replay']['claims'][0]
    actual=dict(status=result['status'],eligible_count=threshold['eligible_count'],support_count=threshold['support_count'],support_families=threshold['support_families'],provenance_class=threshold['provenance_class'],verdict=threshold['verdict'],v1_expected_seats=source['aggregation']['expected_seat_ids'],change_impact=source['change_impact'])
    review.require(actual==expected,'nine companion projection')
    review.require(before==review.product_pins(),'source drift')
    review.write(folder,'result.json',result); report=dict(status='PASS',expected=expected,actual=actual,source_pins=before,result_pin=pin(canonical(result)),model_calls=0,scope='Nine distinct synthetic assigned families; no provider observations, identity authentication or error-independence claim. Original V1 registry unchanged.')
    review.write(folder,'review.json',report); print(json.dumps(dict(path=str(folder/'review.json'),status=report['status'],accounting=result['accounting'])))


if __name__=='__main__': main()
