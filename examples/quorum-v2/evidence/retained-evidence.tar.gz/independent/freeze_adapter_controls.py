"""Freeze adapter rejection controls before adapter implementation; no product import."""
import hashlib
import json
from pathlib import Path

ROOT=Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
OUT=Path('/dev/shm/semantic-transport-quorum-v2-20261029/independent')
PINS={'docs/quorum-v2-replay-contract.json':'17173995c4dbbcd6ff16e9c6ac7bd92eca3b47193e4eb77635577623f74a9a52','docs/quorum-v2-replay-admitted.json':'3efde7878e3b61d7a8af2b2b99f27a9ef78c7fd9e421f8953fa96dd7a1238869'}
CASES=[]


def add(name, method, mutation, result='REFUSED', launch='UNSPECIFIED'):
    if len(CASES)>=64 or name in {row['id'] for row in CASES}:
        raise ValueError('control bound/identity')
    CASES.append(dict(id=name,method=method,mutation=mutation,expected_status=result,child_launch=launch,no_threshold_only_live_fallback=True))


add('A01_FRESH_LIVE_BINDING','PUBLIC_LIVE','Run admitted original V1 fixture with fresh synthetic v2 policy/registry/admissions and exact selected source context.','EVALUATED_LIVE_COMPOSITION','REQUIRED')
add('A02_FAKE_BOOTSTRAP_SELF_HASH','PUBLIC_PREFLIGHT','Use fake script that emits plausible result/receipt and supply its correct caller SHA256; product-fixed admitted bootstrap SHA differs.',launch='FORBIDDEN')
add('A03_WRONG_CALLER_BOOTSTRAP_PIN','PUBLIC_PREFLIGHT','Use real admitted bootstrap with one caller expected-digest byte changed.',launch='FORBIDDEN')
add('A04_WRONG_INVOCATION_PIN','PUBLIC_PREFLIGHT','Change invocation bytes while retaining caller expected invocation SHA.',launch='FORBIDDEN')
add('A05_WRONG_REQUEST_PIN','PUBLIC_PREFLIGHT','Change supplied request bytes while retaining externally held expected request SHA.',launch='FORBIDDEN')
add('A06_WRONG_CLAIM_SCOPE','PUBLIC_LIVE','Rehold v2 documents coherently with a different claim_sha256; live selected claim remains original.')
add('A07_WRONG_TASK_SCOPE','PUBLIC_LIVE','Rehold v2 documents coherently with a different task_sha256; actual V1 request.task remains original.')
add('A08_WRONG_SOURCE_SCOPE','PUBLIC_LIVE','Rehold v2 documents coherently with a different source_set_sha256; canonical actual external_source_pins remain original.')
add('A09_MISSING_SELECTED_CLAIM','PUBLIC_LIVE','Select a claim ID/revision not present in authentic replay output.')
add('A10_RETAIN_REVALIDATION','PUBLIC_LIVE','Threshold is met while original fixture change_impact is NEEDS_REVALIDATION. Preserve whole original result/receipt and that exact value.','EVALUATED_LIVE_COMPOSITION','REQUIRED')
add('A11_NINE_SEATS_DO_NOT_WIDEN_V1','PUBLIC_LIVE','A nine-seat standalone v2 policy can pass; attempt nine seats in the V1 body and rebuild local caller pins. Original V1 schema must still refuse.')
add('C01_FAKE_REPLAY_MODULE_CLOSURE','PUBLIC_PREFLIGHT','Replace replay module in private fixture; update descriptor/invocation/file pins self-consistently. Product-fixed 16-file digest/length roster differs.',launch='FORBIDDEN')
add('C02_ROSTER_MISSING_FILE','PUBLIC_PREFLIGHT','Delete a checker/helper roster entry and rehold candidate descriptor/invocation.',launch='FORBIDDEN')
add('C03_ROSTER_EXTRA_FILE','PUBLIC_PREFLIGHT','Add an unadmitted checker/helper roster entry and rehold candidate descriptor/invocation.',launch='FORBIDDEN')
add('C04_ROSTER_DUPLICATE_ENTRY','PUBLIC_PREFLIGHT','Repeat an identical checker/helper roster entry; do not silently deduplicate.',launch='FORBIDDEN')
add('C05_WRONG_RUNTIME_DESCRIPTOR','PUBLIC_PREFLIGHT','Change selected runtime descriptor pin and self-consistent caller invocation; fixed admitted runtime pin differs.',launch='FORBIDDEN')
add('C06_WRONG_INSTALL_DESCRIPTOR','PUBLIC_PREFLIGHT','Change selected install descriptor pin and self-consistent caller invocation; admitted descriptor differs.',launch='FORBIDDEN')
add('C07_WRONG_SOURCE_MANIFEST','PUBLIC_PREFLIGHT','Change decoder source-manifest root in coherent candidate metadata; admitted source-manifest digest differs.',launch='FORBIDDEN')
add('C08_WRONG_PYTHON_IDENTITY','PUBLIC_PREFLIGHT','Use coherent descriptor naming a different Python SHA/length; fixed admitted interpreter identity differs.',launch='FORBIDDEN')
add('C09_RELOCATABLE_ADMITTED_PATHS','PUBLIC_LIVE','Relocate private fixture roots without changing admitted logical roster byte identities and rebuild path-bearing descriptor/invocation pins.','EVALUATED_LIVE_COMPOSITION','REQUIRED')
add('C10_POSTRUN_SOURCE_DRIFT','PUBLIC_LIVE_FAULT_INJECTION','Mutate a private admitted closure file after preflight and before final identity recheck; reject result even if child emitted valid output.')
add('P01_EXIT_NONZERO','PRIVATE_CAPTURE_VALIDATOR','Take actual positive captured output and change owned capture exit_code to 1.')
add('P02_FALSE_SUCCESS_STATUS','PRIVATE_CAPTURE_VALIDATOR','Keep child exit 0 but capture status REFUSED_TIMEOUT; require both status and exit.')
add('P03_BOOL_ACCEPTED_RESULT','PRIVATE_CAPTURE_VALIDATOR','Change accepted_result from Boolean true to integer 1 in canonical stdout.')
add('P04_WRONG_RESULT_SCHEMA','PRIVATE_CAPTURE_VALIDATOR','Change stdout schema version while preserving all other captured fields.')
add('P05_WRONG_REPLAY_LABEL','PRIVATE_CAPTURE_VALIDATOR','Change replay from RECOMPUTED_INFORMATIONAL to an unadmitted label.')
add('P06_EMPTY_STDERR_RECEIPT','PRIVATE_CAPTURE_VALIDATOR','Remove qualification receipt bytes from owned stderr capture.')
add('P07_WRONG_RECEIPT_STATUS','PRIVATE_CAPTURE_VALIDATOR','Change stderr status QUALIFIED_FIXED_HOST to a self-asserted different label.')
add('P08_WRONG_RECEIPT_SCHEMA','PRIVATE_CAPTURE_VALIDATOR','Change stderr qualification schema version.')
add('P09_STDOUT_EXTRA_LINE','PRIVATE_CAPTURE_VALIDATOR','Append a second JSON object line after actual valid stdout.')
add('P10_STDERR_EXTRA_LINE','PRIVATE_CAPTURE_VALIDATOR','Append a second JSON object line after actual valid qualification receipt.')
add('P11_MISSING_STDOUT_LF','PRIVATE_CAPTURE_VALIDATOR','Remove the one required terminal LF from stdout.')
add('P12_DOUBLE_STDOUT_LF','PRIVATE_CAPTURE_VALIDATOR','Append one extra terminal LF to stdout.')
add('P13_NONCANONICAL_STDOUT','PRIVATE_CAPTURE_VALIDATOR','Add harmless JSON whitespace inside actual result; exact canonical output contract refuses.')
add('P14_WRONG_OUTPUT_REQUEST_PIN','PRIVATE_CAPTURE_VALIDATOR','Change stdout request SHA or bytes independently; expected raw request remains held unchanged.')
add('P15_DUPLICATE_SELECTED_CLAIM','PRIVATE_CAPTURE_VALIDATOR','Duplicate selected claim entry in captured result; exactly one match required.')
add('P16_REFUSAL_AS_SUCCESS','PRIVATE_CAPTURE_VALIDATOR','Use a captured V1 refusal object plus exit0/statusSUCCESS; recognized recomputed-result gate still refuses.')
add('R01_INHERITED_AS_LOWER','PUBLIC_RESOURCE_SUBPROCESS','Lower inherited AS hard and soft ceiling below original 1GiB. Verify explicit prelaunch refusal and unchanged parent limits.',launch='FORBIDDEN')
add('R02_INHERITED_FSIZE_LOWER','PUBLIC_RESOURCE_SUBPROCESS','Lower inherited FSIZE hard and soft ceiling below original 32MiB. Verify explicit prelaunch refusal and unchanged parent limits.',launch='FORBIDDEN')
add('R03_INHERITED_CPU_LOWER','PUBLIC_RESOURCE_SUBPROCESS','Lower inherited CPU limit below original nested 120s. Explicit refusal; no limit raise.',launch='FORBIDDEN')
add('R04_CAPTURE_OVERFLOW','PRIVATE_CAPTURE_VALIDATOR','Supply combined stdout/stderr above 131072 bytes; no truncation or partial composition.')
add('R05_COMPOSED_OUTPUT_OVERFLOW','PRIVATE_COMPOSITION_BOUND','Preserved replay+qualification receipt+threshold individually fit prior caps but final canonical response plus LF exceeds 131072. Explicit refusal; no field dropping.')
add('R06_ADAPTER_METADATA_OVERFLOW','PUBLIC_PREFLIGHT','Adapter metadata aggregate exceeds 65536 bytes even while v2 document aggregate fits.',launch='FORBIDDEN')
for name,digest in PINS.items():
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:
        raise ValueError('adapter contract changed before controls freeze')
report=dict(schema='quorum/independent-adapter-control-oracle/2',status='FROZEN_BEFORE_ADAPTER_IMPLEMENTATION',contract_pins=PINS,cases=CASES,
    positive_projection=['Live V1 result and qualification receipt are preserved byte-equivalent after parsing canonical JSON, with only terminal LF framing removed.','Selected claim and actual request derive context exactly as frozen contract; output root pins identify actual captured bytes.','Threshold remains separate from V1 dimensions, source truth, interpretation, model/provider authentication and authority.','SYNTHETIC_ONLY provenance remains synthetic despite threshold success.'],
    method_limits=['PRIVATE_* controls test validator/composition branches using mutations of an actual captured positive result; they are not claims that a fake public bootstrap was admitted.','PUBLIC_PREFLIGHT no-launch controls need a launch-observer or equivalent private process boundary instrumentation; no candidate executable is run.','Relocatable paths preserve exact logical admitted code/data identities; Python, OS/filesystem/race and hash assumptions remain explicit.','Resource tests run in disposable subprocesses; do not lower limits of the active owner or modify frozen artifacts.','Original failed incompatible-core-process-profile attempt must be retained.'])
raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode(); (OUT/'adapter-controls.json').write_bytes(raw)
print(json.dumps(dict(path=str(OUT/'adapter-controls.json'),sha256=hashlib.sha256(raw).hexdigest(),cases=len(CASES),bytes=len(raw))))
