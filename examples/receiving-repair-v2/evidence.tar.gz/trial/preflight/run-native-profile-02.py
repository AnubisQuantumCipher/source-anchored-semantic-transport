"""Original qualified native profile, separate from staging helper profile."""
import hashlib
import json
import os
from pathlib import Path
import resource
import sys

W = Path('/home/sicarii/Work/semantic-transport-bound-evaluation-20261028')
R = Path('/dev/shm/semantic-transport-core-20261029/evidence/receiving-repair-02/final')
sys.path.insert(0, str(W / 'comparison/receiving'))
sys.path.insert(0, str(W / 'install'))
import stage_repair_support as safe
import transport_install_support as support


def main():
    declared = ((resource.RLIMIT_AS, 1073741824), (resource.RLIMIT_CPU, 120),
                (resource.RLIMIT_FSIZE, 33554432), (resource.RLIMIT_NOFILE, 128))
    inherited = []
    for category, ceiling in declared:
        pair = resource.getrlimit(category)
        safe.need(all(v == resource.RLIM_INFINITY or v >= ceiling for v in pair),
                  'QUALIFIED_DEPENDENCY_PROFILE_UNAVAILABLE')
        inherited.append({'category': category, 'soft': pair[0], 'hard': pair[1],
                          'qualified_child_ceiling': ceiling})
    safe.private.chain(R, 'preflight/native-02', create=True)
    argv = safe.load(safe.read(R / 'preflight/native-command.json'))
    argv[argv.index('--workspace') + 1] = str(R / 'preflight/native-02/source-workspace')
    argv[argv.index('--receipt') + 1] = str(R / 'preflight/native-02/decode-receipt.json')
    records = []
    safe.save(R, 'preflight/native-02/command.json', safe.raw_json(argv), records)
    safe.save(R, 'preflight/native-02/profile.json', safe.raw_json({
        'inherited': inherited, 'staging_helper': '512MiB/CPU30/FSIZE4MiB',
        'native_dependency': '1GiB/CPU120/FSIZE32MiB/NOFILE128',
        'limits_raised': False, 'profile_status': 'ORIGINAL_QUALIFIED_BOUND',
        'capture_bytes_per_stream': 8192, 'wall_seconds': 30}), records)
    result = support.run_bounded(argv, R, {'PATH': '/usr/bin:/bin',
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'},
        timeout=30, cap=8192)
    for stream in ('stdout', 'stderr'):
        raw = result.pop(stream)
        safe.save(R, 'preflight/native-02/' + stream, raw, records)
        result[stream + '_sha256'] = hashlib.sha256(raw).hexdigest()
    safe.save(R, 'preflight/native-02/run.json', safe.raw_json(result), records)
    print(json.dumps(result, sort_keys=True))
    return 0 if result['status'] == 'SUCCESS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
